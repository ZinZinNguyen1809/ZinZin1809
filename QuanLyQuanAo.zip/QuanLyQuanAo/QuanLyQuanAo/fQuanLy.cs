﻿using QuanLyQuanAo.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fQuanLy : Form
    {
        private MasterDTO loginMaster;

        public MasterDTO LoginMaster
        {
            get
            {
                return loginMaster;
            }
            set
            {
                loginMaster = value;
            }
        }
        public fQuanLy(MasterDTO boss)
        {
            InitializeComponent();
            this.LoginMaster = boss;
            
        }
        public fQuanLy()
        {
            InitializeComponent();
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fQuanLy_Load(object sender, EventArgs e)
        {

        }

        private void btnDSNV_Click(object sender, EventArgs e)
        {
            fNhanVien f = new fNhanVien();
            f.ShowDialog();
        }
    }
}
