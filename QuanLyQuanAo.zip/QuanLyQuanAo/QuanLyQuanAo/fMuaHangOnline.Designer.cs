﻿namespace QuanLyQuanAo
{
    partial class fMuaHangOnline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOut = new System.Windows.Forms.Button();
            this.btnInBill = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.cbBLoaiTrangPhuc = new System.Windows.Forms.ComboBox();
            this.cbBKieuDang = new System.Windows.Forms.ComboBox();
            this.cbBSize = new System.Windows.Forms.ComboBox();
            this.dataGridViewShowBuyOn = new System.Windows.Forms.DataGridView();
            this.txbSumMoney = new System.Windows.Forms.TextBox();
            this.dataGridViewListBuyOn = new System.Windows.Forms.DataGridView();
            this.lblDanhSach = new System.Windows.Forms.Label();
            this.lblChoose = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.txbMaKHBuyOn = new System.Windows.Forms.TextBox();
            this.lblMaKHBuyOnline = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowBuyOn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListBuyOn)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(1040, 559);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(144, 74);
            this.btnOut.TabIndex = 0;
            this.btnOut.Text = "Thoát";
            this.btnOut.UseVisualStyleBackColor = true;
            // 
            // btnInBill
            // 
            this.btnInBill.Location = new System.Drawing.Point(727, 559);
            this.btnInBill.Name = "btnInBill";
            this.btnInBill.Size = new System.Drawing.Size(144, 74);
            this.btnInBill.TabIndex = 1;
            this.btnInBill.Text = "Thanh toán";
            this.btnInBill.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 401);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 74);
            this.button3.TabIndex = 2;
            this.button3.Text = "Hiển thị tổng tiền";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // cbBLoaiTrangPhuc
            // 
            this.cbBLoaiTrangPhuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBLoaiTrangPhuc.FormattingEnabled = true;
            this.cbBLoaiTrangPhuc.Items.AddRange(new object[] {
            "Nón",
            "Áo",
            "Quần",
            "Vớ"});
            this.cbBLoaiTrangPhuc.Location = new System.Drawing.Point(281, 1);
            this.cbBLoaiTrangPhuc.Name = "cbBLoaiTrangPhuc";
            this.cbBLoaiTrangPhuc.Size = new System.Drawing.Size(202, 33);
            this.cbBLoaiTrangPhuc.TabIndex = 4;
            // 
            // cbBKieuDang
            // 
            this.cbBKieuDang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBKieuDang.FormattingEnabled = true;
            this.cbBKieuDang.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cbBKieuDang.Location = new System.Drawing.Point(281, 84);
            this.cbBKieuDang.Name = "cbBKieuDang";
            this.cbBKieuDang.Size = new System.Drawing.Size(202, 33);
            this.cbBKieuDang.TabIndex = 5;
            // 
            // cbBSize
            // 
            this.cbBSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSize.FormattingEnabled = true;
            this.cbBSize.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cbBSize.Location = new System.Drawing.Point(281, 166);
            this.cbBSize.Name = "cbBSize";
            this.cbBSize.Size = new System.Drawing.Size(202, 33);
            this.cbBSize.TabIndex = 6;
            // 
            // dataGridViewShowBuyOn
            // 
            this.dataGridViewShowBuyOn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowBuyOn.Location = new System.Drawing.Point(727, 22);
            this.dataGridViewShowBuyOn.Name = "dataGridViewShowBuyOn";
            this.dataGridViewShowBuyOn.RowHeadersWidth = 51;
            this.dataGridViewShowBuyOn.RowTemplate.Height = 24;
            this.dataGridViewShowBuyOn.Size = new System.Drawing.Size(457, 161);
            this.dataGridViewShowBuyOn.TabIndex = 7;
            this.dataGridViewShowBuyOn.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txbSumMoney
            // 
            this.txbSumMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSumMoney.Location = new System.Drawing.Point(281, 416);
            this.txbSumMoney.Name = "txbSumMoney";
            this.txbSumMoney.Size = new System.Drawing.Size(202, 36);
            this.txbSumMoney.TabIndex = 8;
            // 
            // dataGridViewListBuyOn
            // 
            this.dataGridViewListBuyOn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListBuyOn.Location = new System.Drawing.Point(727, 223);
            this.dataGridViewListBuyOn.Name = "dataGridViewListBuyOn";
            this.dataGridViewListBuyOn.RowHeadersWidth = 51;
            this.dataGridViewListBuyOn.RowTemplate.Height = 24;
            this.dataGridViewListBuyOn.Size = new System.Drawing.Size(457, 161);
            this.dataGridViewListBuyOn.TabIndex = 9;
            // 
            // lblDanhSach
            // 
            this.lblDanhSach.AutoSize = true;
            this.lblDanhSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDanhSach.Location = new System.Drawing.Point(12, 270);
            this.lblDanhSach.Name = "lblDanhSach";
            this.lblDanhSach.Size = new System.Drawing.Size(392, 29);
            this.lblDanhSach.TabIndex = 10;
            this.lblDanhSach.Text = "Danh sách đồ đã chọn thanh toán";
            // 
            // lblChoose
            // 
            this.lblChoose.AutoSize = true;
            this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoose.Location = new System.Drawing.Point(12, 83);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(108, 29);
            this.lblChoose.TabIndex = 11;
            this.lblChoose.Text = "Chọn đồ";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(549, 65);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(144, 74);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Tìm hàng";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(549, 252);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(144, 74);
            this.btnShow.TabIndex = 13;
            this.btnShow.Text = "Hiện hàng đã chọn";
            this.btnShow.UseVisualStyleBackColor = true;
            // 
            // txbMaKHBuyOn
            // 
            this.txbMaKHBuyOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMaKHBuyOn.Location = new System.Drawing.Point(281, 574);
            this.txbMaKHBuyOn.Name = "txbMaKHBuyOn";
            this.txbMaKHBuyOn.Size = new System.Drawing.Size(202, 36);
            this.txbMaKHBuyOn.TabIndex = 14;
            // 
            // lblMaKHBuyOnline
            // 
            this.lblMaKHBuyOnline.AutoSize = true;
            this.lblMaKHBuyOnline.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaKHBuyOnline.Location = new System.Drawing.Point(12, 577);
            this.lblMaKHBuyOnline.Name = "lblMaKHBuyOnline";
            this.lblMaKHBuyOnline.Size = new System.Drawing.Size(249, 29);
            this.lblMaKHBuyOnline.TabIndex = 15;
            this.lblMaKHBuyOnline.Text = "Mã khách hàng(STT)";
            // 
            // fMuaHangOnline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 699);
            this.Controls.Add(this.lblMaKHBuyOnline);
            this.Controls.Add(this.txbMaKHBuyOn);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblChoose);
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.dataGridViewListBuyOn);
            this.Controls.Add(this.txbSumMoney);
            this.Controls.Add(this.dataGridViewShowBuyOn);
            this.Controls.Add(this.cbBSize);
            this.Controls.Add(this.cbBKieuDang);
            this.Controls.Add(this.cbBLoaiTrangPhuc);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnInBill);
            this.Controls.Add(this.btnOut);
            this.Name = "fMuaHangOnline";
            this.Text = "fMuaHangOnline";
            this.Load += new System.EventHandler(this.fMuaHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowBuyOn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListBuyOn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Button btnInBill;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox cbBLoaiTrangPhuc;
        private System.Windows.Forms.ComboBox cbBKieuDang;
        private System.Windows.Forms.ComboBox cbBSize;
        private System.Windows.Forms.DataGridView dataGridViewShowBuyOn;
        private System.Windows.Forms.TextBox txbSumMoney;
        private System.Windows.Forms.DataGridView dataGridViewListBuyOn;
        private System.Windows.Forms.Label lblDanhSach;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.TextBox txbMaKHBuyOn;
        private System.Windows.Forms.Label lblMaKHBuyOnline;
    }
}