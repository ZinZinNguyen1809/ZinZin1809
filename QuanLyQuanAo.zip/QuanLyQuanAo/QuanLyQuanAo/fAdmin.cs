﻿using QuanLyQuanAo.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fAdmin : Form
    {
       
        public fAdmin()
        { 
            InitializeComponent();
            LoadHat();
            LoadAo();
            LoadQuan();
            LoadSock();
        }
        void LoadHat()
        {
            string query = "SELECT* FROM dbo.Hat";
            dataViewHat.DataSource = DataProvider.Instance.ExecuteQuery(query);  
        }
        void LoadAo()
        {
            string query = "SELECT* FROM dbo.Ao";
            dataViewAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        void LoadQuan()
        {
            string query = "SELECT* FROM dbo.Quan";
            dataViewQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        void LoadSock()
        {
            string query = "SELECT* FROM dbo.Sock";
            dataViewSock.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tpQuan_Click(object sender, EventArgs e)
        {

        }

        private void tpSock_Click(object sender, EventArgs e)
        {

        }

        private void tbDoanhthu_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchSock_Click(object sender, EventArgs e)
        {

        }

        private void txbNameSock_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteHangE_Click(object sender, EventArgs e)
        {

        }

        private void cbBSearchHangTonKho_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnSearchAo_Click(object sender, EventArgs e)
        {

        }

        private void btnAddQuan_Click(object sender, EventArgs e)
        {

        }

        private void btnShowQuan_Click(object sender, EventArgs e)
        {

        }

        private void tbxSearchNameQuan_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnShowHat_Click(object sender, EventArgs e)
        {

        }

        private void txbSearchAo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddHat_Click(object sender, EventArgs e)
        {

        }
    }
}
