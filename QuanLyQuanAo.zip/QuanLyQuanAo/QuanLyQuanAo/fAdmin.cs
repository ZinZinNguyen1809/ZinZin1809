﻿using QuanLyQuanAo.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fAdmin : Form
    {
       
        public fAdmin()
        { 
            InitializeComponent();
            LoadHat();
            LoadAo();
            LoadQuan();
            LoadSock();
        }
        void LoadHat()
        {
            string query = "SELECT* FROM dbo.Hat";
            dataViewHat.DataSource = DataProvider.Instance.ExecuteQuery(query);  
        }
        void LoadAo()
        {
            string query = "SELECT* FROM dbo.Ao";
            dataViewAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        void LoadQuan()
        {
            string query = "SELECT* FROM dbo.Quan";
            dataViewQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        void LoadSock()
        {
            string query = "SELECT* FROM dbo.Sock";
            dataViewSock.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tpQuan_Click(object sender, EventArgs e)
        {

        }

        private void tpSock_Click(object sender, EventArgs e)
        {

        }

        private void tbDoanhthu_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchSock_Click(object sender, EventArgs e)
        {
            if (cbBSearchKDSock.SelectedIndex.ToString()== "Nam")
            {
                string query = "select NgayNhapSock,idSock ,nameS,SoLuongS,priceS from dbo.Sock where KieuDangS=N'Nam'";
                dataViewSearchSock.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKDSock.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select NgayNhapSock,idSock ,nameS,SoLuongS,priceS from dbo.Sock where KieuDangS=N'Nữ'";
                dataViewSearchSock.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
        }

        private void txbNameSock_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteHangE_Click(object sender, EventArgs e)
        {

        }

        private void cbBSearchHangTonKho_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnSearchAo_Click(object sender, EventArgs e)
        {
            /*if (cbBSearchAo.SelectedItem.ToString() == "AoNam")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SizeA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu")
            {
                string query = "select idAo ,nameA,SizeA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }*/
            if (cbBSearchAo.SelectedItem.ToString() == "AoNam"&& cbBSearchSize.SelectedItem.ToString()=="S")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='S' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNam" && cbBSearchSize.SelectedItem.ToString() == "M")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='M' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNam" && cbBSearchSize.SelectedItem.ToString() == "L")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='L' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNam" && cbBSearchSize.SelectedItem.ToString() == "XL")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='XL' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNam" && cbBSearchSize.SelectedItem.ToString() == "XXL")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='XXL' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu" && cbBSearchSize.SelectedItem.ToString() == "S")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'and SizeA='S' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu" && cbBSearchSize.SelectedItem.ToString() == "M")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'and SizeA='M' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu" && cbBSearchSize.SelectedItem.ToString() == "L")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'and SizeA='L' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu" && cbBSearchSize.SelectedItem.ToString() == "XL")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'and SizeA='XL' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchAo.SelectedItem.ToString() == "AoNu" && cbBSearchSize.SelectedItem.ToString() == "XXL")
            {
                string query = "select NgayNhapAo,idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'and SizeA='XXL' ";
                dataViewSearchAo.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
        }

        private void btnAddQuan_Click(object sender, EventArgs e)
        {

        }

        private void btnShowQuan_Click(object sender, EventArgs e)
        {

        }

        private void tbxSearchNameQuan_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnShowHat_Click(object sender, EventArgs e)
        {

        }

        private void txbSearchAo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddHat_Click(object sender, EventArgs e)
        {

        }

     
        private void tpAo_Click(object sender, EventArgs e)
        {
            
        }

        private void cbBSearchAo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnOutAdmin_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteAo_Click(object sender, EventArgs e)
        {
            if (txbAddIDAo.Text != null)
            {
                string DeleteSLAo = txbSLAddAo.Text.ToString();
                string DeleteIDAo = txbAddIDAo.Text.ToString();
                try
                {
                    string query = "  Update dbo.Ao Set SoLuongA=SoLuongA-'"+DeleteSLAo+"' where idAo = '"+DeleteIDAo+"'";
                    DataTable result = DataProvider.Instance.ExecuteQuery(query);
                    if (MessageBox.Show("Xóa thành công", "Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                    {
                        string queryDelete = "SELECT* FROM dbo.Ao";
                        dataViewAo.DataSource = DataProvider.Instance.ExecuteQuery(queryDelete);
                        this.txbAddIDAo.Enabled = false;
                        this.txbSLAddAo.Enabled = false;
                        this.btnDeleteAo.Enabled = false;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa thất bại ", "Thông báo");
                }
            }
            else
            {
                string DeleteNameA = txbNameAo.Text.ToString();
                string DeleteSizeA = txbSizeAo.Text.ToString();
                string DeleteSLAo = txbSLAddAo.Text.ToString();
                string DeleteKDAo = txbKieuDangAo.Text.ToString();
                try
                {
                    string query = " Update dbo.Ao Set SoLuongA=SoLuongA-'"+DeleteSLAo+"' where nameA ='"+DeleteNameA+"' and SizeA ='"+DeleteSizeA+"'and KieuDangA='"+DeleteKDAo+"' ";
                    DataTable result = DataProvider.Instance.ExecuteQuery(query);
                    if (MessageBox.Show("Xóa thành công", "Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                    {
                        string queryDelete = "SELECT* FROM dbo.Ao";
                        dataViewAo.DataSource = DataProvider.Instance.ExecuteQuery(queryDelete);
                        this.txbNameAo.Enabled = false;
                        this.txbSizeAo.Enabled = false;
                        this.txbSLAddAo.Enabled = false;
                        this.txbKieuDangAo.Enabled = false;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Xóa thất bại ", "Thông báo");
                }
            }
            this.btnChange.Enabled = true;

        }

        
        private void btnAddAo_Click(object sender, EventArgs e)
        {
            string AddIDAo=txbAddIDAo.Text.ToString();
            string DateUpdate = dateTimeAddAo.Value.ToString();
            string AddNameA = txbNameAo.Text.ToString();
            string AddSizeA = txbSizeAo.Text.ToString();
            string AddPriceA = txbPriceAo.Text.ToString();
            string AddSoLuongA = txbSLAddAo.Text.ToString();
            string AddKDAo = txbKieuDangAo.Text.ToString();
            try
            {
                string query = "SET IDENTITY_INSERT QuanlyQuanAo. dbo. Ao ON insert into Ao(idAo,NgayNhapAo,nameA,SizeA,SoluongA,KieuDangA,priceA) values('" + AddIDAo + "','" + DateUpdate + "','" + AddNameA + "','" + AddSizeA + "','" + AddSoLuongA + "','" + AddKDAo + "','" + AddPriceA + "')";
                DataTable result = DataProvider.Instance.ExecuteQuery(query);
                if (MessageBox.Show("Thêm thành công", "Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    string query1 = "SELECT* FROM dbo.Ao";
                    dataViewAo.DataSource = DataProvider.Instance.ExecuteQuery(query1);
                    this.txbAddIDAo.Enabled = false;
                    this.txbNameAo.Enabled = false;
                    this.txbSizeAo.Enabled = false;
                    this.txbSLAddAo.Enabled = false;
                    this.txbKieuDangAo.Enabled = false;
                    this.txbSizeAo.Enabled = false;
                    this.dateTimeAddAo.Enabled = false;
                    this.txbPriceAo.Enabled = false;
                    this.btnChange.Enabled = false;
                }  
            }
            catch(Exception )
            {
                MessageBox.Show("Thêm thất bại ");
            }
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataViewAo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbBSearchSize_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dataViewQuan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearchQuan_Click(object sender, EventArgs e)
        {
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNam" && cbBSearchSizeQ.SelectedItem.ToString() == "S")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='S' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNam" && cbBSearchSizeQ.SelectedItem.ToString() == "M")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='M' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNam" && cbBSearchSizeQ.SelectedItem.ToString() == "L")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='L' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNam" && cbBSearchSizeQ.SelectedItem.ToString() == "XL")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='XL' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNam" && cbBSearchSizeQ.SelectedItem.ToString() == "XXL")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='XXL' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNu" && cbBSearchSizeQ.SelectedItem.ToString() == "S")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nữ'and SizeQ='S' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNu" && cbBSearchSizeQ.SelectedItem.ToString() == "M")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nữ'and SizeQ='M' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNu" && cbBSearchSizeQ.SelectedItem.ToString() == "L")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nữ'and SizeQ='L' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNu" && cbBSearchSizeQ.SelectedItem.ToString() == "XL")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nữ'and SizeQ='XL' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchKieuDangQ.SelectedItem.ToString() == "QuanNu" && cbBSearchSizeQ.SelectedItem.ToString() == "XXL")
            {
                string query = "select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nữ'and SizeQ='XXL' ";
                dataViewSearchQuan.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
        }

        private void dtViewSearchQuan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbBSearchKDSale_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearchHangE_Click(object sender, EventArgs e)
        {
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "S" && cbBSearchKDSale.SelectedIndex.ToString()=="Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'S' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "S" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'S' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "M" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'M' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "XL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XL' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "L" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'L' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "XXL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XXL' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "M" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'M' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "L" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'L' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "XL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XL' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "XXL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nam")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XXL' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "S" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'S' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "S" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'S' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "M" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'M' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "XL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XL' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "L" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'L' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Ao" && cbBSearchSizeSale.SelectedIndex.ToString() == "XXL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XXL' and LoaiHangSale=N'Ao'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "M" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'M' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "L" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'L' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "XL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XL' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }
            if (cbBSearchLoaiSale.SelectedIndex.ToString() == "Quan" && cbBSearchSizeSale.SelectedIndex.ToString() == "XXL" && cbBSearchKDSale.SelectedIndex.ToString() == "Nữ")
            {
                string query = "select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'XXL' and LoaiHangSale=N'Quan'";
                dataViewSearchSale.DataSource = DataProvider.Instance.ExecuteQuery(query);
            }

        }

        private void dataViewSearchSale_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbBSearchKDSock_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tbHangTonKho_Click(object sender, EventArgs e)
        {

        }

        private void fAdmin_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thêm áo ? ", "Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            {
                this.txbAddIDAo.Enabled = true;
                this.txbNameAo.Enabled = true;
                this.txbSizeAo.Enabled = true;
                this.txbSLAddAo.Enabled = true;
                this.txbKieuDangAo.Enabled = true;
                this.txbSizeAo.Enabled = true;
                this.dateTimeAddAo.Enabled = true;
                this.txbPriceAo.Enabled = true;
                this.btnAddAo.Enabled = true;
                this.btnChange.Enabled = false;
            }
            else 
            {
                if (MessageBox.Show("Bạn muốn xóa áo theo ID ? ", "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    this.txbAddIDAo.Enabled = true;
                    this.txbSLAddAo.Enabled = true;
                    this.btnDeleteAo.Enabled = true;
                    this.btnChange.Enabled = false;
                }
                else 
                {
                    this.txbSizeAo.Enabled = true;
                    this.txbNameAo.Enabled = true;
                    this.txbSLAddAo.Enabled = true;
                    this.txbKieuDangAo.Enabled = true;
                    this.btnDeleteAo.Enabled = true;
                    this.btnChange.Enabled = false;
                } 

            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txbAddIDAo.Text = null;
            txbNameAo.Text = null;
            txbSizeAo.Text = null;
            txbSLAddAo.Text = null;
            txbKieuDangAo.Text = null;
            txbSizeAo.Text = null;
            dateTimeAddAo.Text = null;
            txbPriceAo.Text = null;

            this.txbAddIDAo.Enabled = false;
            this.txbNameAo.Enabled = false;
            this.txbSizeAo.Enabled = false;
            this.txbSLAddAo.Enabled = false;
            this.txbKieuDangAo.Enabled = false;
            this.txbSizeAo.Enabled = false;
            this.dateTimeAddAo.Enabled = false;
            this.txbPriceAo.Enabled = false;

            this.btnDeleteAo.Enabled = false;
            this.btnAddAo.Enabled = false;
            this.btnChange.Enabled = true;
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            fMuaHangOffline f = new fMuaHangOffline();
            
        }

        private void btnInBill_Click(object sender, EventArgs e)
        {
            fMuaHangOffline f = new fMuaHangOffline();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }
    }
}
