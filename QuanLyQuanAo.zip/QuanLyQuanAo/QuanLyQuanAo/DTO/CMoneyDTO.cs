﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DTO
{
    public class CMoneyDTO
    {
        /*public string ChuyenTien(float a)
        {
            string str = a.ToString();
            // chin TRAM nam MUOI hai TRIEU tam TRAM bay MUOI ba NGan
            //9     tram     5   muoi    2     trieu       8    tram 7     muoi    3  ngan     000           
            for (int i=0;i<str.Length-3;i++)
            {
                switch (str[i])//952873 000
                {
                    case '1' :{
                            return str[i] = "mot";
                        }

                }
            }
            
        }*/
    }
}
