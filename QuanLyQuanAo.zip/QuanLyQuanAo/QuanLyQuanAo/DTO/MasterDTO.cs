﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DTO
{
    public class MasterDTO
    {
        private string userNameMaster;

        public string UserNameMaster
        {
            get
            {
                return userNameMaster;
            }
            set
            {
                userNameMaster = value;
            }
        }

        private string passMaster;

        public string PassMaster
        {
            get
            {
                return passMaster;
            }
            set
            {
                passMaster = value;
            }
        }

        public MasterDTO(string userNameMaster, string passMaster)
        {
            this.userNameMaster = userNameMaster;
            this.passMaster = passMaster;
        }

        public MasterDTO(DataRow row)
        {
            this.userNameMaster = row["userNameMaster"].ToString();
            this.passMaster = row["passMaster"].ToString();
        }
    }
}
