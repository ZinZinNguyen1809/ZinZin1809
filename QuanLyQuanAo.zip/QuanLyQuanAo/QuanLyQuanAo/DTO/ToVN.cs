﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DTO
{
    public class CToVN
    {
        public void ToVN(string newname)
        {
            /*string kq = newname[0].ToString().ToUpper();
            for (int i = 1; i < newname.Length; i++)
            {
                if (newname[i] != ' ')
                {
                    if (newname[i - 1] == ' ')
                    {
                        kq = kq;
                    }
                    else kq = kq + newname[i];
                }
                if (newname[i] == ' ')
                {
                    kq = kq + ' ' + newname[i + 1].ToString().ToUpper();
                }
                //else  kq = kq + newname[i];
            }*/

        }
    }
}
