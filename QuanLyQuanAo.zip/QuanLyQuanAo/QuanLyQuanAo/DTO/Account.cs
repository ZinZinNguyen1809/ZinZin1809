﻿using QuanLyQuanAo.DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DTO
{
    public class Account
    {
        private string userName;
        
        public string UserName
        {
            get 
            {
                return userName;
            }
            set 
            {
                userName = value;
            }
        }

        private string pass;

        public string Pass
        {
            get
            {
                return pass;
            }
            set
            {
                pass = value;
            }
        }

        public Account(string userName, string pass) 
        {
            this.userName = userName;
            this.pass = pass;
        }

        public Account(DataRow row)
        {
            this.userName = row["userName"].ToString();
            this.pass = row["pass"].ToString();
        }
        public Account GetAccountByUserName(string userName)
        {
            DataTable data= DataProvider.Instance.ExecuteQuery("Select *from account where userName = '"+ userName+"'");
            
            foreach(DataRow item in data.Rows)
            {
                return new Account(item);
            }
            return null;
        }


    }
}
