﻿namespace QuanLyQuanAo
{
    partial class fNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOut = new System.Windows.Forms.Button();
            this.btnAddNV = new System.Windows.Forms.Button();
            this.dataViewNV = new System.Windows.Forms.DataGridView();
            this.btnXoaNV = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewNV)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(638, 362);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(132, 53);
            this.btnOut.TabIndex = 3;
            this.btnOut.Text = "Thoát";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // btnAddNV
            // 
            this.btnAddNV.Location = new System.Drawing.Point(250, 362);
            this.btnAddNV.Name = "btnAddNV";
            this.btnAddNV.Size = new System.Drawing.Size(132, 53);
            this.btnAddNV.TabIndex = 4;
            this.btnAddNV.Text = "Thêm nhân viên";
            this.btnAddNV.UseVisualStyleBackColor = true;
            // 
            // dataViewNV
            // 
            this.dataViewNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewNV.Location = new System.Drawing.Point(415, 21);
            this.dataViewNV.Name = "dataViewNV";
            this.dataViewNV.RowHeadersWidth = 51;
            this.dataViewNV.RowTemplate.Height = 24;
            this.dataViewNV.Size = new System.Drawing.Size(373, 130);
            this.dataViewNV.TabIndex = 5;
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Location = new System.Drawing.Point(442, 362);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(132, 53);
            this.btnXoaNV.TabIndex = 6;
            this.btnXoaNV.Text = "Xóa nhân viên";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            // 
            // fNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnXoaNV);
            this.Controls.Add(this.dataViewNV);
            this.Controls.Add(this.btnAddNV);
            this.Controls.Add(this.btnOut);
            this.Name = "fNhanVien";
            this.Text = "fNhanVien";
            this.Load += new System.EventHandler(this.fNhanVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewNV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Button btnAddNV;
        private System.Windows.Forms.DataGridView dataViewNV;
        private System.Windows.Forms.Button btnXoaNV;
    }
}