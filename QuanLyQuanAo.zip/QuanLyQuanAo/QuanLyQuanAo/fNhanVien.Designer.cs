﻿namespace QuanLyQuanAo
{
    partial class fNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOut = new System.Windows.Forms.Button();
            this.btnAddNV = new System.Windows.Forms.Button();
            this.dataViewNV = new System.Windows.Forms.DataGridView();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblTenNV = new System.Windows.Forms.Label();
            this.lblDateNV = new System.Windows.Forms.Label();
            this.lblDiaChiNV = new System.Windows.Forms.Label();
            this.lblSDTNV = new System.Windows.Forms.Label();
            this.lblGioitinh = new System.Windows.Forms.Label();
            this.tbxNameNV = new System.Windows.Forms.TextBox();
            this.lblSTTNV = new System.Windows.Forms.Label();
            this.dateTimeNV = new System.Windows.Forms.DateTimePicker();
            this.tbxSDTNV = new System.Windows.Forms.TextBox();
            this.tbxMaNV = new System.Windows.Forms.TextBox();
            this.tbxGioiTinh = new System.Windows.Forms.TextBox();
            this.tbxDiaChiNV = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnTaoTK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewNV)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(1069, 688);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(132, 53);
            this.btnOut.TabIndex = 3;
            this.btnOut.Text = "Thoát";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // btnAddNV
            // 
            this.btnAddNV.Enabled = false;
            this.btnAddNV.Location = new System.Drawing.Point(267, 526);
            this.btnAddNV.Name = "btnAddNV";
            this.btnAddNV.Size = new System.Drawing.Size(132, 53);
            this.btnAddNV.TabIndex = 4;
            this.btnAddNV.Text = "Thêm nhân viên";
            this.btnAddNV.UseVisualStyleBackColor = true;
            this.btnAddNV.Click += new System.EventHandler(this.btnAddNV_Click);
            // 
            // dataViewNV
            // 
            this.dataViewNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewNV.Location = new System.Drawing.Point(736, 9);
            this.dataViewNV.Name = "dataViewNV";
            this.dataViewNV.RowHeadersWidth = 51;
            this.dataViewNV.RowTemplate.Height = 24;
            this.dataViewNV.Size = new System.Drawing.Size(465, 475);
            this.dataViewNV.TabIndex = 5;
            this.dataViewNV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewNV_CellContentClick);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Enabled = false;
            this.btnXoaNV.Location = new System.Drawing.Point(513, 526);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(132, 53);
            this.btnXoaNV.TabIndex = 6;
            this.btnXoaNV.Text = "Xóa nhân viên";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(769, 526);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(132, 53);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Thay đổi";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblTenNV
            // 
            this.lblTenNV.AutoSize = true;
            this.lblTenNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenNV.Location = new System.Drawing.Point(15, 12);
            this.lblTenNV.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTenNV.Name = "lblTenNV";
            this.lblTenNV.Size = new System.Drawing.Size(173, 29);
            this.lblTenNV.TabIndex = 8;
            this.lblTenNV.Text = "Tên nhân viên";
            // 
            // lblDateNV
            // 
            this.lblDateNV.AutoSize = true;
            this.lblDateNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateNV.Location = new System.Drawing.Point(15, 178);
            this.lblDateNV.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDateNV.Name = "lblDateNV";
            this.lblDateNV.Size = new System.Drawing.Size(126, 29);
            this.lblDateNV.TabIndex = 9;
            this.lblDateNV.Text = "Ngày sinh";
            // 
            // lblDiaChiNV
            // 
            this.lblDiaChiNV.AutoSize = true;
            this.lblDiaChiNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiaChiNV.Location = new System.Drawing.Point(15, 451);
            this.lblDiaChiNV.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDiaChiNV.Name = "lblDiaChiNV";
            this.lblDiaChiNV.Size = new System.Drawing.Size(91, 29);
            this.lblDiaChiNV.TabIndex = 10;
            this.lblDiaChiNV.Text = "Địa chỉ";
            // 
            // lblSDTNV
            // 
            this.lblSDTNV.AutoSize = true;
            this.lblSDTNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDTNV.Location = new System.Drawing.Point(15, 266);
            this.lblSDTNV.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSDTNV.Name = "lblSDTNV";
            this.lblSDTNV.Size = new System.Drawing.Size(63, 29);
            this.lblSDTNV.TabIndex = 11;
            this.lblSDTNV.Text = "SĐT";
            // 
            // lblGioitinh
            // 
            this.lblGioitinh.AutoSize = true;
            this.lblGioitinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioitinh.Location = new System.Drawing.Point(15, 350);
            this.lblGioitinh.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblGioitinh.Name = "lblGioitinh";
            this.lblGioitinh.Size = new System.Drawing.Size(106, 29);
            this.lblGioitinh.TabIndex = 12;
            this.lblGioitinh.Text = "Giới tính";
            // 
            // tbxNameNV
            // 
            this.tbxNameNV.Enabled = false;
            this.tbxNameNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxNameNV.Location = new System.Drawing.Point(290, 12);
            this.tbxNameNV.Name = "tbxNameNV";
            this.tbxNameNV.Size = new System.Drawing.Size(402, 36);
            this.tbxNameNV.TabIndex = 13;
            // 
            // lblSTTNV
            // 
            this.lblSTTNV.AutoSize = true;
            this.lblSTTNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSTTNV.Location = new System.Drawing.Point(15, 98);
            this.lblSTTNV.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSTTNV.Name = "lblSTTNV";
            this.lblSTTNV.Size = new System.Drawing.Size(214, 29);
            this.lblSTTNV.TabIndex = 17;
            this.lblSTTNV.Text = "Mã nhân viên mới";
            // 
            // dateTimeNV
            // 
            this.dateTimeNV.Enabled = false;
            this.dateTimeNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeNV.Location = new System.Drawing.Point(290, 178);
            this.dateTimeNV.Name = "dateTimeNV";
            this.dateTimeNV.Size = new System.Drawing.Size(402, 36);
            this.dateTimeNV.TabIndex = 19;
            // 
            // tbxSDTNV
            // 
            this.tbxSDTNV.Enabled = false;
            this.tbxSDTNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSDTNV.Location = new System.Drawing.Point(290, 266);
            this.tbxSDTNV.Name = "tbxSDTNV";
            this.tbxSDTNV.Size = new System.Drawing.Size(402, 36);
            this.tbxSDTNV.TabIndex = 21;
            // 
            // tbxMaNV
            // 
            this.tbxMaNV.Enabled = false;
            this.tbxMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMaNV.Location = new System.Drawing.Point(290, 98);
            this.tbxMaNV.Name = "tbxMaNV";
            this.tbxMaNV.Size = new System.Drawing.Size(402, 36);
            this.tbxMaNV.TabIndex = 22;
            // 
            // tbxGioiTinh
            // 
            this.tbxGioiTinh.Enabled = false;
            this.tbxGioiTinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxGioiTinh.Location = new System.Drawing.Point(290, 359);
            this.tbxGioiTinh.Name = "tbxGioiTinh";
            this.tbxGioiTinh.Size = new System.Drawing.Size(402, 36);
            this.tbxGioiTinh.TabIndex = 23;
            // 
            // tbxDiaChiNV
            // 
            this.tbxDiaChiNV.Enabled = false;
            this.tbxDiaChiNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDiaChiNV.Location = new System.Drawing.Point(290, 448);
            this.tbxDiaChiNV.Name = "tbxDiaChiNV";
            this.tbxDiaChiNV.Size = new System.Drawing.Size(402, 36);
            this.tbxDiaChiNV.TabIndex = 24;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(998, 526);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(132, 53);
            this.btnCancel.TabIndex = 25;
            this.btnCancel.Text = "Bỏ qua";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnTaoTK
            // 
            this.btnTaoTK.Location = new System.Drawing.Point(20, 526);
            this.btnTaoTK.Name = "btnTaoTK";
            this.btnTaoTK.Size = new System.Drawing.Size(132, 53);
            this.btnTaoTK.TabIndex = 31;
            this.btnTaoTK.Text = "Tạo tài khoản";
            this.btnTaoTK.UseVisualStyleBackColor = true;
            this.btnTaoTK.Click += new System.EventHandler(this.btnTaoTK_Click);
            // 
            // fNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1239, 784);
            this.Controls.Add(this.btnTaoTK);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.tbxDiaChiNV);
            this.Controls.Add(this.tbxGioiTinh);
            this.Controls.Add(this.tbxMaNV);
            this.Controls.Add(this.tbxSDTNV);
            this.Controls.Add(this.dateTimeNV);
            this.Controls.Add(this.lblSTTNV);
            this.Controls.Add(this.tbxNameNV);
            this.Controls.Add(this.lblGioitinh);
            this.Controls.Add(this.lblSDTNV);
            this.Controls.Add(this.lblDiaChiNV);
            this.Controls.Add(this.lblDateNV);
            this.Controls.Add(this.lblTenNV);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnXoaNV);
            this.Controls.Add(this.dataViewNV);
            this.Controls.Add(this.btnAddNV);
            this.Controls.Add(this.btnOut);
            this.Name = "fNhanVien";
            this.Text = "fNhanVien";
            this.Load += new System.EventHandler(this.fNhanVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewNV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Button btnAddNV;
        private System.Windows.Forms.DataGridView dataViewNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblTenNV;
        private System.Windows.Forms.Label lblDateNV;
        private System.Windows.Forms.Label lblDiaChiNV;
        private System.Windows.Forms.Label lblSDTNV;
        private System.Windows.Forms.Label lblGioitinh;
        private System.Windows.Forms.TextBox tbxNameNV;
        private System.Windows.Forms.Label lblSTTNV;
        private System.Windows.Forms.DateTimePicker dateTimeNV;
        private System.Windows.Forms.TextBox tbxSDTNV;
        private System.Windows.Forms.TextBox tbxMaNV;
        private System.Windows.Forms.TextBox tbxGioiTinh;
        private System.Windows.Forms.TextBox tbxDiaChiNV;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnTaoTK;
    }
}