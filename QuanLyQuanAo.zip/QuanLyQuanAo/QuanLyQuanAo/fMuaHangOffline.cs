﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fMuaHangOffline : Form
    {
        public fMuaHangOffline()
        {
            InitializeComponent();
        }

        private void fMuaHangOffline_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnToString_Click(object sender, EventArgs e)
        {

        }

        private void btnAddHD_Click(object sender, EventArgs e)
        {

        }
    }
}
