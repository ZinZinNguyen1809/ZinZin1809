﻿namespace QuanLyQuanAo
{
    partial class fMuaHangOffline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaHoaDon = new System.Windows.Forms.Label();
            this.lblSTTNV = new System.Windows.Forms.Label();
            this.lblDateSell = new System.Windows.Forms.Label();
            this.lblNameNVSell = new System.Windows.Forms.Label();
            this.tbxMaHoaDon = new System.Windows.Forms.TextBox();
            this.tbxNameNVSell = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnAddHD = new System.Windows.Forms.Button();
            this.btnSaveHD = new System.Windows.Forms.Button();
            this.btnHuyHD = new System.Windows.Forms.Button();
            this.btnInHD = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.tbxTongTien = new System.Windows.Forms.TextBox();
            this.btnToString = new System.Windows.Forms.Button();
            this.tbxToString = new System.Windows.Forms.TextBox();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.lblNameKH = new System.Windows.Forms.Label();
            this.tbxNameKH = new System.Windows.Forms.TextBox();
            this.lblDiaChiKh = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxDiaChiKH = new System.Windows.Forms.TextBox();
            this.tbxSDTKH = new System.Windows.Forms.TextBox();
            this.cbbMaNV = new System.Windows.Forms.ComboBox();
            this.cbbMaKH = new System.Windows.Forms.ComboBox();
            this.lblLoaiHang = new System.Windows.Forms.Label();
            this.cbbLoaiHang = new System.Windows.Forms.ComboBox();
            this.lblSLHang = new System.Windows.Forms.Label();
            this.tbxSLHang = new System.Windows.Forms.TextBox();
            this.lblNameHang = new System.Windows.Forms.Label();
            this.tbxNameHang = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.tbxPrice = new System.Windows.Forms.TextBox();
            this.lblSafe = new System.Windows.Forms.Label();
            this.lblToTien = new System.Windows.Forms.Label();
            this.tbxToTien = new System.Windows.Forms.TextBox();
            this.tbxSafe = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaHoaDon
            // 
            this.lblMaHoaDon.AutoSize = true;
            this.lblMaHoaDon.Location = new System.Drawing.Point(60, 33);
            this.lblMaHoaDon.Name = "lblMaHoaDon";
            this.lblMaHoaDon.Size = new System.Drawing.Size(83, 17);
            this.lblMaHoaDon.TabIndex = 0;
            this.lblMaHoaDon.Text = "Mã hóa đơn";
            // 
            // lblSTTNV
            // 
            this.lblSTTNV.AutoSize = true;
            this.lblSTTNV.Location = new System.Drawing.Point(60, 155);
            this.lblSTTNV.Name = "lblSTTNV";
            this.lblSTTNV.Size = new System.Drawing.Size(93, 17);
            this.lblSTTNV.TabIndex = 1;
            this.lblSTTNV.Text = "Mã nhân viên";
            // 
            // lblDateSell
            // 
            this.lblDateSell.AutoSize = true;
            this.lblDateSell.Location = new System.Drawing.Point(60, 93);
            this.lblDateSell.Name = "lblDateSell";
            this.lblDateSell.Size = new System.Drawing.Size(69, 17);
            this.lblDateSell.TabIndex = 2;
            this.lblDateSell.Text = "Ngày bán";
            // 
            // lblNameNVSell
            // 
            this.lblNameNVSell.AutoSize = true;
            this.lblNameNVSell.Location = new System.Drawing.Point(60, 223);
            this.lblNameNVSell.Name = "lblNameNVSell";
            this.lblNameNVSell.Size = new System.Drawing.Size(99, 17);
            this.lblNameNVSell.TabIndex = 3;
            this.lblNameNVSell.Text = "Tên nhân viên";
            // 
            // tbxMaHoaDon
            // 
            this.tbxMaHoaDon.Location = new System.Drawing.Point(194, 33);
            this.tbxMaHoaDon.Name = "tbxMaHoaDon";
            this.tbxMaHoaDon.Size = new System.Drawing.Size(126, 22);
            this.tbxMaHoaDon.TabIndex = 4;
            // 
            // tbxNameNVSell
            // 
            this.tbxNameNVSell.Location = new System.Drawing.Point(194, 218);
            this.tbxNameNVSell.Name = "tbxNameNVSell";
            this.tbxNameNVSell.Size = new System.Drawing.Size(126, 22);
            this.tbxNameNVSell.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(194, 93);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(126, 22);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // btnAddHD
            // 
            this.btnAddHD.Location = new System.Drawing.Point(44, 651);
            this.btnAddHD.Name = "btnAddHD";
            this.btnAddHD.Size = new System.Drawing.Size(128, 40);
            this.btnAddHD.TabIndex = 7;
            this.btnAddHD.Text = "Thêm hóa đơn";
            this.btnAddHD.UseVisualStyleBackColor = true;
            this.btnAddHD.Click += new System.EventHandler(this.btnAddHD_Click);
            // 
            // btnSaveHD
            // 
            this.btnSaveHD.Location = new System.Drawing.Point(253, 651);
            this.btnSaveHD.Name = "btnSaveHD";
            this.btnSaveHD.Size = new System.Drawing.Size(128, 40);
            this.btnSaveHD.TabIndex = 8;
            this.btnSaveHD.Text = "Lưu hóa đơn";
            this.btnSaveHD.UseVisualStyleBackColor = true;
            // 
            // btnHuyHD
            // 
            this.btnHuyHD.Location = new System.Drawing.Point(460, 651);
            this.btnHuyHD.Name = "btnHuyHD";
            this.btnHuyHD.Size = new System.Drawing.Size(128, 40);
            this.btnHuyHD.TabIndex = 9;
            this.btnHuyHD.Text = "Hủy hóa đơn";
            this.btnHuyHD.UseVisualStyleBackColor = true;
            // 
            // btnInHD
            // 
            this.btnInHD.Location = new System.Drawing.Point(656, 651);
            this.btnInHD.Name = "btnInHD";
            this.btnInHD.Size = new System.Drawing.Size(128, 40);
            this.btnInHD.TabIndex = 10;
            this.btnInHD.Text = "In hóa đơn";
            this.btnInHD.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(44, 412);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1055, 150);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Location = new System.Drawing.Point(835, 581);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(68, 17);
            this.lblTongTien.TabIndex = 12;
            this.lblTongTien.Text = "Tổng tiền";
            // 
            // tbxTongTien
            // 
            this.tbxTongTien.Location = new System.Drawing.Point(973, 578);
            this.tbxTongTien.Name = "tbxTongTien";
            this.tbxTongTien.Size = new System.Drawing.Size(126, 22);
            this.tbxTongTien.TabIndex = 13;
            // 
            // btnToString
            // 
            this.btnToString.Location = new System.Drawing.Point(838, 617);
            this.btnToString.Name = "btnToString";
            this.btnToString.Size = new System.Drawing.Size(78, 28);
            this.btnToString.TabIndex = 14;
            this.btnToString.Text = "Bằng chữ";
            this.btnToString.UseVisualStyleBackColor = true;
            this.btnToString.Click += new System.EventHandler(this.btnToString_Click);
            // 
            // tbxToString
            // 
            this.tbxToString.Location = new System.Drawing.Point(973, 620);
            this.tbxToString.Name = "tbxToString";
            this.tbxToString.Size = new System.Drawing.Size(126, 22);
            this.tbxToString.TabIndex = 15;
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Location = new System.Drawing.Point(744, 33);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(105, 17);
            this.lblMaKH.TabIndex = 16;
            this.lblMaKH.Text = "Mã khách hàng";
            // 
            // lblNameKH
            // 
            this.lblNameKH.AutoSize = true;
            this.lblNameKH.Location = new System.Drawing.Point(744, 93);
            this.lblNameKH.Name = "lblNameKH";
            this.lblNameKH.Size = new System.Drawing.Size(111, 17);
            this.lblNameKH.TabIndex = 18;
            this.lblNameKH.Text = "Tên khách hàng";
            // 
            // tbxNameKH
            // 
            this.tbxNameKH.Location = new System.Drawing.Point(973, 93);
            this.tbxNameKH.Name = "tbxNameKH";
            this.tbxNameKH.Size = new System.Drawing.Size(126, 22);
            this.tbxNameKH.TabIndex = 19;
            // 
            // lblDiaChiKh
            // 
            this.lblDiaChiKh.AutoSize = true;
            this.lblDiaChiKh.Location = new System.Drawing.Point(744, 158);
            this.lblDiaChiKh.Name = "lblDiaChiKh";
            this.lblDiaChiKh.Size = new System.Drawing.Size(129, 17);
            this.lblDiaChiKh.TabIndex = 20;
            this.lblDiaChiKh.Text = "Địa chỉ khách hàng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(744, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "SĐT khách hàng";
            // 
            // tbxDiaChiKH
            // 
            this.tbxDiaChiKH.Location = new System.Drawing.Point(973, 150);
            this.tbxDiaChiKH.Name = "tbxDiaChiKH";
            this.tbxDiaChiKH.Size = new System.Drawing.Size(126, 22);
            this.tbxDiaChiKH.TabIndex = 22;
            // 
            // tbxSDTKH
            // 
            this.tbxSDTKH.Location = new System.Drawing.Point(973, 215);
            this.tbxSDTKH.Name = "tbxSDTKH";
            this.tbxSDTKH.Size = new System.Drawing.Size(126, 22);
            this.tbxSDTKH.TabIndex = 23;
            // 
            // cbbMaNV
            // 
            this.cbbMaNV.FormattingEnabled = true;
            this.cbbMaNV.Location = new System.Drawing.Point(194, 155);
            this.cbbMaNV.Name = "cbbMaNV";
            this.cbbMaNV.Size = new System.Drawing.Size(126, 24);
            this.cbbMaNV.TabIndex = 24;
            // 
            // cbbMaKH
            // 
            this.cbbMaKH.FormattingEnabled = true;
            this.cbbMaKH.Location = new System.Drawing.Point(973, 31);
            this.cbbMaKH.Name = "cbbMaKH";
            this.cbbMaKH.Size = new System.Drawing.Size(126, 24);
            this.cbbMaKH.TabIndex = 25;
            // 
            // lblLoaiHang
            // 
            this.lblLoaiHang.AutoSize = true;
            this.lblLoaiHang.Location = new System.Drawing.Point(60, 298);
            this.lblLoaiHang.Name = "lblLoaiHang";
            this.lblLoaiHang.Size = new System.Drawing.Size(71, 17);
            this.lblLoaiHang.TabIndex = 26;
            this.lblLoaiHang.Text = "Loại hàng";
            // 
            // cbbLoaiHang
            // 
            this.cbbLoaiHang.FormattingEnabled = true;
            this.cbbLoaiHang.Items.AddRange(new object[] {
            "Nón",
            "Áo",
            "Quần",
            "Vớ"});
            this.cbbLoaiHang.Location = new System.Drawing.Point(194, 291);
            this.cbbLoaiHang.Name = "cbbLoaiHang";
            this.cbbLoaiHang.Size = new System.Drawing.Size(126, 24);
            this.cbbLoaiHang.TabIndex = 27;
            // 
            // lblSLHang
            // 
            this.lblSLHang.AutoSize = true;
            this.lblSLHang.Location = new System.Drawing.Point(60, 362);
            this.lblSLHang.Name = "lblSLHang";
            this.lblSLHang.Size = new System.Drawing.Size(64, 17);
            this.lblSLHang.TabIndex = 28;
            this.lblSLHang.Text = "Số lượng";
            // 
            // tbxSLHang
            // 
            this.tbxSLHang.Location = new System.Drawing.Point(194, 359);
            this.tbxSLHang.Name = "tbxSLHang";
            this.tbxSLHang.Size = new System.Drawing.Size(126, 22);
            this.tbxSLHang.TabIndex = 29;
            // 
            // lblNameHang
            // 
            this.lblNameHang.AutoSize = true;
            this.lblNameHang.Location = new System.Drawing.Point(429, 298);
            this.lblNameHang.Name = "lblNameHang";
            this.lblNameHang.Size = new System.Drawing.Size(69, 17);
            this.lblNameHang.TabIndex = 30;
            this.lblNameHang.Text = "Tên hàng";
            // 
            // tbxNameHang
            // 
            this.tbxNameHang.Location = new System.Drawing.Point(538, 298);
            this.tbxNameHang.Name = "tbxNameHang";
            this.tbxNameHang.Size = new System.Drawing.Size(126, 22);
            this.tbxNameHang.TabIndex = 31;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(744, 298);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(30, 17);
            this.lblPrice.TabIndex = 32;
            this.lblPrice.Text = "Giá";
            // 
            // tbxPrice
            // 
            this.tbxPrice.Location = new System.Drawing.Point(973, 291);
            this.tbxPrice.Name = "tbxPrice";
            this.tbxPrice.Size = new System.Drawing.Size(126, 22);
            this.tbxPrice.TabIndex = 33;
            // 
            // lblSafe
            // 
            this.lblSafe.AutoSize = true;
            this.lblSafe.Location = new System.Drawing.Point(429, 359);
            this.lblSafe.Name = "lblSafe";
            this.lblSafe.Size = new System.Drawing.Size(86, 17);
            this.lblSafe.TabIndex = 34;
            this.lblSafe.Text = "Giảm giá(%)";
            // 
            // lblToTien
            // 
            this.lblToTien.AutoSize = true;
            this.lblToTien.Location = new System.Drawing.Point(744, 359);
            this.lblToTien.Name = "lblToTien";
            this.lblToTien.Size = new System.Drawing.Size(76, 17);
            this.lblToTien.TabIndex = 35;
            this.lblToTien.Text = "Thành tiền";
            // 
            // tbxToTien
            // 
            this.tbxToTien.Location = new System.Drawing.Point(973, 354);
            this.tbxToTien.Name = "tbxToTien";
            this.tbxToTien.Size = new System.Drawing.Size(126, 22);
            this.tbxToTien.TabIndex = 36;
            // 
            // tbxSafe
            // 
            this.tbxSafe.Location = new System.Drawing.Point(538, 359);
            this.tbxSafe.Name = "tbxSafe";
            this.tbxSafe.Size = new System.Drawing.Size(126, 22);
            this.tbxSafe.TabIndex = 37;
            // 
            // fMuaHangOffline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 722);
            this.Controls.Add(this.tbxSafe);
            this.Controls.Add(this.tbxToTien);
            this.Controls.Add(this.lblToTien);
            this.Controls.Add(this.lblSafe);
            this.Controls.Add(this.tbxPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.tbxNameHang);
            this.Controls.Add(this.lblNameHang);
            this.Controls.Add(this.tbxSLHang);
            this.Controls.Add(this.lblSLHang);
            this.Controls.Add(this.cbbLoaiHang);
            this.Controls.Add(this.lblLoaiHang);
            this.Controls.Add(this.cbbMaKH);
            this.Controls.Add(this.cbbMaNV);
            this.Controls.Add(this.tbxSDTKH);
            this.Controls.Add(this.tbxDiaChiKH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblDiaChiKh);
            this.Controls.Add(this.tbxNameKH);
            this.Controls.Add(this.lblNameKH);
            this.Controls.Add(this.lblMaKH);
            this.Controls.Add(this.tbxToString);
            this.Controls.Add(this.btnToString);
            this.Controls.Add(this.tbxTongTien);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnInHD);
            this.Controls.Add(this.btnHuyHD);
            this.Controls.Add(this.btnSaveHD);
            this.Controls.Add(this.btnAddHD);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tbxNameNVSell);
            this.Controls.Add(this.tbxMaHoaDon);
            this.Controls.Add(this.lblNameNVSell);
            this.Controls.Add(this.lblDateSell);
            this.Controls.Add(this.lblSTTNV);
            this.Controls.Add(this.lblMaHoaDon);
            this.Name = "fMuaHangOffline";
            this.Text = "fMuaHangOffline";
            this.Load += new System.EventHandler(this.fMuaHangOffline_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaHoaDon;
        private System.Windows.Forms.Label lblSTTNV;
        private System.Windows.Forms.Label lblDateSell;
        private System.Windows.Forms.Label lblNameNVSell;
        private System.Windows.Forms.TextBox tbxMaHoaDon;
        private System.Windows.Forms.TextBox tbxNameNVSell;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnAddHD;
        private System.Windows.Forms.Button btnSaveHD;
        private System.Windows.Forms.Button btnHuyHD;
        private System.Windows.Forms.Button btnInHD;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.TextBox tbxTongTien;
        private System.Windows.Forms.Button btnToString;
        private System.Windows.Forms.TextBox tbxToString;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.Label lblNameKH;
        private System.Windows.Forms.TextBox tbxNameKH;
        private System.Windows.Forms.Label lblDiaChiKh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxDiaChiKH;
        private System.Windows.Forms.TextBox tbxSDTKH;
        private System.Windows.Forms.ComboBox cbbMaNV;
        private System.Windows.Forms.ComboBox cbbMaKH;
        private System.Windows.Forms.Label lblLoaiHang;
        private System.Windows.Forms.ComboBox cbbLoaiHang;
        private System.Windows.Forms.Label lblSLHang;
        private System.Windows.Forms.TextBox tbxSLHang;
        private System.Windows.Forms.Label lblNameHang;
        private System.Windows.Forms.TextBox tbxNameHang;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox tbxPrice;
        private System.Windows.Forms.Label lblSafe;
        private System.Windows.Forms.Label lblToTien;
        private System.Windows.Forms.TextBox tbxToTien;
        private System.Windows.Forms.TextBox tbxSafe;
    }
}