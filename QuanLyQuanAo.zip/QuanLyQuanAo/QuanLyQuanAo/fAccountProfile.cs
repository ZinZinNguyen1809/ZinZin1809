﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fAccountProfile : Form
    {
        public fAccountProfile()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txBNewPassTop_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnNewPass_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn muốn đổi mật khẩu ?","Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            {
                if (txbNewPassBot.Text.ToString() == txBNewPassTop.Text.ToString())
                {
                    MessageBox.Show("Đổi mật khẩu thành công ", "Thông báo");
                    
                }
                else
                {
                    MessageBox.Show("Đổi mật khẩu không thành công, vẫn sử dụng mật khẩu cũ", "Thông báo");
                }
            }
        }

        private void txbNewPassBot_TextChanged(object sender, EventArgs e)
        {

        }

        private void fAccountProfile_Load(object sender, EventArgs e)
        {

        }
    }
}
