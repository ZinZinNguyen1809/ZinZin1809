﻿namespace QuanLyQuanAo
{
    partial class fDanhSachKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataViewKH = new System.Windows.Forms.DataGridView();
            this.btnOut = new System.Windows.Forms.Button();
            this.btnSearchKH = new System.Windows.Forms.Button();
            this.tbxSearchKH = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewKH)).BeginInit();
            this.SuspendLayout();
            // 
            // dataViewKH
            // 
            this.dataViewKH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewKH.Location = new System.Drawing.Point(519, 22);
            this.dataViewKH.Name = "dataViewKH";
            this.dataViewKH.RowHeadersWidth = 51;
            this.dataViewKH.RowTemplate.Height = 24;
            this.dataViewKH.Size = new System.Drawing.Size(654, 187);
            this.dataViewKH.TabIndex = 0;
            this.dataViewKH.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewKH_CellClick);
            this.dataViewKH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewKH_CellContentClick);
            this.dataViewKH.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataViewKH_CellPainting);
            // 
            // btnOut
            // 
            this.btnOut.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnOut.Location = new System.Drawing.Point(1018, 643);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(155, 63);
            this.btnOut.TabIndex = 1;
            this.btnOut.Text = "Thoát";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // btnSearchKH
            // 
            this.btnSearchKH.Location = new System.Drawing.Point(1, 22);
            this.btnSearchKH.Name = "btnSearchKH";
            this.btnSearchKH.Size = new System.Drawing.Size(155, 63);
            this.btnSearchKH.TabIndex = 2;
            this.btnSearchKH.Text = "Tìm";
            this.btnSearchKH.UseVisualStyleBackColor = true;
            this.btnSearchKH.Click += new System.EventHandler(this.btnSearchKH_Click);
            // 
            // tbxSearchKH
            // 
            this.tbxSearchKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSearchKH.Location = new System.Drawing.Point(183, 49);
            this.tbxSearchKH.Name = "tbxSearchKH";
            this.tbxSearchKH.Size = new System.Drawing.Size(309, 36);
            this.tbxSearchKH.TabIndex = 3;
            this.tbxSearchKH.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnLoad
            // 
            this.btnLoad.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLoad.Location = new System.Drawing.Point(711, 275);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(155, 63);
            this.btnLoad.TabIndex = 4;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // fDanhSachKhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 743);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.tbxSearchKH);
            this.Controls.Add(this.btnSearchKH);
            this.Controls.Add(this.btnOut);
            this.Controls.Add(this.dataViewKH);
            this.Name = "fDanhSachKhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fDanhSachKhachHang";
            this.Load += new System.EventHandler(this.fDanhSachKhachHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewKH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataViewKH;
        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Button btnSearchKH;
        private System.Windows.Forms.TextBox tbxSearchKH;
        private System.Windows.Forms.Button btnLoad;
    }
}