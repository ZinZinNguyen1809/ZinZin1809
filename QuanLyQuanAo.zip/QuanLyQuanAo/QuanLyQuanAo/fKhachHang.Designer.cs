﻿namespace QuanLyQuanAo
{
    partial class fKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOut = new System.Windows.Forms.Button();
            this.lblNameKH = new System.Windows.Forms.Label();
            this.lblMaKh = new System.Windows.Forms.Label();
            this.lblDateKH = new System.Windows.Forms.Label();
            this.lblSDT = new System.Windows.Forms.Label();
            this.lblDiaChiKH = new System.Windows.Forms.Label();
            this.dateTimeDateKH = new System.Windows.Forms.DateTimePicker();
            this.txbNameKH = new System.Windows.Forms.TextBox();
            this.txbSTTKH = new System.Windows.Forms.TextBox();
            this.txbSdtKH = new System.Windows.Forms.TextBox();
            this.txbDiaChiKH = new System.Windows.Forms.TextBox();
            this.btnAddKH = new System.Windows.Forms.Button();
            this.btnTV = new System.Windows.Forms.Button();
            this.btnOldKH = new System.Windows.Forms.Button();
            this.dataGridViewCheckSTTKH = new System.Windows.Forms.DataGridView();
            this.btnCheckIDKH = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCheckSTTKH)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(974, 584);
            this.btnOut.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(216, 88);
            this.btnOut.TabIndex = 0;
            this.btnOut.Text = "Thoát";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // lblNameKH
            // 
            this.lblNameKH.AutoSize = true;
            this.lblNameKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameKH.Location = new System.Drawing.Point(15, 40);
            this.lblNameKH.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNameKH.Name = "lblNameKH";
            this.lblNameKH.Size = new System.Drawing.Size(194, 29);
            this.lblNameKH.TabIndex = 1;
            this.lblNameKH.Text = "Tên khách hàng";
            this.lblNameKH.Click += new System.EventHandler(this.lblNameKH_Click);
            // 
            // lblMaKh
            // 
            this.lblMaKh.AutoSize = true;
            this.lblMaKh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaKh.Location = new System.Drawing.Point(18, 134);
            this.lblMaKh.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMaKh.Name = "lblMaKh";
            this.lblMaKh.Size = new System.Drawing.Size(252, 29);
            this.lblMaKh.TabIndex = 2;
            this.lblMaKh.Text = "Số thứ tự khách hàng";
            // 
            // lblDateKH
            // 
            this.lblDateKH.AutoSize = true;
            this.lblDateKH.Location = new System.Drawing.Point(15, 246);
            this.lblDateKH.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDateKH.Name = "lblDateKH";
            this.lblDateKH.Size = new System.Drawing.Size(264, 29);
            this.lblDateKH.TabIndex = 3;
            this.lblDateKH.Text = "Ngày sinh khách hàng";
            // 
            // lblSDT
            // 
            this.lblSDT.AutoSize = true;
            this.lblSDT.Location = new System.Drawing.Point(18, 369);
            this.lblSDT.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSDT.Name = "lblSDT";
            this.lblSDT.Size = new System.Drawing.Size(161, 29);
            this.lblSDT.TabIndex = 4;
            this.lblSDT.Text = "Số điện thoại";
            this.lblSDT.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblDiaChiKH
            // 
            this.lblDiaChiKH.AutoSize = true;
            this.lblDiaChiKH.Location = new System.Drawing.Point(18, 486);
            this.lblDiaChiKH.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDiaChiKH.Name = "lblDiaChiKH";
            this.lblDiaChiKH.Size = new System.Drawing.Size(229, 29);
            this.lblDiaChiKH.TabIndex = 5;
            this.lblDiaChiKH.Text = "Địa chỉ khách hàng";
            // 
            // dateTimeDateKH
            // 
            this.dateTimeDateKH.Location = new System.Drawing.Point(335, 240);
            this.dateTimeDateKH.Name = "dateTimeDateKH";
            this.dateTimeDateKH.Size = new System.Drawing.Size(402, 36);
            this.dateTimeDateKH.TabIndex = 6;
            // 
            // txbNameKH
            // 
            this.txbNameKH.Location = new System.Drawing.Point(335, 40);
            this.txbNameKH.Name = "txbNameKH";
            this.txbNameKH.Size = new System.Drawing.Size(402, 36);
            this.txbNameKH.TabIndex = 7;
            this.txbNameKH.TextChanged += new System.EventHandler(this.txbNameKH_TextChanged);
            // 
            // txbSTTKH
            // 
            this.txbSTTKH.Location = new System.Drawing.Point(335, 134);
            this.txbSTTKH.Name = "txbSTTKH";
            this.txbSTTKH.Size = new System.Drawing.Size(402, 36);
            this.txbSTTKH.TabIndex = 8;
            // 
            // txbSdtKH
            // 
            this.txbSdtKH.Location = new System.Drawing.Point(335, 366);
            this.txbSdtKH.Name = "txbSdtKH";
            this.txbSdtKH.Size = new System.Drawing.Size(402, 36);
            this.txbSdtKH.TabIndex = 9;
            // 
            // txbDiaChiKH
            // 
            this.txbDiaChiKH.Location = new System.Drawing.Point(335, 479);
            this.txbDiaChiKH.Name = "txbDiaChiKH";
            this.txbDiaChiKH.Size = new System.Drawing.Size(402, 36);
            this.txbDiaChiKH.TabIndex = 10;
            // 
            // btnAddKH
            // 
            this.btnAddKH.Location = new System.Drawing.Point(670, 584);
            this.btnAddKH.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnAddKH.Name = "btnAddKH";
            this.btnAddKH.Size = new System.Drawing.Size(208, 88);
            this.btnAddKH.TabIndex = 11;
            this.btnAddKH.Text = "Thêm mới";
            this.btnAddKH.UseVisualStyleBackColor = true;
            this.btnAddKH.Click += new System.EventHandler(this.btnAddKH_Click);
            // 
            // btnTV
            // 
            this.btnTV.Location = new System.Drawing.Point(891, 40);
            this.btnTV.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnTV.Name = "btnTV";
            this.btnTV.Size = new System.Drawing.Size(268, 36);
            this.btnTV.TabIndex = 12;
            this.btnTV.Text = "Định dạng Tiếng Việt";
            this.btnTV.UseVisualStyleBackColor = true;
            this.btnTV.Click += new System.EventHandler(this.btnTV_Click);
            // 
            // btnOldKH
            // 
            this.btnOldKH.Location = new System.Drawing.Point(308, 584);
            this.btnOldKH.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnOldKH.Name = "btnOldKH";
            this.btnOldKH.Size = new System.Drawing.Size(211, 88);
            this.btnOldKH.TabIndex = 13;
            this.btnOldKH.Text = "Danh sách khách hàng";
            this.btnOldKH.UseVisualStyleBackColor = true;
            this.btnOldKH.Click += new System.EventHandler(this.btnOldKH_Click);
            // 
            // dataGridViewCheckSTTKH
            // 
            this.dataGridViewCheckSTTKH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCheckSTTKH.Location = new System.Drawing.Point(1044, 135);
            this.dataGridViewCheckSTTKH.Name = "dataGridViewCheckSTTKH";
            this.dataGridViewCheckSTTKH.RowHeadersWidth = 51;
            this.dataGridViewCheckSTTKH.RowTemplate.Height = 24;
            this.dataGridViewCheckSTTKH.Size = new System.Drawing.Size(115, 141);
            this.dataGridViewCheckSTTKH.TabIndex = 14;
            this.dataGridViewCheckSTTKH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCheckSTTKH_CellContentClick);
            // 
            // btnCheckIDKH
            // 
            this.btnCheckIDKH.Location = new System.Drawing.Point(891, 135);
            this.btnCheckIDKH.Name = "btnCheckIDKH";
            this.btnCheckIDKH.Size = new System.Drawing.Size(116, 140);
            this.btnCheckIDKH.TabIndex = 15;
            this.btnCheckIDKH.Text = "Kiểm tra thứ tự khách mới";
            this.btnCheckIDKH.UseVisualStyleBackColor = true;
            this.btnCheckIDKH.Click += new System.EventHandler(this.btnCheckIDKH_Click);
            // 
            // fKhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 686);
            this.Controls.Add(this.btnCheckIDKH);
            this.Controls.Add(this.dataGridViewCheckSTTKH);
            this.Controls.Add(this.btnOldKH);
            this.Controls.Add(this.btnTV);
            this.Controls.Add(this.btnAddKH);
            this.Controls.Add(this.txbDiaChiKH);
            this.Controls.Add(this.txbSdtKH);
            this.Controls.Add(this.txbSTTKH);
            this.Controls.Add(this.txbNameKH);
            this.Controls.Add(this.dateTimeDateKH);
            this.Controls.Add(this.lblDiaChiKH);
            this.Controls.Add(this.lblSDT);
            this.Controls.Add(this.lblDateKH);
            this.Controls.Add(this.lblMaKh);
            this.Controls.Add(this.lblNameKH);
            this.Controls.Add(this.btnOut);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "fKhachHang";
            this.Text = "fKhachHang";
            this.Load += new System.EventHandler(this.fKhachHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCheckSTTKH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Label lblNameKH;
        private System.Windows.Forms.Label lblMaKh;
        private System.Windows.Forms.Label lblDateKH;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.Label lblDiaChiKH;
        private System.Windows.Forms.DateTimePicker dateTimeDateKH;
        private System.Windows.Forms.TextBox txbNameKH;
        private System.Windows.Forms.TextBox txbSTTKH;
        private System.Windows.Forms.TextBox txbSdtKH;
        private System.Windows.Forms.TextBox txbDiaChiKH;
        private System.Windows.Forms.Button btnAddKH;
        private System.Windows.Forms.Button btnTV;
        private System.Windows.Forms.Button btnOldKH;
        private System.Windows.Forms.DataGridView dataGridViewCheckSTTKH;
        private System.Windows.Forms.Button btnCheckIDKH;
    }
}