﻿using QuanLyQuanAo.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DAO
{
    class Master
    {
        private static Master instance;

        public static Master Instance
        {
            get
            {
                if (instance == null) instance = new Master();
                return instance;
            }
            set
            {
                instance = value;
            }
        }
        private Master() { }

        public bool LoginMaster(string userNameMaster, string passWordMaster)
        {
            string query = "SELECT *FROM dbo.Master WHERE UserNameMaster = N'" + userNameMaster + "' AND PassMaster = N'" + passWordMaster + "'";

            DataTable result = DataProvider.Instance.ExecuteQuery(query);

            return result.Rows.Count > 0;
        }

        public MasterDTO GetAccountByUserNameMaster(string userNameMaster)
        {
            DataTable data = DataProvider.Instance.ExecuteQuery("Select *from Master where UserNameMaster = '" + userNameMaster + "'");

            foreach (DataRow item in data.Rows)
            {
                return new MasterDTO(item);
            }
            return null;
        }
    }
}
