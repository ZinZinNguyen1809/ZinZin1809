﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanAo.DAO
{
    public class CKhachHangDAO
    {
        private static CKhachHangDAO instance;
        public static CKhachHangDAO Instance
        {
            get
            {
                if (instance == null) instance = new CKhachHangDAO();
                return instance;
            }
            set
            {
                instance = value;
            }
        }
        private CKhachHangDAO() { }
        
    }
}
