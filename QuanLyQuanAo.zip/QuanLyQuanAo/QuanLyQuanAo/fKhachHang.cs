﻿using QuanLyQuanAo.DAO;
using QuanLyQuanAo.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fKhachHang : Form
    {
        public fKhachHang()
        {
            InitializeComponent();
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblNameKH_Click(object sender, EventArgs e)
        {

        }

        private void fKhachHang_Load(object sender, EventArgs e)
        {

        }

        private void btnAddKH_Click(object sender, EventArgs e)
        {
            string DiaChiKH =txbDiaChiKH.Text.ToString();
            string nameKH = txbNameKH.Text.ToString();
            string sdtKH = txbSdtKH.Text.ToString();
            string MaKH = txbSTTKH.Text.ToString();
            string snKH = dateTimeSNKH.Value.ToString();

            if (DiaChiKH.Length != 0 && nameKH.Length != 0 && sdtKH.Length != 0 && MaKH.Length != 0 && snKH.Length != 0)
            {
                try
                {
                    string query = "insert into dbo.KhachHang(MaKH,TênKH,NgàySinhKH,ĐịaChỉKH,SĐT,SốTiềnĐãGD) values('" + MaKH + "','" + nameKH + "','" + snKH + "','" + DiaChiKH + "','" + sdtKH + "','" + 0 + "')";
                    DataTable data = DataProvider.Instance.ExecuteQuery(query);
                    MessageBox.Show("Thêm thành công", "Thông báo", MessageBoxButtons.OK);
                    
                    txbDiaChiKH.Text = null;
                    txbNameKH.Text = null;
                    txbSdtKH.Text = null;
                    txbSTTKH.Text = null;
                    dateTimeSNKH.Text = null;
                }
                catch (Exception)
                {
                    MessageBox.Show("Thêm thất bại", "Thông báo");
                }

            }
            else MessageBox.Show("Chưa nhập đủ thông tin", "Thông báo", MessageBoxButtons.OK);
        }

        private void txbNameKH_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTV_Click(object sender, EventArgs e)
        {
            string newname=txbNameKH.Text.Trim().ToLower();
            string kq = newname[0].ToString().ToUpper();
            for (int i = 1; i < newname.Length; i++)
            {

                if (newname[i] != ' ')
                {
                    if (newname[i - 1] == ' ')
                    {
                        kq = kq;
                    }
                    else kq = kq + newname[i];
                }
                if (newname[i] == ' ')
                {
                    kq = kq + ' ' + newname[i + 1].ToString().ToUpper();
                }
                //else  kq = kq + newname[i];
            }
            txbNameKH.Text = kq;
        }

        private void btnOldKH_Click(object sender, EventArgs e)
        {
            fDanhSachKhachHang f = new fDanhSachKhachHang();
            f.ShowDialog();

        }

        private void btnCheckIDKH_Click(object sender, EventArgs e)
        {
            //string query = "select MaKH from dbo.KhachHang ";
            //dataGridViewCheckSTTKH.DataSource= DataProvider.Instance.ExecuteQuery(query);
            txbSTTKH.Text = CBill.CreateKey("hihi");
        }

        private void dataGridViewCheckSTTKH_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void txbSdtKH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void txbNameKH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
    }
}
