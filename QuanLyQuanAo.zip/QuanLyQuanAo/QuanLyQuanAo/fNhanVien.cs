﻿using QuanLyQuanAo.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fNhanVien : Form
    {
        public fNhanVien()
        {
            InitializeComponent();
            LoadNV();
        }
        void LoadNV()
        {
            string query = "SELECT* FROM dbo.Nhanvien";
            dataViewNV.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fNhanVien_Load(object sender, EventArgs e)
        {

        }

        private void dataViewNV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.tbxMaNV.Enabled = false;
            this.txbNameNV.Enabled = false;
            this.tbxDiaChiNV.Enabled = false; 
            this.tbxGioiTinh.Enabled = false;
            this.tbxSDTNV.Enabled = false;
            this.dateTimeNV.Enabled = false;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            fLogin f = new fLogin();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btnTaoTK_Click(object sender, EventArgs e)
        {
            fNewAccount f = new fNewAccount();
            this.Hide();
            f.ShowDialog();
            this.Show();

        }
    }
}
