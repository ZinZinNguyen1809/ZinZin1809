﻿using QuanLyQuanAo.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanAo
{
    public partial class fNhanVien : Form
    {
        public fNhanVien()
        {
            InitializeComponent();
            LoadNV();
        }
        void LoadNV()
        {
            string query = "SELECT* FROM dbo.Nhanvien";
            dataViewNV.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fNhanVien_Load(object sender, EventArgs e)
        {

        }

        private void dataViewNV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.tbxMaNV.Enabled = false;
            this.tbxNameNV.Enabled = false;
            this.tbxDiaChiNV.Enabled = false; 
            this.tbxGioiTinh.Enabled = false;
            this.tbxSDTNV.Enabled = false;
            this.dateTimeNV.Enabled = false;

            this.btnAddNV.Enabled = false;
            this.btnDeleteNV.Enabled = false;
            this.btnChangeNV.Enabled = true;

            tbxNameNV.Text = null;
            tbxSDTNV.Text = null;
            tbxMaNV.Text = null;
            tbxGioiTinh.Text = null;
            tbxDiaChiNV.Text = null;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            fLogin f = new fLogin();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btnTaoTK_Click(object sender, EventArgs e)
        {
            fNewAccount f = new fNewAccount();
            this.Hide();
            f.ShowDialog();
            this.Show();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thêm nhân viên mới ? ", "Thông báo ", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            {
                this.tbxDiaChiNV.Enabled = true;
                this.tbxGioiTinh.Enabled = true;
                this.tbxMaNV.Enabled = true;
                this.tbxNameNV.Enabled = true;
                this.tbxSDTNV.Enabled = true;
                this.dateTimeNV.Enabled = true;

                this.btnAddNV.Enabled = true;
                this.btnChangeNV.Enabled = false;
            }
            else
            {
                if (MessageBox.Show("Bạn muốn xóa nhân viên theo ID ? ", "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    this.tbxMaNV.Enabled = true;
                    
                    this.btnDeleteNV.Enabled = true;
                    this.btnChangeNV.Enabled = false;   
                }
            }
        }

        private void btnAddNV_Click(object sender, EventArgs e)
        {
            string nameNV = tbxNameNV.Text.ToString();
            string dateNV = dateTimeNV.Value.ToString();
            string SdtNV = tbxSDTNV.Text.ToString();
            string DiaChiNV = tbxDiaChiNV.Text.ToString();
            string GioiTinh = tbxGioiTinh.Text.ToString();
            string MaNV = tbxMaNV.Text.ToString();
            try
            {
                string query = "insert into NhanVien(MANV,TenNhanvien,NgaySinh,SdtNhanvien,DiaChiNhanvien,GioiTinh) values('"+MaNV+"','"+nameNV+"','"+dateNV+"','"+SdtNV+"','"+DiaChiNV+"','"+GioiTinh+"')";
                DataTable data = DataProvider.Instance.ExecuteQuery(query);
                if (MessageBox.Show("Thêm thành công", "Thông báo ", MessageBoxButtons.OK) == System.Windows.Forms.DialogResult.OK)
                {
                    string query1 = "select *from dbo.NhanVien";
                    dataViewNV.DataSource = DataProvider.Instance.ExecuteQuery(query1);

                    this.tbxDiaChiNV.Enabled = false;
                    this.tbxGioiTinh.Enabled = false;
                    this.tbxMaNV.Enabled = false;
                    this.tbxNameNV.Enabled = false;
                    this.tbxSDTNV.Enabled = false;
                    this.dateTimeNV.Enabled = false;

                    btnAddNV.Enabled = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Thêm thất bại", "Thông báo");
            }
        }

        private void btnDeleteNV_Click(object sender, EventArgs e)
        {
            if (tbxMaNV.Text != null)
            {
                string MaNV = tbxMaNV.Text.ToString();
                string query= "delete dbo.NhanVien where MANV = '"+MaNV+"'";
                DataTable data = DataProvider.Instance.ExecuteQuery(query);
                if (MessageBox.Show("Xóa thành công","Thông báo",MessageBoxButtons.OK)== System.Windows.Forms.DialogResult.OK)
                {
                    string query1 = "select *from NhanVien";
                    dataViewNV.DataSource = DataProvider.Instance.ExecuteQuery(query1);

                    this.tbxMaNV.Enabled = false;
                    this.btnDeleteNV.Enabled = false;
                    this.btnChangeNV.Enabled = true;
                }
            }
        }
    }
}
