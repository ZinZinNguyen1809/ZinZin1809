﻿namespace QuanLyQuanAo
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbHangTonKho = new System.Windows.Forms.TabPage();
            this.lblSearchLoaiHTKho = new System.Windows.Forms.Label();
            this.cbBSearchHangTonKho = new System.Windows.Forms.ComboBox();
            this.btnSearchHangE = new System.Windows.Forms.Button();
            this.txbSearchHangE = new System.Windows.Forms.TextBox();
            this.btnShowHangE = new System.Windows.Forms.Button();
            this.btnEditHangE = new System.Windows.Forms.Button();
            this.btnDeleteHangE = new System.Windows.Forms.Button();
            this.btnAddHangE = new System.Windows.Forms.Button();
            this.dataViewẾ = new System.Windows.Forms.DataGridView();
            this.tpSock = new System.Windows.Forms.TabPage();
            this.btAddSock = new System.Windows.Forms.Button();
            this.btnDeleteSock = new System.Windows.Forms.Button();
            this.cbBDanhmucSock = new System.Windows.Forms.ComboBox();
            this.tbxSearchNameSock = new System.Windows.Forms.TextBox();
            this.tbxSearchIdSock = new System.Windows.Forms.TextBox();
            this.txbSearchSock = new System.Windows.Forms.TextBox();
            this.nmUDPriceSock = new System.Windows.Forms.NumericUpDown();
            this.lblSearchPriceSock = new System.Windows.Forms.Label();
            this.lblSearchDanhmucSock = new System.Windows.Forms.Label();
            this.lblSearchNameSock = new System.Windows.Forms.Label();
            this.lblSearchIDSock = new System.Windows.Forms.Label();
            this.dataViewSock = new System.Windows.Forms.DataGridView();
            this.btnSearchSock = new System.Windows.Forms.Button();
            this.btnShowSock = new System.Windows.Forms.Button();
            this.btnEditSock = new System.Windows.Forms.Button();
            this.tpQuan = new System.Windows.Forms.TabPage();
            this.btnAddQuan = new System.Windows.Forms.Button();
            this.btnDeleteQuan = new System.Windows.Forms.Button();
            this.txbSearchQuan = new System.Windows.Forms.TextBox();
            this.cbBDanhmucQuan = new System.Windows.Forms.ComboBox();
            this.tbxSearchNameQuan = new System.Windows.Forms.TextBox();
            this.tbxSearchIDQuan = new System.Windows.Forms.TextBox();
            this.nmUDPriceQuan = new System.Windows.Forms.NumericUpDown();
            this.lblSearchPriceQuan = new System.Windows.Forms.Label();
            this.lblSearchDanhmucQuan = new System.Windows.Forms.Label();
            this.lblSearchNameQuan = new System.Windows.Forms.Label();
            this.lblSearchIDQuan = new System.Windows.Forms.Label();
            this.dataViewQuan = new System.Windows.Forms.DataGridView();
            this.btnSearchQuan = new System.Windows.Forms.Button();
            this.btnShowQuan = new System.Windows.Forms.Button();
            this.btnEditQuan = new System.Windows.Forms.Button();
            this.tpAo = new System.Windows.Forms.TabPage();
            this.btnAddAo = new System.Windows.Forms.Button();
            this.btnDeleteAo = new System.Windows.Forms.Button();
            this.cbBDanhmucAo = new System.Windows.Forms.ComboBox();
            this.txbSearchNameAo = new System.Windows.Forms.TextBox();
            this.txbSearchIdAo = new System.Windows.Forms.TextBox();
            this.txbSearchAo = new System.Windows.Forms.TextBox();
            this.nmUDPriceAo = new System.Windows.Forms.NumericUpDown();
            this.lblSearchPriceAo = new System.Windows.Forms.Label();
            this.lblSearchDanhmucAo = new System.Windows.Forms.Label();
            this.lblSearchNameAo = new System.Windows.Forms.Label();
            this.lblSearchIDAo = new System.Windows.Forms.Label();
            this.dataViewAo = new System.Windows.Forms.DataGridView();
            this.btnSearchAo = new System.Windows.Forms.Button();
            this.btnShowAo = new System.Windows.Forms.Button();
            this.btnEditAo = new System.Windows.Forms.Button();
            this.lblSpriceHat = new System.Windows.Forms.TabPage();
            this.nmUDPriceHat = new System.Windows.Forms.NumericUpDown();
            this.lblSearchPriceHat = new System.Windows.Forms.Label();
            this.cbBDanhmucHat = new System.Windows.Forms.ComboBox();
            this.lblSearchDanhmucHat = new System.Windows.Forms.Label();
            this.txbSearchNameHat = new System.Windows.Forms.TextBox();
            this.txbIDHat = new System.Windows.Forms.TextBox();
            this.txbSearchHat = new System.Windows.Forms.TextBox();
            this.lblSearchNameHat = new System.Windows.Forms.Label();
            this.lblSearchIDHat = new System.Windows.Forms.Label();
            this.btnSearchHat = new System.Windows.Forms.Button();
            this.btnShowHat = new System.Windows.Forms.Button();
            this.btnEditHat = new System.Windows.Forms.Button();
            this.btnDeleteHat = new System.Windows.Forms.Button();
            this.btnAddHat = new System.Windows.Forms.Button();
            this.dataViewHat = new System.Windows.Forms.DataGridView();
            this.tbDoanhthu = new System.Windows.Forms.TabPage();
            this.btnThongKeTienLai = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblMoney = new System.Windows.Forms.Label();
            this.lblLai = new System.Windows.Forms.Label();
            this.btnThongKeDoanhThu = new System.Windows.Forms.Button();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tb9 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnOutAdmin = new System.Windows.Forms.Button();
            this.tbHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewẾ)).BeginInit();
            this.tpSock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceSock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).BeginInit();
            this.tpQuan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).BeginInit();
            this.tpAo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceAo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).BeginInit();
            this.lblSpriceHat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceHat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).BeginInit();
            this.tbDoanhthu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tb9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbHangTonKho
            // 
            this.tbHangTonKho.Controls.Add(this.lblSearchLoaiHTKho);
            this.tbHangTonKho.Controls.Add(this.cbBSearchHangTonKho);
            this.tbHangTonKho.Controls.Add(this.btnSearchHangE);
            this.tbHangTonKho.Controls.Add(this.txbSearchHangE);
            this.tbHangTonKho.Controls.Add(this.btnShowHangE);
            this.tbHangTonKho.Controls.Add(this.btnEditHangE);
            this.tbHangTonKho.Controls.Add(this.btnDeleteHangE);
            this.tbHangTonKho.Controls.Add(this.btnAddHangE);
            this.tbHangTonKho.Controls.Add(this.dataViewẾ);
            this.tbHangTonKho.Location = new System.Drawing.Point(4, 25);
            this.tbHangTonKho.Name = "tbHangTonKho";
            this.tbHangTonKho.Padding = new System.Windows.Forms.Padding(3);
            this.tbHangTonKho.Size = new System.Drawing.Size(962, 584);
            this.tbHangTonKho.TabIndex = 5;
            this.tbHangTonKho.Text = "Hàng tồn kho";
            this.tbHangTonKho.UseVisualStyleBackColor = true;
            // 
            // lblSearchLoaiHTKho
            // 
            this.lblSearchLoaiHTKho.AutoSize = true;
            this.lblSearchLoaiHTKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchLoaiHTKho.Location = new System.Drawing.Point(584, 3);
            this.lblSearchLoaiHTKho.Name = "lblSearchLoaiHTKho";
            this.lblSearchLoaiHTKho.Size = new System.Drawing.Size(258, 29);
            this.lblSearchLoaiHTKho.TabIndex = 29;
            this.lblSearchLoaiHTKho.Text = "Loại mặt hàng cần tra";
            // 
            // cbBSearchHangTonKho
            // 
            this.cbBSearchHangTonKho.FormattingEnabled = true;
            this.cbBSearchHangTonKho.Items.AddRange(new object[] {
            "Nón",
            "Áo",
            "Quần",
            "Vớ"});
            this.cbBSearchHangTonKho.Location = new System.Drawing.Point(613, 45);
            this.cbBSearchHangTonKho.Name = "cbBSearchHangTonKho";
            this.cbBSearchHangTonKho.Size = new System.Drawing.Size(207, 24);
            this.cbBSearchHangTonKho.TabIndex = 28;
            this.cbBSearchHangTonKho.SelectedIndexChanged += new System.EventHandler(this.cbBSearchHangTonKho_SelectedIndexChanged);
            // 
            // btnSearchHangE
            // 
            this.btnSearchHangE.Location = new System.Drawing.Point(839, 77);
            this.btnSearchHangE.Name = "btnSearchHangE";
            this.btnSearchHangE.Size = new System.Drawing.Size(99, 71);
            this.btnSearchHangE.TabIndex = 27;
            this.btnSearchHangE.Text = "Tìm";
            this.btnSearchHangE.UseVisualStyleBackColor = true;
            // 
            // txbSearchHangE
            // 
            this.txbSearchHangE.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchHangE.Location = new System.Drawing.Point(571, 90);
            this.txbSearchHangE.Name = "txbSearchHangE";
            this.txbSearchHangE.Size = new System.Drawing.Size(262, 36);
            this.txbSearchHangE.TabIndex = 26;
            // 
            // btnShowHangE
            // 
            this.btnShowHangE.Location = new System.Drawing.Point(360, 12);
            this.btnShowHangE.Name = "btnShowHangE";
            this.btnShowHangE.Size = new System.Drawing.Size(99, 67);
            this.btnShowHangE.TabIndex = 25;
            this.btnShowHangE.Text = "Kiểm tra hàng tồn kho";
            this.btnShowHangE.UseVisualStyleBackColor = true;
            // 
            // btnEditHangE
            // 
            this.btnEditHangE.Location = new System.Drawing.Point(240, 10);
            this.btnEditHangE.Name = "btnEditHangE";
            this.btnEditHangE.Size = new System.Drawing.Size(99, 71);
            this.btnEditHangE.TabIndex = 24;
            this.btnEditHangE.Text = "Sửa đổi thông tin hàng tồn kho";
            this.btnEditHangE.UseVisualStyleBackColor = true;
            // 
            // btnDeleteHangE
            // 
            this.btnDeleteHangE.Location = new System.Drawing.Point(111, 10);
            this.btnDeleteHangE.Name = "btnDeleteHangE";
            this.btnDeleteHangE.Size = new System.Drawing.Size(109, 71);
            this.btnDeleteHangE.TabIndex = 23;
            this.btnDeleteHangE.Text = "Xóa";
            this.btnDeleteHangE.UseVisualStyleBackColor = true;
            this.btnDeleteHangE.Click += new System.EventHandler(this.btnDeleteHangE_Click);
            // 
            // btnAddHangE
            // 
            this.btnAddHangE.Location = new System.Drawing.Point(6, 10);
            this.btnAddHangE.Name = "btnAddHangE";
            this.btnAddHangE.Size = new System.Drawing.Size(99, 71);
            this.btnAddHangE.TabIndex = 22;
            this.btnAddHangE.Text = "Thêm hàng tồn kho";
            this.btnAddHangE.UseVisualStyleBackColor = true;
            // 
            // dataViewẾ
            // 
            this.dataViewẾ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewẾ.Location = new System.Drawing.Point(6, 118);
            this.dataViewẾ.Name = "dataViewẾ";
            this.dataViewẾ.RowHeadersWidth = 51;
            this.dataViewẾ.RowTemplate.Height = 24;
            this.dataViewẾ.Size = new System.Drawing.Size(469, 456);
            this.dataViewẾ.TabIndex = 9;
            // 
            // tpSock
            // 
            this.tpSock.Controls.Add(this.btAddSock);
            this.tpSock.Controls.Add(this.btnDeleteSock);
            this.tpSock.Controls.Add(this.cbBDanhmucSock);
            this.tpSock.Controls.Add(this.tbxSearchNameSock);
            this.tpSock.Controls.Add(this.tbxSearchIdSock);
            this.tpSock.Controls.Add(this.txbSearchSock);
            this.tpSock.Controls.Add(this.nmUDPriceSock);
            this.tpSock.Controls.Add(this.lblSearchPriceSock);
            this.tpSock.Controls.Add(this.lblSearchDanhmucSock);
            this.tpSock.Controls.Add(this.lblSearchNameSock);
            this.tpSock.Controls.Add(this.lblSearchIDSock);
            this.tpSock.Controls.Add(this.dataViewSock);
            this.tpSock.Controls.Add(this.btnSearchSock);
            this.tpSock.Controls.Add(this.btnShowSock);
            this.tpSock.Controls.Add(this.btnEditSock);
            this.tpSock.Location = new System.Drawing.Point(4, 25);
            this.tpSock.Name = "tpSock";
            this.tpSock.Padding = new System.Windows.Forms.Padding(3);
            this.tpSock.Size = new System.Drawing.Size(962, 584);
            this.tpSock.TabIndex = 4;
            this.tpSock.Text = "Vớ";
            this.tpSock.UseVisualStyleBackColor = true;
            this.tpSock.Click += new System.EventHandler(this.tpSock_Click);
            // 
            // btAddSock
            // 
            this.btAddSock.Location = new System.Drawing.Point(17, 6);
            this.btAddSock.Name = "btAddSock";
            this.btAddSock.Size = new System.Drawing.Size(99, 71);
            this.btAddSock.TabIndex = 21;
            this.btAddSock.Text = "Thêm vào kho hàng";
            this.btAddSock.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSock
            // 
            this.btnDeleteSock.Location = new System.Drawing.Point(122, 6);
            this.btnDeleteSock.Name = "btnDeleteSock";
            this.btnDeleteSock.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteSock.TabIndex = 20;
            this.btnDeleteSock.Text = "Xóa";
            this.btnDeleteSock.UseVisualStyleBackColor = true;
            // 
            // cbBDanhmucSock
            // 
            this.cbBDanhmucSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBDanhmucSock.FormattingEnabled = true;
            this.cbBDanhmucSock.Location = new System.Drawing.Point(687, 256);
            this.cbBDanhmucSock.Name = "cbBDanhmucSock";
            this.cbBDanhmucSock.Size = new System.Drawing.Size(272, 37);
            this.cbBDanhmucSock.TabIndex = 19;
            // 
            // tbxSearchNameSock
            // 
            this.tbxSearchNameSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSearchNameSock.Location = new System.Drawing.Point(687, 187);
            this.tbxSearchNameSock.Name = "tbxSearchNameSock";
            this.tbxSearchNameSock.Size = new System.Drawing.Size(272, 36);
            this.tbxSearchNameSock.TabIndex = 18;
            // 
            // tbxSearchIdSock
            // 
            this.tbxSearchIdSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSearchIdSock.Location = new System.Drawing.Point(687, 112);
            this.tbxSearchIdSock.Name = "tbxSearchIdSock";
            this.tbxSearchIdSock.ReadOnly = true;
            this.tbxSearchIdSock.Size = new System.Drawing.Size(272, 36);
            this.tbxSearchIdSock.TabIndex = 16;
            // 
            // txbSearchSock
            // 
            this.txbSearchSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchSock.Location = new System.Drawing.Point(553, 37);
            this.txbSearchSock.Name = "txbSearchSock";
            this.txbSearchSock.Size = new System.Drawing.Size(262, 36);
            this.txbSearchSock.TabIndex = 15;
            this.txbSearchSock.TextChanged += new System.EventHandler(this.txbNameSock_TextChanged);
            // 
            // nmUDPriceSock
            // 
            this.nmUDPriceSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmUDPriceSock.Location = new System.Drawing.Point(687, 326);
            this.nmUDPriceSock.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nmUDPriceSock.Name = "nmUDPriceSock";
            this.nmUDPriceSock.Size = new System.Drawing.Size(272, 36);
            this.nmUDPriceSock.TabIndex = 17;
            // 
            // lblSearchPriceSock
            // 
            this.lblSearchPriceSock.AutoSize = true;
            this.lblSearchPriceSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchPriceSock.Location = new System.Drawing.Point(510, 323);
            this.lblSearchPriceSock.Name = "lblSearchPriceSock";
            this.lblSearchPriceSock.Size = new System.Drawing.Size(79, 39);
            this.lblSearchPriceSock.TabIndex = 14;
            this.lblSearchPriceSock.Text = "Giá:";
            // 
            // lblSearchDanhmucSock
            // 
            this.lblSearchDanhmucSock.AutoSize = true;
            this.lblSearchDanhmucSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDanhmucSock.Location = new System.Drawing.Point(510, 256);
            this.lblSearchDanhmucSock.Name = "lblSearchDanhmucSock";
            this.lblSearchDanhmucSock.Size = new System.Drawing.Size(181, 39);
            this.lblSearchDanhmucSock.TabIndex = 12;
            this.lblSearchDanhmucSock.Text = "Danh mục:";
            // 
            // lblSearchNameSock
            // 
            this.lblSearchNameSock.AutoSize = true;
            this.lblSearchNameSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchNameSock.Location = new System.Drawing.Point(510, 187);
            this.lblSearchNameSock.Name = "lblSearchNameSock";
            this.lblSearchNameSock.Size = new System.Drawing.Size(130, 39);
            this.lblSearchNameSock.TabIndex = 10;
            this.lblSearchNameSock.Text = "Tên vớ:";
            // 
            // lblSearchIDSock
            // 
            this.lblSearchIDSock.AutoSize = true;
            this.lblSearchIDSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchIDSock.Location = new System.Drawing.Point(510, 112);
            this.lblSearchIDSock.Name = "lblSearchIDSock";
            this.lblSearchIDSock.Size = new System.Drawing.Size(61, 39);
            this.lblSearchIDSock.TabIndex = 9;
            this.lblSearchIDSock.Text = "ID:";
            // 
            // dataViewSock
            // 
            this.dataViewSock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSock.Location = new System.Drawing.Point(6, 83);
            this.dataViewSock.Name = "dataViewSock";
            this.dataViewSock.RowHeadersWidth = 51;
            this.dataViewSock.RowTemplate.Height = 24;
            this.dataViewSock.Size = new System.Drawing.Size(469, 456);
            this.dataViewSock.TabIndex = 8;
            // 
            // btnSearchSock
            // 
            this.btnSearchSock.Location = new System.Drawing.Point(857, 6);
            this.btnSearchSock.Name = "btnSearchSock";
            this.btnSearchSock.Size = new System.Drawing.Size(99, 71);
            this.btnSearchSock.TabIndex = 7;
            this.btnSearchSock.Text = "Tìm";
            this.btnSearchSock.UseVisualStyleBackColor = true;
            this.btnSearchSock.Click += new System.EventHandler(this.btnSearchSock_Click);
            // 
            // btnShowSock
            // 
            this.btnShowSock.Location = new System.Drawing.Point(352, 8);
            this.btnShowSock.Name = "btnShowSock";
            this.btnShowSock.Size = new System.Drawing.Size(99, 67);
            this.btnShowSock.TabIndex = 6;
            this.btnShowSock.Text = "Kiểm tra hàng";
            this.btnShowSock.UseVisualStyleBackColor = true;
            // 
            // btnEditSock
            // 
            this.btnEditSock.Location = new System.Drawing.Point(237, 6);
            this.btnEditSock.Name = "btnEditSock";
            this.btnEditSock.Size = new System.Drawing.Size(99, 71);
            this.btnEditSock.TabIndex = 5;
            this.btnEditSock.Text = "Sửa đổi thông tin hàng";
            this.btnEditSock.UseVisualStyleBackColor = true;
            // 
            // tpQuan
            // 
            this.tpQuan.Controls.Add(this.btnAddQuan);
            this.tpQuan.Controls.Add(this.btnDeleteQuan);
            this.tpQuan.Controls.Add(this.txbSearchQuan);
            this.tpQuan.Controls.Add(this.cbBDanhmucQuan);
            this.tpQuan.Controls.Add(this.tbxSearchNameQuan);
            this.tpQuan.Controls.Add(this.tbxSearchIDQuan);
            this.tpQuan.Controls.Add(this.nmUDPriceQuan);
            this.tpQuan.Controls.Add(this.lblSearchPriceQuan);
            this.tpQuan.Controls.Add(this.lblSearchDanhmucQuan);
            this.tpQuan.Controls.Add(this.lblSearchNameQuan);
            this.tpQuan.Controls.Add(this.lblSearchIDQuan);
            this.tpQuan.Controls.Add(this.dataViewQuan);
            this.tpQuan.Controls.Add(this.btnSearchQuan);
            this.tpQuan.Controls.Add(this.btnShowQuan);
            this.tpQuan.Controls.Add(this.btnEditQuan);
            this.tpQuan.Location = new System.Drawing.Point(4, 25);
            this.tpQuan.Name = "tpQuan";
            this.tpQuan.Padding = new System.Windows.Forms.Padding(3);
            this.tpQuan.Size = new System.Drawing.Size(962, 584);
            this.tpQuan.TabIndex = 3;
            this.tpQuan.Text = "Quần";
            this.tpQuan.UseVisualStyleBackColor = true;
            this.tpQuan.Click += new System.EventHandler(this.tpQuan_Click);
            // 
            // btnAddQuan
            // 
            this.btnAddQuan.Location = new System.Drawing.Point(6, 6);
            this.btnAddQuan.Name = "btnAddQuan";
            this.btnAddQuan.Size = new System.Drawing.Size(99, 71);
            this.btnAddQuan.TabIndex = 21;
            this.btnAddQuan.Text = "Thêm vào kho hàng";
            this.btnAddQuan.UseVisualStyleBackColor = true;
            this.btnAddQuan.Click += new System.EventHandler(this.btnAddQuan_Click);
            // 
            // btnDeleteQuan
            // 
            this.btnDeleteQuan.Location = new System.Drawing.Point(123, 6);
            this.btnDeleteQuan.Name = "btnDeleteQuan";
            this.btnDeleteQuan.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteQuan.TabIndex = 20;
            this.btnDeleteQuan.Text = "Xóa";
            this.btnDeleteQuan.UseVisualStyleBackColor = true;
            // 
            // txbSearchQuan
            // 
            this.txbSearchQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchQuan.Location = new System.Drawing.Point(576, 22);
            this.txbSearchQuan.Name = "txbSearchQuan";
            this.txbSearchQuan.Size = new System.Drawing.Size(262, 36);
            this.txbSearchQuan.TabIndex = 15;
            // 
            // cbBDanhmucQuan
            // 
            this.cbBDanhmucQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBDanhmucQuan.FormattingEnabled = true;
            this.cbBDanhmucQuan.Location = new System.Drawing.Point(678, 253);
            this.cbBDanhmucQuan.Name = "cbBDanhmucQuan";
            this.cbBDanhmucQuan.Size = new System.Drawing.Size(272, 37);
            this.cbBDanhmucQuan.TabIndex = 19;
            // 
            // tbxSearchNameQuan
            // 
            this.tbxSearchNameQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSearchNameQuan.Location = new System.Drawing.Point(678, 182);
            this.tbxSearchNameQuan.Name = "tbxSearchNameQuan";
            this.tbxSearchNameQuan.Size = new System.Drawing.Size(272, 36);
            this.tbxSearchNameQuan.TabIndex = 18;
            this.tbxSearchNameQuan.TextChanged += new System.EventHandler(this.tbxSearchNameQuan_TextChanged);
            // 
            // tbxSearchIDQuan
            // 
            this.tbxSearchIDQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSearchIDQuan.Location = new System.Drawing.Point(678, 111);
            this.tbxSearchIDQuan.Name = "tbxSearchIDQuan";
            this.tbxSearchIDQuan.ReadOnly = true;
            this.tbxSearchIDQuan.Size = new System.Drawing.Size(272, 36);
            this.tbxSearchIDQuan.TabIndex = 16;
            // 
            // nmUDPriceQuan
            // 
            this.nmUDPriceQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmUDPriceQuan.Location = new System.Drawing.Point(678, 335);
            this.nmUDPriceQuan.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nmUDPriceQuan.Name = "nmUDPriceQuan";
            this.nmUDPriceQuan.Size = new System.Drawing.Size(272, 36);
            this.nmUDPriceQuan.TabIndex = 17;
            // 
            // lblSearchPriceQuan
            // 
            this.lblSearchPriceQuan.AutoSize = true;
            this.lblSearchPriceQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchPriceQuan.Location = new System.Drawing.Point(481, 335);
            this.lblSearchPriceQuan.Name = "lblSearchPriceQuan";
            this.lblSearchPriceQuan.Size = new System.Drawing.Size(79, 39);
            this.lblSearchPriceQuan.TabIndex = 14;
            this.lblSearchPriceQuan.Text = "Giá:";
            // 
            // lblSearchDanhmucQuan
            // 
            this.lblSearchDanhmucQuan.AutoSize = true;
            this.lblSearchDanhmucQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDanhmucQuan.Location = new System.Drawing.Point(481, 253);
            this.lblSearchDanhmucQuan.Name = "lblSearchDanhmucQuan";
            this.lblSearchDanhmucQuan.Size = new System.Drawing.Size(181, 39);
            this.lblSearchDanhmucQuan.TabIndex = 12;
            this.lblSearchDanhmucQuan.Text = "Danh mục:";
            // 
            // lblSearchNameQuan
            // 
            this.lblSearchNameQuan.AutoSize = true;
            this.lblSearchNameQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchNameQuan.Location = new System.Drawing.Point(481, 182);
            this.lblSearchNameQuan.Name = "lblSearchNameQuan";
            this.lblSearchNameQuan.Size = new System.Drawing.Size(170, 39);
            this.lblSearchNameQuan.TabIndex = 10;
            this.lblSearchNameQuan.Text = "Tên quần:";
            // 
            // lblSearchIDQuan
            // 
            this.lblSearchIDQuan.AutoSize = true;
            this.lblSearchIDQuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchIDQuan.Location = new System.Drawing.Point(481, 111);
            this.lblSearchIDQuan.Name = "lblSearchIDQuan";
            this.lblSearchIDQuan.Size = new System.Drawing.Size(61, 39);
            this.lblSearchIDQuan.TabIndex = 9;
            this.lblSearchIDQuan.Text = "ID:";
            // 
            // dataViewQuan
            // 
            this.dataViewQuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewQuan.Location = new System.Drawing.Point(6, 93);
            this.dataViewQuan.Name = "dataViewQuan";
            this.dataViewQuan.RowHeadersWidth = 51;
            this.dataViewQuan.RowTemplate.Height = 24;
            this.dataViewQuan.Size = new System.Drawing.Size(469, 456);
            this.dataViewQuan.TabIndex = 8;
            // 
            // btnSearchQuan
            // 
            this.btnSearchQuan.Location = new System.Drawing.Point(857, 6);
            this.btnSearchQuan.Name = "btnSearchQuan";
            this.btnSearchQuan.Size = new System.Drawing.Size(99, 71);
            this.btnSearchQuan.TabIndex = 7;
            this.btnSearchQuan.Text = "Tìm";
            this.btnSearchQuan.UseVisualStyleBackColor = true;
            // 
            // btnShowQuan
            // 
            this.btnShowQuan.Location = new System.Drawing.Point(365, 6);
            this.btnShowQuan.Name = "btnShowQuan";
            this.btnShowQuan.Size = new System.Drawing.Size(99, 71);
            this.btnShowQuan.TabIndex = 6;
            this.btnShowQuan.Text = "Kiểm tra hàng";
            this.btnShowQuan.UseVisualStyleBackColor = true;
            this.btnShowQuan.Click += new System.EventHandler(this.btnShowQuan_Click);
            // 
            // btnEditQuan
            // 
            this.btnEditQuan.Location = new System.Drawing.Point(244, 6);
            this.btnEditQuan.Name = "btnEditQuan";
            this.btnEditQuan.Size = new System.Drawing.Size(99, 77);
            this.btnEditQuan.TabIndex = 5;
            this.btnEditQuan.Text = "Sửa đổi thông tin hàng";
            this.btnEditQuan.UseVisualStyleBackColor = true;
            // 
            // tpAo
            // 
            this.tpAo.Controls.Add(this.btnAddAo);
            this.tpAo.Controls.Add(this.btnDeleteAo);
            this.tpAo.Controls.Add(this.cbBDanhmucAo);
            this.tpAo.Controls.Add(this.txbSearchNameAo);
            this.tpAo.Controls.Add(this.txbSearchIdAo);
            this.tpAo.Controls.Add(this.txbSearchAo);
            this.tpAo.Controls.Add(this.nmUDPriceAo);
            this.tpAo.Controls.Add(this.lblSearchPriceAo);
            this.tpAo.Controls.Add(this.lblSearchDanhmucAo);
            this.tpAo.Controls.Add(this.lblSearchNameAo);
            this.tpAo.Controls.Add(this.lblSearchIDAo);
            this.tpAo.Controls.Add(this.dataViewAo);
            this.tpAo.Controls.Add(this.btnSearchAo);
            this.tpAo.Controls.Add(this.btnShowAo);
            this.tpAo.Controls.Add(this.btnEditAo);
            this.tpAo.Location = new System.Drawing.Point(4, 25);
            this.tpAo.Name = "tpAo";
            this.tpAo.Padding = new System.Windows.Forms.Padding(3);
            this.tpAo.Size = new System.Drawing.Size(962, 584);
            this.tpAo.TabIndex = 2;
            this.tpAo.Text = "Áo";
            this.tpAo.UseVisualStyleBackColor = true;
            // 
            // btnAddAo
            // 
            this.btnAddAo.Location = new System.Drawing.Point(7, 6);
            this.btnAddAo.Name = "btnAddAo";
            this.btnAddAo.Size = new System.Drawing.Size(99, 71);
            this.btnAddAo.TabIndex = 21;
            this.btnAddAo.Text = "Thêm vào kho hàng";
            this.btnAddAo.UseVisualStyleBackColor = true;
            // 
            // btnDeleteAo
            // 
            this.btnDeleteAo.Location = new System.Drawing.Point(126, 6);
            this.btnDeleteAo.Name = "btnDeleteAo";
            this.btnDeleteAo.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteAo.TabIndex = 20;
            this.btnDeleteAo.Text = "Xóa";
            this.btnDeleteAo.UseVisualStyleBackColor = true;
            // 
            // cbBDanhmucAo
            // 
            this.cbBDanhmucAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBDanhmucAo.FormattingEnabled = true;
            this.cbBDanhmucAo.Location = new System.Drawing.Point(674, 278);
            this.cbBDanhmucAo.Name = "cbBDanhmucAo";
            this.cbBDanhmucAo.Size = new System.Drawing.Size(272, 37);
            this.cbBDanhmucAo.TabIndex = 19;
            // 
            // txbSearchNameAo
            // 
            this.txbSearchNameAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchNameAo.Location = new System.Drawing.Point(674, 196);
            this.txbSearchNameAo.Name = "txbSearchNameAo";
            this.txbSearchNameAo.Size = new System.Drawing.Size(272, 36);
            this.txbSearchNameAo.TabIndex = 18;
            // 
            // txbSearchIdAo
            // 
            this.txbSearchIdAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchIdAo.Location = new System.Drawing.Point(674, 114);
            this.txbSearchIdAo.Name = "txbSearchIdAo";
            this.txbSearchIdAo.ReadOnly = true;
            this.txbSearchIdAo.Size = new System.Drawing.Size(272, 36);
            this.txbSearchIdAo.TabIndex = 16;
            // 
            // txbSearchAo
            // 
            this.txbSearchAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchAo.Location = new System.Drawing.Point(589, 16);
            this.txbSearchAo.Name = "txbSearchAo";
            this.txbSearchAo.Size = new System.Drawing.Size(262, 36);
            this.txbSearchAo.TabIndex = 15;
            this.txbSearchAo.TextChanged += new System.EventHandler(this.txbSearchAo_TextChanged);
            // 
            // nmUDPriceAo
            // 
            this.nmUDPriceAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmUDPriceAo.Location = new System.Drawing.Point(674, 361);
            this.nmUDPriceAo.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nmUDPriceAo.Name = "nmUDPriceAo";
            this.nmUDPriceAo.Size = new System.Drawing.Size(272, 36);
            this.nmUDPriceAo.TabIndex = 17;
            // 
            // lblSearchPriceAo
            // 
            this.lblSearchPriceAo.AutoSize = true;
            this.lblSearchPriceAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchPriceAo.Location = new System.Drawing.Point(482, 361);
            this.lblSearchPriceAo.Name = "lblSearchPriceAo";
            this.lblSearchPriceAo.Size = new System.Drawing.Size(79, 39);
            this.lblSearchPriceAo.TabIndex = 14;
            this.lblSearchPriceAo.Text = "Giá:";
            // 
            // lblSearchDanhmucAo
            // 
            this.lblSearchDanhmucAo.AutoSize = true;
            this.lblSearchDanhmucAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDanhmucAo.Location = new System.Drawing.Point(482, 278);
            this.lblSearchDanhmucAo.Name = "lblSearchDanhmucAo";
            this.lblSearchDanhmucAo.Size = new System.Drawing.Size(181, 39);
            this.lblSearchDanhmucAo.TabIndex = 12;
            this.lblSearchDanhmucAo.Text = "Danh mục:";
            // 
            // lblSearchNameAo
            // 
            this.lblSearchNameAo.AutoSize = true;
            this.lblSearchNameAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchNameAo.Location = new System.Drawing.Point(482, 196);
            this.lblSearchNameAo.Name = "lblSearchNameAo";
            this.lblSearchNameAo.Size = new System.Drawing.Size(132, 39);
            this.lblSearchNameAo.TabIndex = 10;
            this.lblSearchNameAo.Text = "Tên áo:";
            // 
            // lblSearchIDAo
            // 
            this.lblSearchIDAo.AutoSize = true;
            this.lblSearchIDAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchIDAo.Location = new System.Drawing.Point(482, 114);
            this.lblSearchIDAo.Name = "lblSearchIDAo";
            this.lblSearchIDAo.Size = new System.Drawing.Size(61, 39);
            this.lblSearchIDAo.TabIndex = 9;
            this.lblSearchIDAo.Text = "ID:";
            // 
            // dataViewAo
            // 
            this.dataViewAo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewAo.Location = new System.Drawing.Point(7, 96);
            this.dataViewAo.Name = "dataViewAo";
            this.dataViewAo.RowHeadersWidth = 51;
            this.dataViewAo.RowTemplate.Height = 24;
            this.dataViewAo.Size = new System.Drawing.Size(469, 456);
            this.dataViewAo.TabIndex = 8;
            // 
            // btnSearchAo
            // 
            this.btnSearchAo.Location = new System.Drawing.Point(857, 6);
            this.btnSearchAo.Name = "btnSearchAo";
            this.btnSearchAo.Size = new System.Drawing.Size(99, 71);
            this.btnSearchAo.TabIndex = 7;
            this.btnSearchAo.Text = "Tìm";
            this.btnSearchAo.UseVisualStyleBackColor = true;
            this.btnSearchAo.Click += new System.EventHandler(this.btnSearchAo_Click);
            // 
            // btnShowAo
            // 
            this.btnShowAo.Location = new System.Drawing.Point(377, 3);
            this.btnShowAo.Name = "btnShowAo";
            this.btnShowAo.Size = new System.Drawing.Size(99, 71);
            this.btnShowAo.TabIndex = 6;
            this.btnShowAo.Text = "Kiểm tra hàng";
            this.btnShowAo.UseVisualStyleBackColor = true;
            // 
            // btnEditAo
            // 
            this.btnEditAo.Location = new System.Drawing.Point(250, 6);
            this.btnEditAo.Name = "btnEditAo";
            this.btnEditAo.Size = new System.Drawing.Size(99, 71);
            this.btnEditAo.TabIndex = 5;
            this.btnEditAo.Text = "Sửa đổi thông tin hàng";
            this.btnEditAo.UseVisualStyleBackColor = true;
            // 
            // lblSpriceHat
            // 
            this.lblSpriceHat.Controls.Add(this.nmUDPriceHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchPriceHat);
            this.lblSpriceHat.Controls.Add(this.cbBDanhmucHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchDanhmucHat);
            this.lblSpriceHat.Controls.Add(this.txbSearchNameHat);
            this.lblSpriceHat.Controls.Add(this.txbIDHat);
            this.lblSpriceHat.Controls.Add(this.txbSearchHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchNameHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchIDHat);
            this.lblSpriceHat.Controls.Add(this.btnSearchHat);
            this.lblSpriceHat.Controls.Add(this.btnShowHat);
            this.lblSpriceHat.Controls.Add(this.btnEditHat);
            this.lblSpriceHat.Controls.Add(this.btnDeleteHat);
            this.lblSpriceHat.Controls.Add(this.btnAddHat);
            this.lblSpriceHat.Controls.Add(this.dataViewHat);
            this.lblSpriceHat.Location = new System.Drawing.Point(4, 25);
            this.lblSpriceHat.Name = "lblSpriceHat";
            this.lblSpriceHat.Padding = new System.Windows.Forms.Padding(3);
            this.lblSpriceHat.Size = new System.Drawing.Size(962, 580);
            this.lblSpriceHat.TabIndex = 1;
            this.lblSpriceHat.Text = "Nón";
            this.lblSpriceHat.UseVisualStyleBackColor = true;
            this.lblSpriceHat.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // nmUDPriceHat
            // 
            this.nmUDPriceHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmUDPriceHat.Location = new System.Drawing.Point(684, 334);
            this.nmUDPriceHat.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nmUDPriceHat.Name = "nmUDPriceHat";
            this.nmUDPriceHat.Size = new System.Drawing.Size(272, 36);
            this.nmUDPriceHat.TabIndex = 14;
            // 
            // lblSearchPriceHat
            // 
            this.lblSearchPriceHat.AutoSize = true;
            this.lblSearchPriceHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchPriceHat.Location = new System.Drawing.Point(497, 334);
            this.lblSearchPriceHat.Name = "lblSearchPriceHat";
            this.lblSearchPriceHat.Size = new System.Drawing.Size(79, 39);
            this.lblSearchPriceHat.TabIndex = 13;
            this.lblSearchPriceHat.Text = "Giá:";
            // 
            // cbBDanhmucHat
            // 
            this.cbBDanhmucHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBDanhmucHat.FormattingEnabled = true;
            this.cbBDanhmucHat.Location = new System.Drawing.Point(684, 258);
            this.cbBDanhmucHat.Name = "cbBDanhmucHat";
            this.cbBDanhmucHat.Size = new System.Drawing.Size(272, 37);
            this.cbBDanhmucHat.TabIndex = 12;
            // 
            // lblSearchDanhmucHat
            // 
            this.lblSearchDanhmucHat.AutoSize = true;
            this.lblSearchDanhmucHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDanhmucHat.Location = new System.Drawing.Point(497, 258);
            this.lblSearchDanhmucHat.Name = "lblSearchDanhmucHat";
            this.lblSearchDanhmucHat.Size = new System.Drawing.Size(181, 39);
            this.lblSearchDanhmucHat.TabIndex = 11;
            this.lblSearchDanhmucHat.Text = "Danh mục:";
            this.lblSearchDanhmucHat.Click += new System.EventHandler(this.label2_Click);
            // 
            // txbSearchNameHat
            // 
            this.txbSearchNameHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchNameHat.Location = new System.Drawing.Point(684, 183);
            this.txbSearchNameHat.Name = "txbSearchNameHat";
            this.txbSearchNameHat.Size = new System.Drawing.Size(272, 36);
            this.txbSearchNameHat.TabIndex = 10;
            // 
            // txbIDHat
            // 
            this.txbIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDHat.Location = new System.Drawing.Point(684, 104);
            this.txbIDHat.Name = "txbIDHat";
            this.txbIDHat.ReadOnly = true;
            this.txbIDHat.Size = new System.Drawing.Size(272, 36);
            this.txbIDHat.TabIndex = 8;
            this.txbIDHat.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txbSearchHat
            // 
            this.txbSearchHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchHat.Location = new System.Drawing.Point(579, 23);
            this.txbSearchHat.Name = "txbSearchHat";
            this.txbSearchHat.Size = new System.Drawing.Size(262, 36);
            this.txbSearchHat.TabIndex = 6;
            // 
            // lblSearchNameHat
            // 
            this.lblSearchNameHat.AutoSize = true;
            this.lblSearchNameHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchNameHat.Location = new System.Drawing.Point(497, 183);
            this.lblSearchNameHat.Name = "lblSearchNameHat";
            this.lblSearchNameHat.Size = new System.Drawing.Size(151, 39);
            this.lblSearchNameHat.TabIndex = 9;
            this.lblSearchNameHat.Text = "Tên nón:";
            // 
            // lblSearchIDHat
            // 
            this.lblSearchIDHat.AutoSize = true;
            this.lblSearchIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchIDHat.Location = new System.Drawing.Point(497, 104);
            this.lblSearchIDHat.Name = "lblSearchIDHat";
            this.lblSearchIDHat.Size = new System.Drawing.Size(61, 39);
            this.lblSearchIDHat.TabIndex = 7;
            this.lblSearchIDHat.Text = "ID:";
            this.lblSearchIDHat.Click += new System.EventHandler(this.lblID_Click);
            // 
            // btnSearchHat
            // 
            this.btnSearchHat.Location = new System.Drawing.Point(857, 6);
            this.btnSearchHat.Name = "btnSearchHat";
            this.btnSearchHat.Size = new System.Drawing.Size(99, 71);
            this.btnSearchHat.TabIndex = 5;
            this.btnSearchHat.Text = "Tìm";
            this.btnSearchHat.UseVisualStyleBackColor = true;
            // 
            // btnShowHat
            // 
            this.btnShowHat.Location = new System.Drawing.Point(376, 6);
            this.btnShowHat.Name = "btnShowHat";
            this.btnShowHat.Size = new System.Drawing.Size(99, 71);
            this.btnShowHat.TabIndex = 4;
            this.btnShowHat.Text = "Kiểm tra hàng";
            this.btnShowHat.UseVisualStyleBackColor = true;
            this.btnShowHat.Click += new System.EventHandler(this.btnShowHat_Click);
            // 
            // btnEditHat
            // 
            this.btnEditHat.Location = new System.Drawing.Point(251, 6);
            this.btnEditHat.Name = "btnEditHat";
            this.btnEditHat.Size = new System.Drawing.Size(99, 71);
            this.btnEditHat.TabIndex = 3;
            this.btnEditHat.Text = "Sửa đổi thông tin hàng";
            this.btnEditHat.UseVisualStyleBackColor = true;
            // 
            // btnDeleteHat
            // 
            this.btnDeleteHat.Location = new System.Drawing.Point(129, 6);
            this.btnDeleteHat.Name = "btnDeleteHat";
            this.btnDeleteHat.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteHat.TabIndex = 2;
            this.btnDeleteHat.Text = "Xóa";
            this.btnDeleteHat.UseVisualStyleBackColor = true;
            // 
            // btnAddHat
            // 
            this.btnAddHat.Location = new System.Drawing.Point(6, 6);
            this.btnAddHat.Name = "btnAddHat";
            this.btnAddHat.Size = new System.Drawing.Size(99, 71);
            this.btnAddHat.TabIndex = 1;
            this.btnAddHat.Text = "Thêm vào kho hàng";
            this.btnAddHat.UseVisualStyleBackColor = true;
            this.btnAddHat.Click += new System.EventHandler(this.btnAddHat_Click);
            // 
            // dataViewHat
            // 
            this.dataViewHat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewHat.Location = new System.Drawing.Point(6, 104);
            this.dataViewHat.Name = "dataViewHat";
            this.dataViewHat.RowHeadersWidth = 51;
            this.dataViewHat.RowTemplate.Height = 24;
            this.dataViewHat.Size = new System.Drawing.Size(469, 456);
            this.dataViewHat.TabIndex = 0;
            // 
            // tbDoanhthu
            // 
            this.tbDoanhthu.Controls.Add(this.btnThongKeTienLai);
            this.tbDoanhthu.Controls.Add(this.textBox2);
            this.tbDoanhthu.Controls.Add(this.textBox1);
            this.tbDoanhthu.Controls.Add(this.lblMoney);
            this.tbDoanhthu.Controls.Add(this.lblLai);
            this.tbDoanhthu.Controls.Add(this.btnThongKeDoanhThu);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker4);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker3);
            this.tbDoanhthu.Controls.Add(this.dataGridView2);
            this.tbDoanhthu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDoanhthu.Location = new System.Drawing.Point(4, 25);
            this.tbDoanhthu.Name = "tbDoanhthu";
            this.tbDoanhthu.Padding = new System.Windows.Forms.Padding(3);
            this.tbDoanhthu.Size = new System.Drawing.Size(962, 580);
            this.tbDoanhthu.TabIndex = 0;
            this.tbDoanhthu.Text = "Doanh thu";
            this.tbDoanhthu.UseVisualStyleBackColor = true;
            this.tbDoanhthu.Click += new System.EventHandler(this.tbDoanhthu_Click);
            // 
            // btnThongKeTienLai
            // 
            this.btnThongKeTienLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeTienLai.Location = new System.Drawing.Point(544, 60);
            this.btnThongKeTienLai.Name = "btnThongKeTienLai";
            this.btnThongKeTienLai.Size = new System.Drawing.Size(140, 70);
            this.btnThongKeTienLai.TabIndex = 9;
            this.btnThongKeTienLai.Text = "Tra cứu doanh thu";
            this.btnThongKeTienLai.UseVisualStyleBackColor = true;
            this.btnThongKeTienLai.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(856, 109);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 27);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(856, 60);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 27);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // lblMoney
            // 
            this.lblMoney.AutoSize = true;
            this.lblMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoney.Location = new System.Drawing.Point(690, 101);
            this.lblMoney.Name = "lblMoney";
            this.lblMoney.Size = new System.Drawing.Size(166, 29);
            this.lblMoney.TabIndex = 6;
            this.lblMoney.Text = "Tiền thu được";
            // 
            // lblLai
            // 
            this.lblLai.AutoSize = true;
            this.lblLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLai.Location = new System.Drawing.Point(690, 60);
            this.lblLai.Name = "lblLai";
            this.lblLai.Size = new System.Drawing.Size(47, 29);
            this.lblLai.TabIndex = 5;
            this.lblLai.Text = "Lãi";
            // 
            // btnThongKeDoanhThu
            // 
            this.btnThongKeDoanhThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeDoanhThu.Location = new System.Drawing.Point(356, 9);
            this.btnThongKeDoanhThu.Name = "btnThongKeDoanhThu";
            this.btnThongKeDoanhThu.Size = new System.Drawing.Size(116, 57);
            this.btnThongKeDoanhThu.TabIndex = 4;
            this.btnThongKeDoanhThu.Text = "Thống kê hàng đã bán";
            this.btnThongKeDoanhThu.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Location = new System.Drawing.Point(590, 12);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(327, 30);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(18, 11);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(330, 30);
            this.dateTimePicker3.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(18, 72);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(454, 424);
            this.dataGridView2.TabIndex = 1;
            // 
            // tb9
            // 
            this.tb9.Controls.Add(this.tbDoanhthu);
            this.tb9.Controls.Add(this.lblSpriceHat);
            this.tb9.Controls.Add(this.tpAo);
            this.tb9.Controls.Add(this.tpQuan);
            this.tb9.Controls.Add(this.tpSock);
            this.tb9.Controls.Add(this.tbHangTonKho);
            this.tb9.Controls.Add(this.tabPage1);
            this.tb9.Location = new System.Drawing.Point(42, 27);
            this.tb9.Name = "tb9";
            this.tb9.SelectedIndex = 0;
            this.tb9.Size = new System.Drawing.Size(970, 613);
            this.tb9.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(962, 580);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnOutAdmin
            // 
            this.btnOutAdmin.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnOutAdmin.Location = new System.Drawing.Point(929, 647);
            this.btnOutAdmin.Name = "btnOutAdmin";
            this.btnOutAdmin.Size = new System.Drawing.Size(115, 74);
            this.btnOutAdmin.TabIndex = 13;
            this.btnOutAdmin.Text = "Thoát";
            this.btnOutAdmin.UseVisualStyleBackColor = true;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1101, 733);
            this.Controls.Add(this.btnOutAdmin);
            this.Controls.Add(this.tb9);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.tbHangTonKho.ResumeLayout(false);
            this.tbHangTonKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewẾ)).EndInit();
            this.tpSock.ResumeLayout(false);
            this.tpSock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceSock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).EndInit();
            this.tpQuan.ResumeLayout(false);
            this.tpQuan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).EndInit();
            this.tpAo.ResumeLayout(false);
            this.tpAo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceAo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).EndInit();
            this.lblSpriceHat.ResumeLayout(false);
            this.lblSpriceHat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceHat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).EndInit();
            this.tbDoanhthu.ResumeLayout(false);
            this.tbDoanhthu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tb9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tbHangTonKho;
        private System.Windows.Forms.Button btnSearchHangE;
        private System.Windows.Forms.TextBox txbSearchHangE;
        private System.Windows.Forms.Button btnShowHangE;
        private System.Windows.Forms.Button btnEditHangE;
        private System.Windows.Forms.Button btnDeleteHangE;
        private System.Windows.Forms.Button btnAddHangE;
        private System.Windows.Forms.DataGridView dataViewẾ;
        private System.Windows.Forms.TabPage tpSock;
        private System.Windows.Forms.Button btAddSock;
        private System.Windows.Forms.Button btnDeleteSock;
        private System.Windows.Forms.ComboBox cbBDanhmucSock;
        private System.Windows.Forms.TextBox tbxSearchNameSock;
        private System.Windows.Forms.TextBox tbxSearchIdSock;
        private System.Windows.Forms.TextBox txbSearchSock;
        private System.Windows.Forms.NumericUpDown nmUDPriceSock;
        private System.Windows.Forms.Label lblSearchPriceSock;
        private System.Windows.Forms.Label lblSearchDanhmucSock;
        private System.Windows.Forms.Label lblSearchNameSock;
        private System.Windows.Forms.Label lblSearchIDSock;
        private System.Windows.Forms.DataGridView dataViewSock;
        private System.Windows.Forms.Button btnSearchSock;
        private System.Windows.Forms.Button btnShowSock;
        private System.Windows.Forms.Button btnEditSock;
        private System.Windows.Forms.TabPage tpQuan;
        private System.Windows.Forms.Button btnAddQuan;
        private System.Windows.Forms.Button btnDeleteQuan;
        private System.Windows.Forms.ComboBox cbBDanhmucQuan;
        private System.Windows.Forms.TextBox tbxSearchNameQuan;
        private System.Windows.Forms.TextBox tbxSearchIDQuan;
        private System.Windows.Forms.TextBox txbSearchQuan;
        private System.Windows.Forms.NumericUpDown nmUDPriceQuan;
        private System.Windows.Forms.Label lblSearchPriceQuan;
        private System.Windows.Forms.Label lblSearchDanhmucQuan;
        private System.Windows.Forms.Label lblSearchNameQuan;
        private System.Windows.Forms.Label lblSearchIDQuan;
        private System.Windows.Forms.DataGridView dataViewQuan;
        private System.Windows.Forms.Button btnSearchQuan;
        private System.Windows.Forms.Button btnShowQuan;
        private System.Windows.Forms.Button btnEditQuan;
        private System.Windows.Forms.TabPage tpAo;
        private System.Windows.Forms.Button btnAddAo;
        private System.Windows.Forms.Button btnDeleteAo;
        private System.Windows.Forms.ComboBox cbBDanhmucAo;
        private System.Windows.Forms.TextBox txbSearchNameAo;
        private System.Windows.Forms.TextBox txbSearchIdAo;
        private System.Windows.Forms.TextBox txbSearchAo;
        private System.Windows.Forms.NumericUpDown nmUDPriceAo;
        private System.Windows.Forms.Label lblSearchPriceAo;
        private System.Windows.Forms.Label lblSearchDanhmucAo;
        private System.Windows.Forms.Label lblSearchNameAo;
        private System.Windows.Forms.Label lblSearchIDAo;
        private System.Windows.Forms.DataGridView dataViewAo;
        private System.Windows.Forms.Button btnSearchAo;
        private System.Windows.Forms.Button btnShowAo;
        private System.Windows.Forms.Button btnEditAo;
        private System.Windows.Forms.TabPage lblSpriceHat;
        private System.Windows.Forms.NumericUpDown nmUDPriceHat;
        private System.Windows.Forms.Label lblSearchPriceHat;
        private System.Windows.Forms.ComboBox cbBDanhmucHat;
        private System.Windows.Forms.Label lblSearchDanhmucHat;
        private System.Windows.Forms.TextBox txbSearchNameHat;
        private System.Windows.Forms.TextBox txbIDHat;
        private System.Windows.Forms.TextBox txbSearchHat;
        private System.Windows.Forms.Label lblSearchNameHat;
        private System.Windows.Forms.Label lblSearchIDHat;
        private System.Windows.Forms.Button btnSearchHat;
        private System.Windows.Forms.Button btnShowHat;
        private System.Windows.Forms.Button btnEditHat;
        private System.Windows.Forms.Button btnDeleteHat;
        private System.Windows.Forms.Button btnAddHat;
        private System.Windows.Forms.DataGridView dataViewHat;
        private System.Windows.Forms.TabPage tbDoanhthu;
        private System.Windows.Forms.Button btnThongKeDoanhThu;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabControl tb9;
        private System.Windows.Forms.ComboBox cbBSearchHangTonKho;
        private System.Windows.Forms.Label lblSearchLoaiHTKho;
        private System.Windows.Forms.Button btnOutAdmin;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblMoney;
        private System.Windows.Forms.Label lblLai;
        private System.Windows.Forms.Button btnThongKeTienLai;
        private System.Windows.Forms.TabPage tabPage1;
    }
}