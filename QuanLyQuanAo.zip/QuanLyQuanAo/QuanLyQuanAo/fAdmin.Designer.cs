﻿namespace QuanLyQuanAo
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOutAdmin = new System.Windows.Forms.Button();
            this.tbHangTonKho = new System.Windows.Forms.TabPage();
            this.cbBSearchLoaiSale = new System.Windows.Forms.ComboBox();
            this.cbBSearchSizeSale = new System.Windows.Forms.ComboBox();
            this.cbBSearchKDSale = new System.Windows.Forms.ComboBox();
            this.dataViewSearchSale = new System.Windows.Forms.DataGridView();
            this.btnSearchHangE = new System.Windows.Forms.Button();
            this.btnDeleteHangE = new System.Windows.Forms.Button();
            this.btnAddHangE = new System.Windows.Forms.Button();
            this.dataViewSale = new System.Windows.Forms.DataGridView();
            this.tpSock = new System.Windows.Forms.TabPage();
            this.label29 = new System.Windows.Forms.Label();
            this.txbPriceSock = new System.Windows.Forms.TextBox();
            this.txbKDSock = new System.Windows.Forms.TextBox();
            this.txbSLSock = new System.Windows.Forms.TextBox();
            this.txbSizeSock = new System.Windows.Forms.TextBox();
            this.txbNameSock = new System.Windows.Forms.TextBox();
            this.txbIDSock = new System.Windows.Forms.TextBox();
            this.dateTimeSock = new System.Windows.Forms.DateTimePicker();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnCancelSock = new System.Windows.Forms.Button();
            this.btnChangeSock = new System.Windows.Forms.Button();
            this.cbBSearchKDSock = new System.Windows.Forms.ComboBox();
            this.dataViewSearchSock = new System.Windows.Forms.DataGridView();
            this.btnAddSock = new System.Windows.Forms.Button();
            this.btnDeleteSock = new System.Windows.Forms.Button();
            this.dataViewSock = new System.Windows.Forms.DataGridView();
            this.btnSearchSock = new System.Windows.Forms.Button();
            this.tpQuan = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txbPriceQ = new System.Windows.Forms.TextBox();
            this.txbKDQ = new System.Windows.Forms.TextBox();
            this.txbSLQ = new System.Windows.Forms.TextBox();
            this.txbSizeQ = new System.Windows.Forms.TextBox();
            this.txbNameQ = new System.Windows.Forms.TextBox();
            this.dateTimeNhapQ = new System.Windows.Forms.DateTimePicker();
            this.txbIDQ = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnCancelQ = new System.Windows.Forms.Button();
            this.btnChangeQ = new System.Windows.Forms.Button();
            this.cbBSearchSizeQ = new System.Windows.Forms.ComboBox();
            this.cbBSearchKieuDangQ = new System.Windows.Forms.ComboBox();
            this.dataViewSearchQuan = new System.Windows.Forms.DataGridView();
            this.btnAddQ = new System.Windows.Forms.Button();
            this.btnDeleteQ = new System.Windows.Forms.Button();
            this.dataViewQuan = new System.Windows.Forms.DataGridView();
            this.btnSearchQuan = new System.Windows.Forms.Button();
            this.tpAo = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txbAddIDAo = new System.Windows.Forms.TextBox();
            this.dataViewAo = new System.Windows.Forms.DataGridView();
            this.txbPriceAo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txbKieuDangAo = new System.Windows.Forms.TextBox();
            this.dateTimeAddAo = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txbSLAddAo = new System.Windows.Forms.TextBox();
            this.txbNameAo = new System.Windows.Forms.TextBox();
            this.txbSizeAo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbBSearchKDAo = new System.Windows.Forms.ComboBox();
            this.cbBSearchSizeAo = new System.Windows.Forms.ComboBox();
            this.lblSearchSizeAo = new System.Windows.Forms.Label();
            this.lblSearchKDAo = new System.Windows.Forms.Label();
            this.dataViewSearchAo = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAddAo = new System.Windows.Forms.Button();
            this.btnDeleteAo = new System.Windows.Forms.Button();
            this.btnChangeAo = new System.Windows.Forms.Button();
            this.btnCancelAo = new System.Windows.Forms.Button();
            this.btnSearchAo = new System.Windows.Forms.Button();
            this.tb9 = new System.Windows.Forms.TabControl();
            this.tbDoanhthu = new System.Windows.Forms.TabPage();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnThongKeTienLai = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblMoney = new System.Windows.Forms.Label();
            this.lblLai = new System.Windows.Forms.Label();
            this.btnThongKeDoanhThu = new System.Windows.Forms.Button();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dataViewDSBill = new System.Windows.Forms.DataGridView();
            this.lblSpriceHat = new System.Windows.Forms.TabPage();
            this.label30 = new System.Windows.Forms.Label();
            this.txbSizeHat = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimeNhapHat = new System.Windows.Forms.DateTimePicker();
            this.txbPriceHat = new System.Windows.Forms.TextBox();
            this.txbKDHat = new System.Windows.Forms.TextBox();
            this.txbSLHat = new System.Windows.Forms.TextBox();
            this.txbNameHat = new System.Windows.Forms.TextBox();
            this.txbIDHat = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lblIDHat = new System.Windows.Forms.Label();
            this.btnCancelHat = new System.Windows.Forms.Button();
            this.dâtViewSearchHat = new System.Windows.Forms.DataGridView();
            this.txbSearchHat = new System.Windows.Forms.TextBox();
            this.btnSearchHat = new System.Windows.Forms.Button();
            this.btnChangeHat = new System.Windows.Forms.Button();
            this.btnDeleteHat = new System.Windows.Forms.Button();
            this.btnAddHat = new System.Windows.Forms.Button();
            this.dataViewHat = new System.Windows.Forms.DataGridView();
            this.tbHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSale)).BeginInit();
            this.tpSock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).BeginInit();
            this.tpQuan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).BeginInit();
            this.tpAo.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchAo)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tb9.SuspendLayout();
            this.tbDoanhthu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewDSBill)).BeginInit();
            this.lblSpriceHat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dâtViewSearchHat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOutAdmin
            // 
            this.btnOutAdmin.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnOutAdmin.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnOutAdmin.ForeColor = System.Drawing.SystemColors.Control;
            this.btnOutAdmin.Location = new System.Drawing.Point(1071, 713);
            this.btnOutAdmin.Name = "btnOutAdmin";
            this.btnOutAdmin.Size = new System.Drawing.Size(140, 70);
            this.btnOutAdmin.TabIndex = 13;
            this.btnOutAdmin.Text = "Thoát";
            this.btnOutAdmin.UseVisualStyleBackColor = false;
            this.btnOutAdmin.Click += new System.EventHandler(this.btnOutAdmin_Click);
            // 
            // tbHangTonKho
            // 
            this.tbHangTonKho.Controls.Add(this.cbBSearchLoaiSale);
            this.tbHangTonKho.Controls.Add(this.cbBSearchSizeSale);
            this.tbHangTonKho.Controls.Add(this.cbBSearchKDSale);
            this.tbHangTonKho.Controls.Add(this.dataViewSearchSale);
            this.tbHangTonKho.Controls.Add(this.btnSearchHangE);
            this.tbHangTonKho.Controls.Add(this.btnDeleteHangE);
            this.tbHangTonKho.Controls.Add(this.btnAddHangE);
            this.tbHangTonKho.Controls.Add(this.dataViewSale);
            this.tbHangTonKho.Location = new System.Drawing.Point(4, 25);
            this.tbHangTonKho.Name = "tbHangTonKho";
            this.tbHangTonKho.Padding = new System.Windows.Forms.Padding(3);
            this.tbHangTonKho.Size = new System.Drawing.Size(1191, 650);
            this.tbHangTonKho.TabIndex = 5;
            this.tbHangTonKho.Text = "Hàng tồn kho";
            this.tbHangTonKho.UseVisualStyleBackColor = true;
            this.tbHangTonKho.Click += new System.EventHandler(this.tbHangTonKho_Click);
            // 
            // cbBSearchLoaiSale
            // 
            this.cbBSearchLoaiSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchLoaiSale.FormattingEnabled = true;
            this.cbBSearchLoaiSale.Items.AddRange(new object[] {
            "Non(tất cả có chung size M)",
            "Ao",
            "Quan",
            "Vớ(tất cả có chung size M)"});
            this.cbBSearchLoaiSale.Location = new System.Drawing.Point(119, 582);
            this.cbBSearchLoaiSale.Name = "cbBSearchLoaiSale";
            this.cbBSearchLoaiSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchLoaiSale.TabIndex = 41;
            // 
            // cbBSearchSizeSale
            // 
            this.cbBSearchSizeSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSizeSale.FormattingEnabled = true;
            this.cbBSearchSizeSale.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cbBSearchSizeSale.Location = new System.Drawing.Point(119, 516);
            this.cbBSearchSizeSale.Name = "cbBSearchSizeSale";
            this.cbBSearchSizeSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchSizeSale.TabIndex = 40;
            // 
            // cbBSearchKDSale
            // 
            this.cbBSearchKDSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKDSale.FormattingEnabled = true;
            this.cbBSearchKDSale.Items.AddRange(new object[] {
            "Nam",
            "Nu"});
            this.cbBSearchKDSale.Location = new System.Drawing.Point(119, 452);
            this.cbBSearchKDSale.Name = "cbBSearchKDSale";
            this.cbBSearchKDSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchKDSale.TabIndex = 29;
            this.cbBSearchKDSale.SelectedIndexChanged += new System.EventHandler(this.cbBSearchKDSale_SelectedIndexChanged);
            // 
            // dataViewSearchSale
            // 
            this.dataViewSearchSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchSale.Location = new System.Drawing.Point(580, 452);
            this.dataViewSearchSale.Name = "dataViewSearchSale";
            this.dataViewSearchSale.RowHeadersWidth = 51;
            this.dataViewSearchSale.RowTemplate.Height = 24;
            this.dataViewSearchSale.Size = new System.Drawing.Size(547, 164);
            this.dataViewSearchSale.TabIndex = 28;
            this.dataViewSearchSale.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewSearchSale_CellContentClick);
            // 
            // btnSearchHangE
            // 
            this.btnSearchHangE.Location = new System.Drawing.Point(6, 452);
            this.btnSearchHangE.Name = "btnSearchHangE";
            this.btnSearchHangE.Size = new System.Drawing.Size(99, 164);
            this.btnSearchHangE.TabIndex = 27;
            this.btnSearchHangE.Text = "Tìm";
            this.btnSearchHangE.UseVisualStyleBackColor = true;
            this.btnSearchHangE.Click += new System.EventHandler(this.btnSearchHangE_Click);
            // 
            // btnDeleteHangE
            // 
            this.btnDeleteHangE.Location = new System.Drawing.Point(6, 219);
            this.btnDeleteHangE.Name = "btnDeleteHangE";
            this.btnDeleteHangE.Size = new System.Drawing.Size(109, 71);
            this.btnDeleteHangE.TabIndex = 23;
            this.btnDeleteHangE.Text = "Xóa";
            this.btnDeleteHangE.UseVisualStyleBackColor = true;
            this.btnDeleteHangE.Click += new System.EventHandler(this.btnDeleteHangE_Click);
            // 
            // btnAddHangE
            // 
            this.btnAddHangE.Location = new System.Drawing.Point(6, 6);
            this.btnAddHangE.Name = "btnAddHangE";
            this.btnAddHangE.Size = new System.Drawing.Size(99, 71);
            this.btnAddHangE.TabIndex = 22;
            this.btnAddHangE.Text = "Thêm hàng tồn kho";
            this.btnAddHangE.UseVisualStyleBackColor = true;
            // 
            // dataViewSale
            // 
            this.dataViewSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSale.Location = new System.Drawing.Point(580, 6);
            this.dataViewSale.Name = "dataViewSale";
            this.dataViewSale.RowHeadersWidth = 51;
            this.dataViewSale.RowTemplate.Height = 24;
            this.dataViewSale.Size = new System.Drawing.Size(556, 257);
            this.dataViewSale.TabIndex = 9;
            // 
            // tpSock
            // 
            this.tpSock.Controls.Add(this.label29);
            this.tpSock.Controls.Add(this.txbPriceSock);
            this.tpSock.Controls.Add(this.txbKDSock);
            this.tpSock.Controls.Add(this.txbSLSock);
            this.tpSock.Controls.Add(this.txbSizeSock);
            this.tpSock.Controls.Add(this.txbNameSock);
            this.tpSock.Controls.Add(this.txbIDSock);
            this.tpSock.Controls.Add(this.dateTimeSock);
            this.tpSock.Controls.Add(this.label28);
            this.tpSock.Controls.Add(this.label27);
            this.tpSock.Controls.Add(this.label26);
            this.tpSock.Controls.Add(this.label25);
            this.tpSock.Controls.Add(this.label24);
            this.tpSock.Controls.Add(this.label23);
            this.tpSock.Controls.Add(this.label22);
            this.tpSock.Controls.Add(this.btnCancelSock);
            this.tpSock.Controls.Add(this.btnChangeSock);
            this.tpSock.Controls.Add(this.cbBSearchKDSock);
            this.tpSock.Controls.Add(this.dataViewSearchSock);
            this.tpSock.Controls.Add(this.btnAddSock);
            this.tpSock.Controls.Add(this.btnDeleteSock);
            this.tpSock.Controls.Add(this.dataViewSock);
            this.tpSock.Controls.Add(this.btnSearchSock);
            this.tpSock.Location = new System.Drawing.Point(4, 25);
            this.tpSock.Name = "tpSock";
            this.tpSock.Padding = new System.Windows.Forms.Padding(3);
            this.tpSock.Size = new System.Drawing.Size(1191, 650);
            this.tpSock.TabIndex = 4;
            this.tpSock.Text = "Vớ";
            this.tpSock.UseVisualStyleBackColor = true;
            this.tpSock.Click += new System.EventHandler(this.tpSock_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label29.Location = new System.Drawing.Point(130, 520);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(148, 25);
            this.label29.TabIndex = 68;
            this.label29.Text = "Theo kiểu dáng";
            // 
            // txbPriceSock
            // 
            this.txbPriceSock.Enabled = false;
            this.txbPriceSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPriceSock.Location = new System.Drawing.Point(295, 429);
            this.txbPriceSock.Name = "txbPriceSock";
            this.txbPriceSock.Size = new System.Drawing.Size(350, 30);
            this.txbPriceSock.TabIndex = 67;
            this.txbPriceSock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbPriceSock_KeyPress);
            // 
            // txbKDSock
            // 
            this.txbKDSock.Enabled = false;
            this.txbKDSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbKDSock.Location = new System.Drawing.Point(295, 355);
            this.txbKDSock.Name = "txbKDSock";
            this.txbKDSock.Size = new System.Drawing.Size(350, 30);
            this.txbKDSock.TabIndex = 66;
            this.txbKDSock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbKDSock_KeyPress);
            // 
            // txbSLSock
            // 
            this.txbSLSock.Enabled = false;
            this.txbSLSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSLSock.Location = new System.Drawing.Point(295, 287);
            this.txbSLSock.Name = "txbSLSock";
            this.txbSLSock.Size = new System.Drawing.Size(350, 30);
            this.txbSLSock.TabIndex = 65;
            this.txbSLSock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbSLSock_KeyPress);
            // 
            // txbSizeSock
            // 
            this.txbSizeSock.Enabled = false;
            this.txbSizeSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSizeSock.Location = new System.Drawing.Point(295, 218);
            this.txbSizeSock.Name = "txbSizeSock";
            this.txbSizeSock.Size = new System.Drawing.Size(350, 30);
            this.txbSizeSock.TabIndex = 64;
            // 
            // txbNameSock
            // 
            this.txbNameSock.Enabled = false;
            this.txbNameSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNameSock.Location = new System.Drawing.Point(295, 146);
            this.txbNameSock.Name = "txbNameSock";
            this.txbNameSock.Size = new System.Drawing.Size(350, 30);
            this.txbNameSock.TabIndex = 63;
            // 
            // txbIDSock
            // 
            this.txbIDSock.Enabled = false;
            this.txbIDSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDSock.Location = new System.Drawing.Point(295, 15);
            this.txbIDSock.Name = "txbIDSock";
            this.txbIDSock.Size = new System.Drawing.Size(350, 30);
            this.txbIDSock.TabIndex = 62;
            // 
            // dateTimeSock
            // 
            this.dateTimeSock.Enabled = false;
            this.dateTimeSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeSock.Location = new System.Drawing.Point(295, 77);
            this.dateTimeSock.Name = "dateTimeSock";
            this.dateTimeSock.Size = new System.Drawing.Size(350, 30);
            this.dateTimeSock.TabIndex = 61;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.MediumBlue;
            this.label28.Location = new System.Drawing.Point(130, 434);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(42, 25);
            this.label28.TabIndex = 60;
            this.label28.Text = "Giá";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.MediumBlue;
            this.label27.Location = new System.Drawing.Point(130, 360);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(101, 25);
            this.label27.TabIndex = 59;
            this.label27.Text = "Kiểu dáng";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.MediumBlue;
            this.label26.Location = new System.Drawing.Point(130, 287);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 25);
            this.label26.TabIndex = 58;
            this.label26.Text = "Số lượng";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.MediumBlue;
            this.label25.Location = new System.Drawing.Point(130, 218);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 25);
            this.label25.TabIndex = 57;
            this.label25.Text = "Size vớ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.MediumBlue;
            this.label24.Location = new System.Drawing.Point(130, 149);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 25);
            this.label24.TabIndex = 47;
            this.label24.Text = "Tên vớ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.MediumBlue;
            this.label23.Location = new System.Drawing.Point(130, 82);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(133, 25);
            this.label23.TabIndex = 46;
            this.label23.Text = "Ngày nhập vớ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.MediumBlue;
            this.label22.Location = new System.Drawing.Point(130, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 25);
            this.label22.TabIndex = 45;
            this.label22.Text = "ID vớ";
            // 
            // btnCancelSock
            // 
            this.btnCancelSock.BackColor = System.Drawing.Color.LawnGreen;
            this.btnCancelSock.Location = new System.Drawing.Point(17, 370);
            this.btnCancelSock.Name = "btnCancelSock";
            this.btnCancelSock.Size = new System.Drawing.Size(99, 89);
            this.btnCancelSock.TabIndex = 44;
            this.btnCancelSock.Text = "Bỏ qua";
            this.btnCancelSock.UseVisualStyleBackColor = false;
            this.btnCancelSock.Click += new System.EventHandler(this.btnCancelSock_Click);
            // 
            // btnChangeSock
            // 
            this.btnChangeSock.BackColor = System.Drawing.Color.LawnGreen;
            this.btnChangeSock.Location = new System.Drawing.Point(17, 248);
            this.btnChangeSock.Name = "btnChangeSock";
            this.btnChangeSock.Size = new System.Drawing.Size(99, 89);
            this.btnChangeSock.TabIndex = 26;
            this.btnChangeSock.Text = "Thay đổi";
            this.btnChangeSock.UseVisualStyleBackColor = false;
            this.btnChangeSock.Click += new System.EventHandler(this.btnChangeSock_Click);
            // 
            // cbBSearchKDSock
            // 
            this.cbBSearchKDSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKDSock.FormattingEnabled = true;
            this.cbBSearchKDSock.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cbBSearchKDSock.Location = new System.Drawing.Point(295, 512);
            this.cbBSearchKDSock.Name = "cbBSearchKDSock";
            this.cbBSearchKDSock.Size = new System.Drawing.Size(350, 37);
            this.cbBSearchKDSock.TabIndex = 25;
            this.cbBSearchKDSock.SelectedIndexChanged += new System.EventHandler(this.cbBSearchKDSock_SelectedIndexChanged);
            // 
            // dataViewSearchSock
            // 
            this.dataViewSearchSock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchSock.Location = new System.Drawing.Point(675, 498);
            this.dataViewSearchSock.Name = "dataViewSearchSock";
            this.dataViewSearchSock.RowHeadersWidth = 51;
            this.dataViewSearchSock.RowTemplate.Height = 24;
            this.dataViewSearchSock.Size = new System.Drawing.Size(498, 118);
            this.dataViewSearchSock.TabIndex = 22;
            this.dataViewSearchSock.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewSearchSock_CellContentClick);
            // 
            // btnAddSock
            // 
            this.btnAddSock.BackColor = System.Drawing.Color.LawnGreen;
            this.btnAddSock.Enabled = false;
            this.btnAddSock.Location = new System.Drawing.Point(17, 15);
            this.btnAddSock.Name = "btnAddSock";
            this.btnAddSock.Size = new System.Drawing.Size(99, 89);
            this.btnAddSock.TabIndex = 21;
            this.btnAddSock.Text = "Thêm";
            this.btnAddSock.UseVisualStyleBackColor = false;
            this.btnAddSock.Click += new System.EventHandler(this.btnAddSock_Click);
            // 
            // btnDeleteSock
            // 
            this.btnDeleteSock.BackColor = System.Drawing.Color.LawnGreen;
            this.btnDeleteSock.Enabled = false;
            this.btnDeleteSock.Location = new System.Drawing.Point(17, 132);
            this.btnDeleteSock.Name = "btnDeleteSock";
            this.btnDeleteSock.Size = new System.Drawing.Size(99, 89);
            this.btnDeleteSock.TabIndex = 20;
            this.btnDeleteSock.Text = "Xóa";
            this.btnDeleteSock.UseVisualStyleBackColor = false;
            this.btnDeleteSock.Click += new System.EventHandler(this.btnDeleteSock_Click);
            // 
            // dataViewSock
            // 
            this.dataViewSock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSock.Location = new System.Drawing.Point(675, 15);
            this.dataViewSock.Name = "dataViewSock";
            this.dataViewSock.RowHeadersWidth = 51;
            this.dataViewSock.RowTemplate.Height = 24;
            this.dataViewSock.Size = new System.Drawing.Size(498, 444);
            this.dataViewSock.TabIndex = 8;
            // 
            // btnSearchSock
            // 
            this.btnSearchSock.BackColor = System.Drawing.Color.LawnGreen;
            this.btnSearchSock.Location = new System.Drawing.Point(17, 491);
            this.btnSearchSock.Name = "btnSearchSock";
            this.btnSearchSock.Size = new System.Drawing.Size(99, 89);
            this.btnSearchSock.TabIndex = 7;
            this.btnSearchSock.Text = "Tìm";
            this.btnSearchSock.UseVisualStyleBackColor = false;
            this.btnSearchSock.Click += new System.EventHandler(this.btnSearchSock_Click);
            // 
            // tpQuan
            // 
            this.tpQuan.Controls.Add(this.label21);
            this.tpQuan.Controls.Add(this.label20);
            this.tpQuan.Controls.Add(this.txbPriceQ);
            this.tpQuan.Controls.Add(this.txbKDQ);
            this.tpQuan.Controls.Add(this.txbSLQ);
            this.tpQuan.Controls.Add(this.txbSizeQ);
            this.tpQuan.Controls.Add(this.txbNameQ);
            this.tpQuan.Controls.Add(this.dateTimeNhapQ);
            this.tpQuan.Controls.Add(this.txbIDQ);
            this.tpQuan.Controls.Add(this.label19);
            this.tpQuan.Controls.Add(this.label18);
            this.tpQuan.Controls.Add(this.label17);
            this.tpQuan.Controls.Add(this.label16);
            this.tpQuan.Controls.Add(this.label15);
            this.tpQuan.Controls.Add(this.label14);
            this.tpQuan.Controls.Add(this.label9);
            this.tpQuan.Controls.Add(this.btnCancelQ);
            this.tpQuan.Controls.Add(this.btnChangeQ);
            this.tpQuan.Controls.Add(this.cbBSearchSizeQ);
            this.tpQuan.Controls.Add(this.cbBSearchKieuDangQ);
            this.tpQuan.Controls.Add(this.dataViewSearchQuan);
            this.tpQuan.Controls.Add(this.btnAddQ);
            this.tpQuan.Controls.Add(this.btnDeleteQ);
            this.tpQuan.Controls.Add(this.dataViewQuan);
            this.tpQuan.Controls.Add(this.btnSearchQuan);
            this.tpQuan.Location = new System.Drawing.Point(4, 25);
            this.tpQuan.Name = "tpQuan";
            this.tpQuan.Padding = new System.Windows.Forms.Padding(3);
            this.tpQuan.Size = new System.Drawing.Size(1191, 650);
            this.tpQuan.TabIndex = 3;
            this.tpQuan.Text = "Quần";
            this.tpQuan.UseVisualStyleBackColor = true;
            this.tpQuan.Click += new System.EventHandler(this.tpQuan_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label21.Location = new System.Drawing.Point(125, 537);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(102, 25);
            this.label21.TabIndex = 59;
            this.label21.Text = "Theo Size";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label20.Location = new System.Drawing.Point(125, 475);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(148, 25);
            this.label20.TabIndex = 58;
            this.label20.Text = "Theo kiểu dáng";
            // 
            // txbPriceQ
            // 
            this.txbPriceQ.Enabled = false;
            this.txbPriceQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPriceQ.Location = new System.Drawing.Point(285, 401);
            this.txbPriceQ.Name = "txbPriceQ";
            this.txbPriceQ.Size = new System.Drawing.Size(350, 30);
            this.txbPriceQ.TabIndex = 57;
            this.txbPriceQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbPriceQ_KeyPress);
            // 
            // txbKDQ
            // 
            this.txbKDQ.Enabled = false;
            this.txbKDQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbKDQ.Location = new System.Drawing.Point(285, 337);
            this.txbKDQ.Name = "txbKDQ";
            this.txbKDQ.Size = new System.Drawing.Size(350, 30);
            this.txbKDQ.TabIndex = 56;
            this.txbKDQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbKDQ_KeyPress);
            // 
            // txbSLQ
            // 
            this.txbSLQ.Enabled = false;
            this.txbSLQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSLQ.Location = new System.Drawing.Point(285, 274);
            this.txbSLQ.Name = "txbSLQ";
            this.txbSLQ.Size = new System.Drawing.Size(350, 30);
            this.txbSLQ.TabIndex = 55;
            this.txbSLQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbSLQ_KeyPress);
            // 
            // txbSizeQ
            // 
            this.txbSizeQ.Enabled = false;
            this.txbSizeQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSizeQ.Location = new System.Drawing.Point(285, 204);
            this.txbSizeQ.Name = "txbSizeQ";
            this.txbSizeQ.Size = new System.Drawing.Size(350, 30);
            this.txbSizeQ.TabIndex = 54;
            // 
            // txbNameQ
            // 
            this.txbNameQ.Enabled = false;
            this.txbNameQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNameQ.Location = new System.Drawing.Point(285, 139);
            this.txbNameQ.Name = "txbNameQ";
            this.txbNameQ.Size = new System.Drawing.Size(350, 30);
            this.txbNameQ.TabIndex = 53;
            // 
            // dateTimeNhapQ
            // 
            this.dateTimeNhapQ.Enabled = false;
            this.dateTimeNhapQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeNhapQ.Location = new System.Drawing.Point(285, 68);
            this.dateTimeNhapQ.Name = "dateTimeNhapQ";
            this.dateTimeNhapQ.Size = new System.Drawing.Size(350, 30);
            this.dateTimeNhapQ.TabIndex = 52;
            // 
            // txbIDQ
            // 
            this.txbIDQ.Enabled = false;
            this.txbIDQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDQ.Location = new System.Drawing.Point(285, 6);
            this.txbIDQ.Name = "txbIDQ";
            this.txbIDQ.Size = new System.Drawing.Size(350, 30);
            this.txbIDQ.TabIndex = 51;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.MediumBlue;
            this.label19.Location = new System.Drawing.Point(125, 406);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 25);
            this.label19.TabIndex = 50;
            this.label19.Text = "Giá quần";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.MediumBlue;
            this.label18.Location = new System.Drawing.Point(125, 342);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 25);
            this.label18.TabIndex = 49;
            this.label18.Text = "Kiểu dáng";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.MediumBlue;
            this.label17.Location = new System.Drawing.Point(125, 274);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 25);
            this.label17.TabIndex = 48;
            this.label17.Text = "Số lượng";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.MediumBlue;
            this.label16.Location = new System.Drawing.Point(125, 207);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 25);
            this.label16.TabIndex = 47;
            this.label16.Text = "Size quần";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.MediumBlue;
            this.label15.Location = new System.Drawing.Point(125, 139);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 25);
            this.label15.TabIndex = 46;
            this.label15.Text = "Tên quần";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.MediumBlue;
            this.label14.Location = new System.Drawing.Point(125, 68);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 25);
            this.label14.TabIndex = 45;
            this.label14.Text = "Ngày nhập quần";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.MediumBlue;
            this.label9.Location = new System.Drawing.Point(125, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 25);
            this.label9.TabIndex = 44;
            this.label9.Text = "ID quần";
            // 
            // btnCancelQ
            // 
            this.btnCancelQ.BackColor = System.Drawing.Color.LawnGreen;
            this.btnCancelQ.Location = new System.Drawing.Point(7, 342);
            this.btnCancelQ.Name = "btnCancelQ";
            this.btnCancelQ.Size = new System.Drawing.Size(98, 98);
            this.btnCancelQ.TabIndex = 43;
            this.btnCancelQ.Text = "Bỏ qua";
            this.btnCancelQ.UseVisualStyleBackColor = false;
            this.btnCancelQ.Click += new System.EventHandler(this.btnCancelQ_Click);
            // 
            // btnChangeQ
            // 
            this.btnChangeQ.BackColor = System.Drawing.Color.LawnGreen;
            this.btnChangeQ.Location = new System.Drawing.Point(7, 227);
            this.btnChangeQ.Name = "btnChangeQ";
            this.btnChangeQ.Size = new System.Drawing.Size(98, 98);
            this.btnChangeQ.TabIndex = 42;
            this.btnChangeQ.Text = "Thay đổi";
            this.btnChangeQ.UseVisualStyleBackColor = false;
            this.btnChangeQ.Click += new System.EventHandler(this.btnChangeQ_Click);
            // 
            // cbBSearchSizeQ
            // 
            this.cbBSearchSizeQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSizeQ.FormattingEnabled = true;
            this.cbBSearchSizeQ.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL"});
            this.cbBSearchSizeQ.Location = new System.Drawing.Point(285, 525);
            this.cbBSearchSizeQ.Name = "cbBSearchSizeQ";
            this.cbBSearchSizeQ.Size = new System.Drawing.Size(350, 37);
            this.cbBSearchSizeQ.TabIndex = 25;
            // 
            // cbBSearchKieuDangQ
            // 
            this.cbBSearchKieuDangQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKieuDangQ.FormattingEnabled = true;
            this.cbBSearchKieuDangQ.Items.AddRange(new object[] {
            "QuanNam",
            "QuanNu"});
            this.cbBSearchKieuDangQ.Location = new System.Drawing.Point(285, 463);
            this.cbBSearchKieuDangQ.Name = "cbBSearchKieuDangQ";
            this.cbBSearchKieuDangQ.Size = new System.Drawing.Size(350, 37);
            this.cbBSearchKieuDangQ.TabIndex = 24;
            this.cbBSearchKieuDangQ.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataViewSearchQuan
            // 
            this.dataViewSearchQuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchQuan.Location = new System.Drawing.Point(669, 451);
            this.dataViewSearchQuan.Name = "dataViewSearchQuan";
            this.dataViewSearchQuan.RowHeadersWidth = 51;
            this.dataViewSearchQuan.RowTemplate.Height = 24;
            this.dataViewSearchQuan.Size = new System.Drawing.Size(503, 165);
            this.dataViewSearchQuan.TabIndex = 22;
            this.dataViewSearchQuan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtViewSearchQuan_CellContentClick);
            // 
            // btnAddQ
            // 
            this.btnAddQ.BackColor = System.Drawing.Color.LawnGreen;
            this.btnAddQ.Enabled = false;
            this.btnAddQ.Location = new System.Drawing.Point(7, 6);
            this.btnAddQ.Name = "btnAddQ";
            this.btnAddQ.Size = new System.Drawing.Size(99, 98);
            this.btnAddQ.TabIndex = 21;
            this.btnAddQ.Text = "Thêm";
            this.btnAddQ.UseVisualStyleBackColor = false;
            this.btnAddQ.Click += new System.EventHandler(this.btnAddQuan_Click);
            // 
            // btnDeleteQ
            // 
            this.btnDeleteQ.BackColor = System.Drawing.Color.LawnGreen;
            this.btnDeleteQ.Enabled = false;
            this.btnDeleteQ.Location = new System.Drawing.Point(8, 123);
            this.btnDeleteQ.Name = "btnDeleteQ";
            this.btnDeleteQ.Size = new System.Drawing.Size(98, 98);
            this.btnDeleteQ.TabIndex = 20;
            this.btnDeleteQ.Text = "Xóa";
            this.btnDeleteQ.UseVisualStyleBackColor = false;
            this.btnDeleteQ.Click += new System.EventHandler(this.btnDeleteQ_Click);
            // 
            // dataViewQuan
            // 
            this.dataViewQuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewQuan.Location = new System.Drawing.Point(669, 6);
            this.dataViewQuan.Name = "dataViewQuan";
            this.dataViewQuan.RowHeadersWidth = 51;
            this.dataViewQuan.RowTemplate.Height = 24;
            this.dataViewQuan.Size = new System.Drawing.Size(503, 425);
            this.dataViewQuan.TabIndex = 8;
            this.dataViewQuan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewQuan_CellContentClick);
            // 
            // btnSearchQuan
            // 
            this.btnSearchQuan.BackColor = System.Drawing.Color.LawnGreen;
            this.btnSearchQuan.Location = new System.Drawing.Point(6, 475);
            this.btnSearchQuan.Name = "btnSearchQuan";
            this.btnSearchQuan.Size = new System.Drawing.Size(99, 98);
            this.btnSearchQuan.TabIndex = 7;
            this.btnSearchQuan.Text = "Tìm";
            this.btnSearchQuan.UseVisualStyleBackColor = false;
            this.btnSearchQuan.Click += new System.EventHandler(this.btnSearchQuan_Click);
            // 
            // tpAo
            // 
            this.tpAo.Controls.Add(this.groupBox3);
            this.tpAo.Controls.Add(this.groupBox2);
            this.tpAo.Controls.Add(this.groupBox1);
            this.tpAo.Location = new System.Drawing.Point(4, 25);
            this.tpAo.Name = "tpAo";
            this.tpAo.Padding = new System.Windows.Forms.Padding(3);
            this.tpAo.Size = new System.Drawing.Size(1191, 650);
            this.tpAo.TabIndex = 2;
            this.tpAo.Text = "Áo";
            this.tpAo.UseVisualStyleBackColor = true;
            this.tpAo.Click += new System.EventHandler(this.tpAo_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txbAddIDAo);
            this.groupBox3.Controls.Add(this.dataViewAo);
            this.groupBox3.Controls.Add(this.txbPriceAo);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txbKieuDangAo);
            this.groupBox3.Controls.Add(this.dateTimeAddAo);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txbSLAddAo);
            this.groupBox3.Controls.Add(this.txbNameAo);
            this.groupBox3.Controls.Add(this.txbSizeAo);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(167, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1018, 466);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thêm xóa sửa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumBlue;
            this.label1.Location = new System.Drawing.Point(21, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 25);
            this.label1.TabIndex = 31;
            this.label1.Text = "ID áo";
            // 
            // txbAddIDAo
            // 
            this.txbAddIDAo.Enabled = false;
            this.txbAddIDAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbAddIDAo.Location = new System.Drawing.Point(190, 21);
            this.txbAddIDAo.Name = "txbAddIDAo";
            this.txbAddIDAo.Size = new System.Drawing.Size(328, 30);
            this.txbAddIDAo.TabIndex = 24;
            // 
            // dataViewAo
            // 
            this.dataViewAo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewAo.Location = new System.Drawing.Point(546, 15);
            this.dataViewAo.Name = "dataViewAo";
            this.dataViewAo.RowHeadersWidth = 51;
            this.dataViewAo.RowTemplate.Height = 24;
            this.dataViewAo.Size = new System.Drawing.Size(472, 437);
            this.dataViewAo.TabIndex = 8;
            this.dataViewAo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewAo_CellClick);
            this.dataViewAo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewAo_CellContentClick);
            this.dataViewAo.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewAo_CellDoubleClick);
            this.dataViewAo.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataViewAo_CellMouseDoubleClick);
            // 
            // txbPriceAo
            // 
            this.txbPriceAo.Enabled = false;
            this.txbPriceAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPriceAo.Location = new System.Drawing.Point(189, 408);
            this.txbPriceAo.Name = "txbPriceAo";
            this.txbPriceAo.Size = new System.Drawing.Size(328, 30);
            this.txbPriceAo.TabIndex = 38;
            this.txbPriceAo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbPriceAo_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumBlue;
            this.label2.Location = new System.Drawing.Point(20, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 25);
            this.label2.TabIndex = 32;
            this.label2.Text = "Ngày nhập áo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MediumBlue;
            this.label7.Location = new System.Drawing.Point(21, 411);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 25);
            this.label7.TabIndex = 37;
            this.label7.Text = "Giá áo";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txbKieuDangAo
            // 
            this.txbKieuDangAo.Enabled = false;
            this.txbKieuDangAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbKieuDangAo.Location = new System.Drawing.Point(189, 345);
            this.txbKieuDangAo.Name = "txbKieuDangAo";
            this.txbKieuDangAo.Size = new System.Drawing.Size(328, 30);
            this.txbKieuDangAo.TabIndex = 29;
            this.txbKieuDangAo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbKieuDangAo_KeyPress);
            // 
            // dateTimeAddAo
            // 
            this.dateTimeAddAo.Enabled = false;
            this.dateTimeAddAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeAddAo.Location = new System.Drawing.Point(190, 86);
            this.dateTimeAddAo.Name = "dateTimeAddAo";
            this.dateTimeAddAo.Size = new System.Drawing.Size(328, 30);
            this.dateTimeAddAo.TabIndex = 40;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(21, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Tên áo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MediumBlue;
            this.label6.Location = new System.Drawing.Point(21, 345);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 25);
            this.label6.TabIndex = 36;
            this.label6.Text = "Kiểu dáng";
            // 
            // txbSLAddAo
            // 
            this.txbSLAddAo.Enabled = false;
            this.txbSLAddAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSLAddAo.Location = new System.Drawing.Point(189, 277);
            this.txbSLAddAo.Name = "txbSLAddAo";
            this.txbSLAddAo.Size = new System.Drawing.Size(328, 30);
            this.txbSLAddAo.TabIndex = 28;
            this.txbSLAddAo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbSLAddAo_KeyPress);
            // 
            // txbNameAo
            // 
            this.txbNameAo.Enabled = false;
            this.txbNameAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNameAo.Location = new System.Drawing.Point(190, 147);
            this.txbNameAo.Name = "txbNameAo";
            this.txbNameAo.Size = new System.Drawing.Size(328, 30);
            this.txbNameAo.TabIndex = 26;
            // 
            // txbSizeAo
            // 
            this.txbSizeAo.Enabled = false;
            this.txbSizeAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSizeAo.Location = new System.Drawing.Point(189, 215);
            this.txbSizeAo.Name = "txbSizeAo";
            this.txbSizeAo.Size = new System.Drawing.Size(328, 30);
            this.txbSizeAo.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MediumBlue;
            this.label4.Location = new System.Drawing.Point(21, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 25);
            this.label4.TabIndex = 34;
            this.label4.Text = "Size áo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MediumBlue;
            this.label5.Location = new System.Drawing.Point(21, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 25);
            this.label5.TabIndex = 35;
            this.label5.Text = "Số lượng";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbBSearchKDAo);
            this.groupBox2.Controls.Add(this.cbBSearchSizeAo);
            this.groupBox2.Controls.Add(this.lblSearchSizeAo);
            this.groupBox2.Controls.Add(this.lblSearchKDAo);
            this.groupBox2.Controls.Add(this.dataViewSearchAo);
            this.groupBox2.Location = new System.Drawing.Point(167, 487);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1018, 158);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // cbBSearchKDAo
            // 
            this.cbBSearchKDAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKDAo.FormattingEnabled = true;
            this.cbBSearchKDAo.Items.AddRange(new object[] {
            "AoNam",
            "AoNu",
            ""});
            this.cbBSearchKDAo.Location = new System.Drawing.Point(189, 32);
            this.cbBSearchKDAo.Name = "cbBSearchKDAo";
            this.cbBSearchKDAo.Size = new System.Drawing.Size(328, 37);
            this.cbBSearchKDAo.TabIndex = 23;
            this.cbBSearchKDAo.SelectedIndexChanged += new System.EventHandler(this.cbBSearchAo_SelectedIndexChanged);
            // 
            // cbBSearchSizeAo
            // 
            this.cbBSearchSizeAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSizeAo.FormattingEnabled = true;
            this.cbBSearchSizeAo.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cbBSearchSizeAo.Location = new System.Drawing.Point(189, 97);
            this.cbBSearchSizeAo.Name = "cbBSearchSizeAo";
            this.cbBSearchSizeAo.Size = new System.Drawing.Size(328, 37);
            this.cbBSearchSizeAo.TabIndex = 39;
            this.cbBSearchSizeAo.SelectedIndexChanged += new System.EventHandler(this.cbBSearchSize_SelectedIndexChanged);
            // 
            // lblSearchSizeAo
            // 
            this.lblSearchSizeAo.AutoSize = true;
            this.lblSearchSizeAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchSizeAo.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblSearchSizeAo.Location = new System.Drawing.Point(20, 97);
            this.lblSearchSizeAo.Name = "lblSearchSizeAo";
            this.lblSearchSizeAo.Size = new System.Drawing.Size(102, 25);
            this.lblSearchSizeAo.TabIndex = 44;
            this.lblSearchSizeAo.Text = "Theo Size";
            // 
            // lblSearchKDAo
            // 
            this.lblSearchKDAo.AutoSize = true;
            this.lblSearchKDAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchKDAo.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblSearchKDAo.Location = new System.Drawing.Point(20, 38);
            this.lblSearchKDAo.Name = "lblSearchKDAo";
            this.lblSearchKDAo.Size = new System.Drawing.Size(148, 25);
            this.lblSearchKDAo.TabIndex = 43;
            this.lblSearchKDAo.Text = "Theo kiểu dáng";
            // 
            // dataViewSearchAo
            // 
            this.dataViewSearchAo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchAo.Location = new System.Drawing.Point(546, 21);
            this.dataViewSearchAo.Name = "dataViewSearchAo";
            this.dataViewSearchAo.RowHeadersWidth = 51;
            this.dataViewSearchAo.RowTemplate.Height = 24;
            this.dataViewSearchAo.Size = new System.Drawing.Size(472, 132);
            this.dataViewSearchAo.TabIndex = 22;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAddAo);
            this.groupBox1.Controls.Add(this.btnDeleteAo);
            this.groupBox1.Controls.Add(this.btnChangeAo);
            this.groupBox1.Controls.Add(this.btnCancelAo);
            this.groupBox1.Controls.Add(this.btnSearchAo);
            this.groupBox1.Location = new System.Drawing.Point(6, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(154, 636);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thao tác";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnAddAo
            // 
            this.btnAddAo.BackColor = System.Drawing.Color.LawnGreen;
            this.btnAddAo.Enabled = false;
            this.btnAddAo.Location = new System.Drawing.Point(16, 21);
            this.btnAddAo.Name = "btnAddAo";
            this.btnAddAo.Size = new System.Drawing.Size(99, 96);
            this.btnAddAo.TabIndex = 21;
            this.btnAddAo.Text = "Thêm ";
            this.btnAddAo.UseVisualStyleBackColor = false;
            this.btnAddAo.Click += new System.EventHandler(this.btnAddAo_Click);
            // 
            // btnDeleteAo
            // 
            this.btnDeleteAo.BackColor = System.Drawing.Color.LawnGreen;
            this.btnDeleteAo.Enabled = false;
            this.btnDeleteAo.Location = new System.Drawing.Point(16, 139);
            this.btnDeleteAo.Name = "btnDeleteAo";
            this.btnDeleteAo.Size = new System.Drawing.Size(99, 96);
            this.btnDeleteAo.TabIndex = 20;
            this.btnDeleteAo.Text = "Xóa  (hàng hư hoặc vừa bán)";
            this.btnDeleteAo.UseVisualStyleBackColor = false;
            this.btnDeleteAo.Click += new System.EventHandler(this.btnDeleteAo_Click);
            // 
            // btnChangeAo
            // 
            this.btnChangeAo.BackColor = System.Drawing.Color.LawnGreen;
            this.btnChangeAo.Location = new System.Drawing.Point(16, 250);
            this.btnChangeAo.Name = "btnChangeAo";
            this.btnChangeAo.Size = new System.Drawing.Size(99, 96);
            this.btnChangeAo.TabIndex = 41;
            this.btnChangeAo.Text = "Thay đổi";
            this.btnChangeAo.UseVisualStyleBackColor = false;
            this.btnChangeAo.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancelAo
            // 
            this.btnCancelAo.BackColor = System.Drawing.Color.LawnGreen;
            this.btnCancelAo.Location = new System.Drawing.Point(16, 371);
            this.btnCancelAo.Name = "btnCancelAo";
            this.btnCancelAo.Size = new System.Drawing.Size(99, 96);
            this.btnCancelAo.TabIndex = 42;
            this.btnCancelAo.Text = "Bỏ qua";
            this.btnCancelAo.UseVisualStyleBackColor = false;
            this.btnCancelAo.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSearchAo
            // 
            this.btnSearchAo.BackColor = System.Drawing.Color.LawnGreen;
            this.btnSearchAo.Location = new System.Drawing.Point(16, 493);
            this.btnSearchAo.Name = "btnSearchAo";
            this.btnSearchAo.Size = new System.Drawing.Size(99, 96);
            this.btnSearchAo.TabIndex = 7;
            this.btnSearchAo.Text = "Tìm";
            this.btnSearchAo.UseVisualStyleBackColor = false;
            this.btnSearchAo.Click += new System.EventHandler(this.btnSearchAo_Click);
            // 
            // tb9
            // 
            this.tb9.Controls.Add(this.tbDoanhthu);
            this.tb9.Controls.Add(this.lblSpriceHat);
            this.tb9.Controls.Add(this.tpAo);
            this.tb9.Controls.Add(this.tpQuan);
            this.tb9.Controls.Add(this.tpSock);
            this.tb9.Controls.Add(this.tbHangTonKho);
            this.tb9.Location = new System.Drawing.Point(12, 28);
            this.tb9.Name = "tb9";
            this.tb9.SelectedIndex = 0;
            this.tb9.Size = new System.Drawing.Size(1199, 679);
            this.tb9.TabIndex = 0;
            // 
            // tbDoanhthu
            // 
            this.tbDoanhthu.Controls.Add(this.btnLoad);
            this.tbDoanhthu.Controls.Add(this.btnThongKeTienLai);
            this.tbDoanhthu.Controls.Add(this.textBox2);
            this.tbDoanhthu.Controls.Add(this.textBox1);
            this.tbDoanhthu.Controls.Add(this.lblMoney);
            this.tbDoanhthu.Controls.Add(this.lblLai);
            this.tbDoanhthu.Controls.Add(this.btnThongKeDoanhThu);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker4);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker3);
            this.tbDoanhthu.Controls.Add(this.dataViewDSBill);
            this.tbDoanhthu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDoanhthu.Location = new System.Drawing.Point(4, 25);
            this.tbDoanhthu.Name = "tbDoanhthu";
            this.tbDoanhthu.Padding = new System.Windows.Forms.Padding(3);
            this.tbDoanhthu.Size = new System.Drawing.Size(1191, 650);
            this.tbDoanhthu.TabIndex = 0;
            this.tbDoanhthu.Text = "Doanh thu";
            this.tbDoanhthu.UseVisualStyleBackColor = true;
            this.tbDoanhthu.Click += new System.EventHandler(this.tbDoanhthu_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(607, 554);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(68, 62);
            this.btnLoad.TabIndex = 10;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnThongKeTienLai
            // 
            this.btnThongKeTienLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeTienLai.Location = new System.Drawing.Point(544, 60);
            this.btnThongKeTienLai.Name = "btnThongKeTienLai";
            this.btnThongKeTienLai.Size = new System.Drawing.Size(140, 70);
            this.btnThongKeTienLai.TabIndex = 9;
            this.btnThongKeTienLai.Text = "Tra cứu doanh thu";
            this.btnThongKeTienLai.UseVisualStyleBackColor = true;
            this.btnThongKeTienLai.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(856, 109);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 27);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(856, 60);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 27);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // lblMoney
            // 
            this.lblMoney.AutoSize = true;
            this.lblMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoney.Location = new System.Drawing.Point(690, 101);
            this.lblMoney.Name = "lblMoney";
            this.lblMoney.Size = new System.Drawing.Size(0, 29);
            this.lblMoney.TabIndex = 6;
            // 
            // lblLai
            // 
            this.lblLai.AutoSize = true;
            this.lblLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLai.Location = new System.Drawing.Point(690, 60);
            this.lblLai.Name = "lblLai";
            this.lblLai.Size = new System.Drawing.Size(0, 29);
            this.lblLai.TabIndex = 5;
            // 
            // btnThongKeDoanhThu
            // 
            this.btnThongKeDoanhThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeDoanhThu.Location = new System.Drawing.Point(356, 9);
            this.btnThongKeDoanhThu.Name = "btnThongKeDoanhThu";
            this.btnThongKeDoanhThu.Size = new System.Drawing.Size(130, 57);
            this.btnThongKeDoanhThu.TabIndex = 4;
            this.btnThongKeDoanhThu.Text = "Thống kê hàng đã bán";
            this.btnThongKeDoanhThu.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Location = new System.Drawing.Point(590, 12);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(327, 30);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(18, 11);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(330, 30);
            this.dateTimePicker3.TabIndex = 2;
            // 
            // dataViewDSBill
            // 
            this.dataViewDSBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewDSBill.Location = new System.Drawing.Point(681, 192);
            this.dataViewDSBill.Name = "dataViewDSBill";
            this.dataViewDSBill.RowHeadersWidth = 51;
            this.dataViewDSBill.RowTemplate.Height = 24;
            this.dataViewDSBill.Size = new System.Drawing.Size(468, 424);
            this.dataViewDSBill.TabIndex = 1;
            this.dataViewDSBill.AllowUserToAddRowsChanged += new System.EventHandler(this.dataViewDSBill_AllowUserToAddRowsChanged);
            this.dataViewDSBill.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewDSBill_CellContentClick);
            // 
            // lblSpriceHat
            // 
            this.lblSpriceHat.Controls.Add(this.label30);
            this.lblSpriceHat.Controls.Add(this.txbSizeHat);
            this.lblSpriceHat.Controls.Add(this.label8);
            this.lblSpriceHat.Controls.Add(this.dateTimeNhapHat);
            this.lblSpriceHat.Controls.Add(this.txbPriceHat);
            this.lblSpriceHat.Controls.Add(this.txbKDHat);
            this.lblSpriceHat.Controls.Add(this.txbSLHat);
            this.lblSpriceHat.Controls.Add(this.txbNameHat);
            this.lblSpriceHat.Controls.Add(this.txbIDHat);
            this.lblSpriceHat.Controls.Add(this.label13);
            this.lblSpriceHat.Controls.Add(this.label12);
            this.lblSpriceHat.Controls.Add(this.label11);
            this.lblSpriceHat.Controls.Add(this.label10);
            this.lblSpriceHat.Controls.Add(this.lb2);
            this.lblSpriceHat.Controls.Add(this.lblIDHat);
            this.lblSpriceHat.Controls.Add(this.btnCancelHat);
            this.lblSpriceHat.Controls.Add(this.dâtViewSearchHat);
            this.lblSpriceHat.Controls.Add(this.txbSearchHat);
            this.lblSpriceHat.Controls.Add(this.btnSearchHat);
            this.lblSpriceHat.Controls.Add(this.btnChangeHat);
            this.lblSpriceHat.Controls.Add(this.btnDeleteHat);
            this.lblSpriceHat.Controls.Add(this.btnAddHat);
            this.lblSpriceHat.Controls.Add(this.dataViewHat);
            this.lblSpriceHat.Location = new System.Drawing.Point(4, 25);
            this.lblSpriceHat.Name = "lblSpriceHat";
            this.lblSpriceHat.Padding = new System.Windows.Forms.Padding(3);
            this.lblSpriceHat.Size = new System.Drawing.Size(1191, 650);
            this.lblSpriceHat.TabIndex = 1;
            this.lblSpriceHat.Text = "Nón";
            this.lblSpriceHat.UseVisualStyleBackColor = true;
            this.lblSpriceHat.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label30.Location = new System.Drawing.Point(128, 531);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(148, 25);
            this.label30.TabIndex = 58;
            this.label30.Text = "Theo kiểu dáng";
            // 
            // txbSizeHat
            // 
            this.txbSizeHat.Enabled = false;
            this.txbSizeHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSizeHat.Location = new System.Drawing.Point(283, 239);
            this.txbSizeHat.Name = "txbSizeHat";
            this.txbSizeHat.Size = new System.Drawing.Size(350, 30);
            this.txbSizeHat.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.MediumBlue;
            this.label8.Location = new System.Drawing.Point(128, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 25);
            this.label8.TabIndex = 56;
            this.label8.Text = "Size nón";
            // 
            // dateTimeNhapHat
            // 
            this.dateTimeNhapHat.Enabled = false;
            this.dateTimeNhapHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeNhapHat.Location = new System.Drawing.Point(283, 89);
            this.dateTimeNhapHat.Name = "dateTimeNhapHat";
            this.dateTimeNhapHat.Size = new System.Drawing.Size(350, 30);
            this.dateTimeNhapHat.TabIndex = 55;
            // 
            // txbPriceHat
            // 
            this.txbPriceHat.Enabled = false;
            this.txbPriceHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPriceHat.Location = new System.Drawing.Point(283, 434);
            this.txbPriceHat.Name = "txbPriceHat";
            this.txbPriceHat.Size = new System.Drawing.Size(350, 30);
            this.txbPriceHat.TabIndex = 54;
            this.txbPriceHat.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            this.txbPriceHat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbPriceHat_KeyPress);
            // 
            // txbKDHat
            // 
            this.txbKDHat.Enabled = false;
            this.txbKDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbKDHat.Location = new System.Drawing.Point(283, 375);
            this.txbKDHat.Name = "txbKDHat";
            this.txbKDHat.Size = new System.Drawing.Size(350, 30);
            this.txbKDHat.TabIndex = 53;
            this.txbKDHat.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            this.txbKDHat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbKDHat_KeyPress);
            // 
            // txbSLHat
            // 
            this.txbSLHat.Enabled = false;
            this.txbSLHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSLHat.Location = new System.Drawing.Point(283, 310);
            this.txbSLHat.Name = "txbSLHat";
            this.txbSLHat.Size = new System.Drawing.Size(350, 30);
            this.txbSLHat.TabIndex = 52;
            this.txbSLHat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbSLHat_KeyPress);
            // 
            // txbNameHat
            // 
            this.txbNameHat.Enabled = false;
            this.txbNameHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNameHat.Location = new System.Drawing.Point(283, 166);
            this.txbNameHat.Name = "txbNameHat";
            this.txbNameHat.Size = new System.Drawing.Size(350, 30);
            this.txbNameHat.TabIndex = 51;
            // 
            // txbIDHat
            // 
            this.txbIDHat.Enabled = false;
            this.txbIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDHat.Location = new System.Drawing.Point(283, 16);
            this.txbIDHat.Name = "txbIDHat";
            this.txbIDHat.Size = new System.Drawing.Size(350, 30);
            this.txbIDHat.TabIndex = 50;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.MediumBlue;
            this.label13.Location = new System.Drawing.Point(128, 375);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 25);
            this.label13.TabIndex = 49;
            this.label13.Text = "Kiểu dáng";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.MediumBlue;
            this.label12.Location = new System.Drawing.Point(128, 437);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 25);
            this.label12.TabIndex = 48;
            this.label12.Text = "Giá";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.MediumBlue;
            this.label11.Location = new System.Drawing.Point(128, 300);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 25);
            this.label11.TabIndex = 47;
            this.label11.Text = "Số lượng";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.MediumBlue;
            this.label10.Location = new System.Drawing.Point(128, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 25);
            this.label10.TabIndex = 46;
            this.label10.Text = "Tên nón";
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.ForeColor = System.Drawing.Color.MediumBlue;
            this.lb2.Location = new System.Drawing.Point(128, 89);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(145, 25);
            this.lb2.TabIndex = 45;
            this.lb2.Text = "Ngày nhập nón";
            // 
            // lblIDHat
            // 
            this.lblIDHat.AutoSize = true;
            this.lblIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDHat.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblIDHat.Location = new System.Drawing.Point(128, 26);
            this.lblIDHat.Name = "lblIDHat";
            this.lblIDHat.Size = new System.Drawing.Size(69, 25);
            this.lblIDHat.TabIndex = 44;
            this.lblIDHat.Text = "ID nón";
            // 
            // btnCancelHat
            // 
            this.btnCancelHat.BackColor = System.Drawing.Color.LawnGreen;
            this.btnCancelHat.Location = new System.Drawing.Point(6, 373);
            this.btnCancelHat.Name = "btnCancelHat";
            this.btnCancelHat.Size = new System.Drawing.Size(99, 89);
            this.btnCancelHat.TabIndex = 43;
            this.btnCancelHat.Text = "Bỏ qua";
            this.btnCancelHat.UseVisualStyleBackColor = false;
            this.btnCancelHat.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dâtViewSearchHat
            // 
            this.dâtViewSearchHat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dâtViewSearchHat.Location = new System.Drawing.Point(657, 496);
            this.dâtViewSearchHat.Name = "dâtViewSearchHat";
            this.dâtViewSearchHat.RowHeadersWidth = 51;
            this.dâtViewSearchHat.RowTemplate.Height = 24;
            this.dâtViewSearchHat.Size = new System.Drawing.Size(516, 149);
            this.dâtViewSearchHat.TabIndex = 7;
            // 
            // txbSearchHat
            // 
            this.txbSearchHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchHat.Location = new System.Drawing.Point(283, 531);
            this.txbSearchHat.Name = "txbSearchHat";
            this.txbSearchHat.Size = new System.Drawing.Size(350, 36);
            this.txbSearchHat.TabIndex = 6;
            // 
            // btnSearchHat
            // 
            this.btnSearchHat.BackColor = System.Drawing.Color.LawnGreen;
            this.btnSearchHat.Location = new System.Drawing.Point(6, 500);
            this.btnSearchHat.Name = "btnSearchHat";
            this.btnSearchHat.Size = new System.Drawing.Size(99, 89);
            this.btnSearchHat.TabIndex = 5;
            this.btnSearchHat.Text = "Tìm";
            this.btnSearchHat.UseVisualStyleBackColor = false;
            // 
            // btnChangeHat
            // 
            this.btnChangeHat.BackColor = System.Drawing.Color.LawnGreen;
            this.btnChangeHat.Location = new System.Drawing.Point(6, 251);
            this.btnChangeHat.Name = "btnChangeHat";
            this.btnChangeHat.Size = new System.Drawing.Size(99, 89);
            this.btnChangeHat.TabIndex = 3;
            this.btnChangeHat.Text = "Thay đổi";
            this.btnChangeHat.UseVisualStyleBackColor = false;
            this.btnChangeHat.Click += new System.EventHandler(this.btnChangeHat_Click);
            // 
            // btnDeleteHat
            // 
            this.btnDeleteHat.BackColor = System.Drawing.Color.LawnGreen;
            this.btnDeleteHat.Enabled = false;
            this.btnDeleteHat.Location = new System.Drawing.Point(6, 126);
            this.btnDeleteHat.Name = "btnDeleteHat";
            this.btnDeleteHat.Size = new System.Drawing.Size(99, 89);
            this.btnDeleteHat.TabIndex = 2;
            this.btnDeleteHat.Text = "Xóa";
            this.btnDeleteHat.UseVisualStyleBackColor = false;
            this.btnDeleteHat.Click += new System.EventHandler(this.btnDeleteHat_Click);
            // 
            // btnAddHat
            // 
            this.btnAddHat.BackColor = System.Drawing.Color.LawnGreen;
            this.btnAddHat.Enabled = false;
            this.btnAddHat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddHat.Location = new System.Drawing.Point(6, 6);
            this.btnAddHat.Name = "btnAddHat";
            this.btnAddHat.Size = new System.Drawing.Size(99, 89);
            this.btnAddHat.TabIndex = 1;
            this.btnAddHat.Text = "Thêm";
            this.btnAddHat.UseVisualStyleBackColor = false;
            this.btnAddHat.Click += new System.EventHandler(this.btnAddHat_Click);
            // 
            // dataViewHat
            // 
            this.dataViewHat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewHat.Location = new System.Drawing.Point(657, 16);
            this.dataViewHat.Name = "dataViewHat";
            this.dataViewHat.RowHeadersWidth = 51;
            this.dataViewHat.RowTemplate.Height = 24;
            this.dataViewHat.Size = new System.Drawing.Size(516, 448);
            this.dataViewHat.TabIndex = 0;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 784);
            this.Controls.Add(this.tb9);
            this.Controls.Add(this.btnOutAdmin);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.fAdmin_Load);
            this.tbHangTonKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSale)).EndInit();
            this.tpSock.ResumeLayout(false);
            this.tpSock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).EndInit();
            this.tpQuan.ResumeLayout(false);
            this.tpQuan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).EndInit();
            this.tpAo.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchAo)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tb9.ResumeLayout(false);
            this.tbDoanhthu.ResumeLayout(false);
            this.tbDoanhthu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewDSBill)).EndInit();
            this.lblSpriceHat.ResumeLayout(false);
            this.lblSpriceHat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dâtViewSearchHat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnOutAdmin;
        private System.Windows.Forms.TabPage tbHangTonKho;
        private System.Windows.Forms.ComboBox cbBSearchLoaiSale;
        private System.Windows.Forms.ComboBox cbBSearchSizeSale;
        private System.Windows.Forms.ComboBox cbBSearchKDSale;
        private System.Windows.Forms.DataGridView dataViewSearchSale;
        private System.Windows.Forms.Button btnSearchHangE;
        private System.Windows.Forms.Button btnDeleteHangE;
        private System.Windows.Forms.Button btnAddHangE;
        private System.Windows.Forms.DataGridView dataViewSale;
        private System.Windows.Forms.TabPage tpSock;
        private System.Windows.Forms.ComboBox cbBSearchKDSock;
        private System.Windows.Forms.DataGridView dataViewSearchSock;
        private System.Windows.Forms.Button btnAddSock;
        private System.Windows.Forms.Button btnDeleteSock;
        private System.Windows.Forms.DataGridView dataViewSock;
        private System.Windows.Forms.Button btnSearchSock;
        private System.Windows.Forms.TabPage tpQuan;
        private System.Windows.Forms.ComboBox cbBSearchSizeQ;
        private System.Windows.Forms.ComboBox cbBSearchKieuDangQ;
        private System.Windows.Forms.DataGridView dataViewSearchQuan;
        private System.Windows.Forms.Button btnAddQ;
        private System.Windows.Forms.Button btnDeleteQ;
        private System.Windows.Forms.DataGridView dataViewQuan;
        private System.Windows.Forms.Button btnSearchQuan;
        private System.Windows.Forms.TabPage tpAo;
        private System.Windows.Forms.ComboBox cbBSearchSizeAo;
        private System.Windows.Forms.TextBox txbPriceAo;
        private System.Windows.Forms.TextBox txbKieuDangAo;
        private System.Windows.Forms.TextBox txbSLAddAo;
        private System.Windows.Forms.TextBox txbSizeAo;
        private System.Windows.Forms.TextBox txbNameAo;
        private System.Windows.Forms.TextBox txbAddIDAo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbBSearchKDAo;
        private System.Windows.Forms.DataGridView dataViewSearchAo;
        private System.Windows.Forms.DataGridView dataViewAo;
        private System.Windows.Forms.TabControl tb9;
        private System.Windows.Forms.TabPage tbDoanhthu;
        private System.Windows.Forms.Button btnThongKeTienLai;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblMoney;
        private System.Windows.Forms.Label lblLai;
        private System.Windows.Forms.Button btnThongKeDoanhThu;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DataGridView dataViewDSBill;
        private System.Windows.Forms.DateTimePicker dateTimeAddAo;
        private System.Windows.Forms.Label lblSearchSizeAo;
        private System.Windows.Forms.Label lblSearchKDAo;
        private System.Windows.Forms.TabPage lblSpriceHat;
        private System.Windows.Forms.Button btnSearchHat;
        private System.Windows.Forms.Button btnChangeHat;
        private System.Windows.Forms.Button btnDeleteHat;
        private System.Windows.Forms.Button btnAddHat;
        private System.Windows.Forms.DataGridView dataViewHat;
        private System.Windows.Forms.DataGridView dâtViewSearchHat;
        private System.Windows.Forms.Button btnCancelHat;
        private System.Windows.Forms.TextBox txbPriceHat;
        private System.Windows.Forms.TextBox txbKDHat;
        private System.Windows.Forms.TextBox txbSLHat;
        private System.Windows.Forms.TextBox txbNameHat;
        private System.Windows.Forms.TextBox txbIDHat;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lblIDHat;
        private System.Windows.Forms.DateTimePicker dateTimeNhapHat;
        private System.Windows.Forms.TextBox txbSizeHat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txbPriceQ;
        private System.Windows.Forms.TextBox txbKDQ;
        private System.Windows.Forms.TextBox txbSLQ;
        private System.Windows.Forms.TextBox txbSizeQ;
        private System.Windows.Forms.TextBox txbNameQ;
        private System.Windows.Forms.DateTimePicker dateTimeNhapQ;
        private System.Windows.Forms.TextBox txbIDQ;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCancelQ;
        private System.Windows.Forms.Button btnChangeQ;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txbPriceSock;
        private System.Windows.Forms.TextBox txbKDSock;
        private System.Windows.Forms.TextBox txbSLSock;
        private System.Windows.Forms.TextBox txbSizeSock;
        private System.Windows.Forms.TextBox txbNameSock;
        private System.Windows.Forms.TextBox txbIDSock;
        private System.Windows.Forms.DateTimePicker dateTimeSock;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnCancelSock;
        private System.Windows.Forms.Button btnChangeSock;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAddAo;
        private System.Windows.Forms.Button btnDeleteAo;
        private System.Windows.Forms.Button btnChangeAo;
        private System.Windows.Forms.Button btnCancelAo;
        private System.Windows.Forms.Button btnSearchAo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txbSearchHat;
    }
}