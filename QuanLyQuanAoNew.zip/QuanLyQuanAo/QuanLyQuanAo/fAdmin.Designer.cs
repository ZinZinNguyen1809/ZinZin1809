﻿namespace QuanLyQuanAo
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbHangTonKho = new System.Windows.Forms.TabPage();
            this.btnSearchHangE = new System.Windows.Forms.Button();
            this.btnDeleteHangE = new System.Windows.Forms.Button();
            this.btnAddHangE = new System.Windows.Forms.Button();
            this.dataViewSale = new System.Windows.Forms.DataGridView();
            this.tpSock = new System.Windows.Forms.TabPage();
            this.btAddSock = new System.Windows.Forms.Button();
            this.btnDeleteSock = new System.Windows.Forms.Button();
            this.dataViewSock = new System.Windows.Forms.DataGridView();
            this.btnSearchSock = new System.Windows.Forms.Button();
            this.tpQuan = new System.Windows.Forms.TabPage();
            this.cbBSearchSizeQ = new System.Windows.Forms.ComboBox();
            this.cbBSearchKieuDangQ = new System.Windows.Forms.ComboBox();
            this.dataViewSearchQuan = new System.Windows.Forms.DataGridView();
            this.btnAddQuan = new System.Windows.Forms.Button();
            this.btnDeleteQuan = new System.Windows.Forms.Button();
            this.dataViewQuan = new System.Windows.Forms.DataGridView();
            this.btnSearchQuan = new System.Windows.Forms.Button();
            this.tpAo = new System.Windows.Forms.TabPage();
            this.cbBSearchSize = new System.Windows.Forms.ComboBox();
            this.txbPriceAo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txbKieuDangAo = new System.Windows.Forms.TextBox();
            this.txbSLAddAo = new System.Windows.Forms.TextBox();
            this.txbSizeAo = new System.Windows.Forms.TextBox();
            this.txbNameAo = new System.Windows.Forms.TextBox();
            this.txbDateAddAo = new System.Windows.Forms.TextBox();
            this.txbIDAo = new System.Windows.Forms.TextBox();
            this.cbBSearchAo = new System.Windows.Forms.ComboBox();
            this.dataViewSearchAo = new System.Windows.Forms.DataGridView();
            this.btnAddAo = new System.Windows.Forms.Button();
            this.btnDeleteAo = new System.Windows.Forms.Button();
            this.dataViewAo = new System.Windows.Forms.DataGridView();
            this.btnSearchAo = new System.Windows.Forms.Button();
            this.btnOutAdmin = new System.Windows.Forms.Button();
            this.lblSpriceHat = new System.Windows.Forms.TabPage();
            this.nmUDPriceHat = new System.Windows.Forms.NumericUpDown();
            this.lblSearchPriceHat = new System.Windows.Forms.Label();
            this.cbBDanhmucHat = new System.Windows.Forms.ComboBox();
            this.lblSearchDanhmucHat = new System.Windows.Forms.Label();
            this.txbSearchNameHat = new System.Windows.Forms.TextBox();
            this.txbIDHat = new System.Windows.Forms.TextBox();
            this.txbSearchHat = new System.Windows.Forms.TextBox();
            this.lblSearchNameHat = new System.Windows.Forms.Label();
            this.lblSearchIDHat = new System.Windows.Forms.Label();
            this.btnSearchHat = new System.Windows.Forms.Button();
            this.btnShowHat = new System.Windows.Forms.Button();
            this.btnEditHat = new System.Windows.Forms.Button();
            this.btnDeleteHat = new System.Windows.Forms.Button();
            this.btnAddHat = new System.Windows.Forms.Button();
            this.dataViewHat = new System.Windows.Forms.DataGridView();
            this.tbDoanhthu = new System.Windows.Forms.TabPage();
            this.btnThongKeTienLai = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblMoney = new System.Windows.Forms.Label();
            this.lblLai = new System.Windows.Forms.Label();
            this.btnThongKeDoanhThu = new System.Windows.Forms.Button();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tb9 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataViewSearchSock = new System.Windows.Forms.DataGridView();
            this.cbBSearchKDSock = new System.Windows.Forms.ComboBox();
            this.dataViewSearchSale = new System.Windows.Forms.DataGridView();
            this.cbBSearchKDSale = new System.Windows.Forms.ComboBox();
            this.cbBSearchSizeSale = new System.Windows.Forms.ComboBox();
            this.cbBSearchLoaiSale = new System.Windows.Forms.ComboBox();
            this.tbHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSale)).BeginInit();
            this.tpSock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).BeginInit();
            this.tpQuan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).BeginInit();
            this.tpAo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchAo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).BeginInit();
            this.lblSpriceHat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceHat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).BeginInit();
            this.tbDoanhthu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tb9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSale)).BeginInit();
            this.SuspendLayout();
            // 
            // tbHangTonKho
            // 
            this.tbHangTonKho.Controls.Add(this.cbBSearchLoaiSale);
            this.tbHangTonKho.Controls.Add(this.cbBSearchSizeSale);
            this.tbHangTonKho.Controls.Add(this.cbBSearchKDSale);
            this.tbHangTonKho.Controls.Add(this.dataViewSearchSale);
            this.tbHangTonKho.Controls.Add(this.btnSearchHangE);
            this.tbHangTonKho.Controls.Add(this.btnDeleteHangE);
            this.tbHangTonKho.Controls.Add(this.btnAddHangE);
            this.tbHangTonKho.Controls.Add(this.dataViewSale);
            this.tbHangTonKho.Location = new System.Drawing.Point(4, 25);
            this.tbHangTonKho.Name = "tbHangTonKho";
            this.tbHangTonKho.Padding = new System.Windows.Forms.Padding(3);
            this.tbHangTonKho.Size = new System.Drawing.Size(1155, 622);
            this.tbHangTonKho.TabIndex = 5;
            this.tbHangTonKho.Text = "Hàng tồn kho";
            this.tbHangTonKho.UseVisualStyleBackColor = true;
            // 
            // btnSearchHangE
            // 
            this.btnSearchHangE.Location = new System.Drawing.Point(6, 452);
            this.btnSearchHangE.Name = "btnSearchHangE";
            this.btnSearchHangE.Size = new System.Drawing.Size(99, 164);
            this.btnSearchHangE.TabIndex = 27;
            this.btnSearchHangE.Text = "Tìm";
            this.btnSearchHangE.UseVisualStyleBackColor = true;
            this.btnSearchHangE.Click += new System.EventHandler(this.btnSearchHangE_Click);
            // 
            // btnDeleteHangE
            // 
            this.btnDeleteHangE.Location = new System.Drawing.Point(6, 219);
            this.btnDeleteHangE.Name = "btnDeleteHangE";
            this.btnDeleteHangE.Size = new System.Drawing.Size(109, 71);
            this.btnDeleteHangE.TabIndex = 23;
            this.btnDeleteHangE.Text = "Xóa";
            this.btnDeleteHangE.UseVisualStyleBackColor = true;
            this.btnDeleteHangE.Click += new System.EventHandler(this.btnDeleteHangE_Click);
            // 
            // btnAddHangE
            // 
            this.btnAddHangE.Location = new System.Drawing.Point(6, 6);
            this.btnAddHangE.Name = "btnAddHangE";
            this.btnAddHangE.Size = new System.Drawing.Size(99, 71);
            this.btnAddHangE.TabIndex = 22;
            this.btnAddHangE.Text = "Thêm hàng tồn kho";
            this.btnAddHangE.UseVisualStyleBackColor = true;
            // 
            // dataViewSale
            // 
            this.dataViewSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSale.Location = new System.Drawing.Point(580, 6);
            this.dataViewSale.Name = "dataViewSale";
            this.dataViewSale.RowHeadersWidth = 51;
            this.dataViewSale.RowTemplate.Height = 24;
            this.dataViewSale.Size = new System.Drawing.Size(556, 257);
            this.dataViewSale.TabIndex = 9;
            // 
            // tpSock
            // 
            this.tpSock.Controls.Add(this.cbBSearchKDSock);
            this.tpSock.Controls.Add(this.dataViewSearchSock);
            this.tpSock.Controls.Add(this.btAddSock);
            this.tpSock.Controls.Add(this.btnDeleteSock);
            this.tpSock.Controls.Add(this.dataViewSock);
            this.tpSock.Controls.Add(this.btnSearchSock);
            this.tpSock.Location = new System.Drawing.Point(4, 25);
            this.tpSock.Name = "tpSock";
            this.tpSock.Padding = new System.Windows.Forms.Padding(3);
            this.tpSock.Size = new System.Drawing.Size(1155, 622);
            this.tpSock.TabIndex = 4;
            this.tpSock.Text = "Vớ";
            this.tpSock.UseVisualStyleBackColor = true;
            this.tpSock.Click += new System.EventHandler(this.tpSock_Click);
            // 
            // btAddSock
            // 
            this.btAddSock.Location = new System.Drawing.Point(17, 6);
            this.btAddSock.Name = "btAddSock";
            this.btAddSock.Size = new System.Drawing.Size(99, 71);
            this.btAddSock.TabIndex = 21;
            this.btAddSock.Text = "Thêm vào kho hàng";
            this.btAddSock.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSock
            // 
            this.btnDeleteSock.Location = new System.Drawing.Point(17, 180);
            this.btnDeleteSock.Name = "btnDeleteSock";
            this.btnDeleteSock.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteSock.TabIndex = 20;
            this.btnDeleteSock.Text = "Xóa";
            this.btnDeleteSock.UseVisualStyleBackColor = true;
            // 
            // dataViewSock
            // 
            this.dataViewSock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSock.Location = new System.Drawing.Point(618, 6);
            this.dataViewSock.Name = "dataViewSock";
            this.dataViewSock.RowHeadersWidth = 51;
            this.dataViewSock.RowTemplate.Height = 24;
            this.dataViewSock.Size = new System.Drawing.Size(469, 230);
            this.dataViewSock.TabIndex = 8;
            // 
            // btnSearchSock
            // 
            this.btnSearchSock.Location = new System.Drawing.Point(17, 432);
            this.btnSearchSock.Name = "btnSearchSock";
            this.btnSearchSock.Size = new System.Drawing.Size(99, 71);
            this.btnSearchSock.TabIndex = 7;
            this.btnSearchSock.Text = "Tìm";
            this.btnSearchSock.UseVisualStyleBackColor = true;
            this.btnSearchSock.Click += new System.EventHandler(this.btnSearchSock_Click);
            // 
            // tpQuan
            // 
            this.tpQuan.Controls.Add(this.cbBSearchSizeQ);
            this.tpQuan.Controls.Add(this.cbBSearchKieuDangQ);
            this.tpQuan.Controls.Add(this.dataViewSearchQuan);
            this.tpQuan.Controls.Add(this.btnAddQuan);
            this.tpQuan.Controls.Add(this.btnDeleteQuan);
            this.tpQuan.Controls.Add(this.dataViewQuan);
            this.tpQuan.Controls.Add(this.btnSearchQuan);
            this.tpQuan.Location = new System.Drawing.Point(4, 25);
            this.tpQuan.Name = "tpQuan";
            this.tpQuan.Padding = new System.Windows.Forms.Padding(3);
            this.tpQuan.Size = new System.Drawing.Size(1155, 622);
            this.tpQuan.TabIndex = 3;
            this.tpQuan.Text = "Quần";
            this.tpQuan.UseVisualStyleBackColor = true;
            this.tpQuan.Click += new System.EventHandler(this.tpQuan_Click);
            // 
            // cbBSearchSizeQ
            // 
            this.cbBSearchSizeQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSizeQ.FormattingEnabled = true;
            this.cbBSearchSizeQ.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL"});
            this.cbBSearchSizeQ.Location = new System.Drawing.Point(130, 524);
            this.cbBSearchSizeQ.Name = "cbBSearchSizeQ";
            this.cbBSearchSizeQ.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchSizeQ.TabIndex = 25;
            // 
            // cbBSearchKieuDangQ
            // 
            this.cbBSearchKieuDangQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKieuDangQ.FormattingEnabled = true;
            this.cbBSearchKieuDangQ.Items.AddRange(new object[] {
            "QuanNam",
            "QuanNu"});
            this.cbBSearchKieuDangQ.Location = new System.Drawing.Point(130, 463);
            this.cbBSearchKieuDangQ.Name = "cbBSearchKieuDangQ";
            this.cbBSearchKieuDangQ.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchKieuDangQ.TabIndex = 24;
            this.cbBSearchKieuDangQ.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataViewSearchQuan
            // 
            this.dataViewSearchQuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchQuan.Location = new System.Drawing.Point(580, 451);
            this.dataViewSearchQuan.Name = "dataViewSearchQuan";
            this.dataViewSearchQuan.RowHeadersWidth = 51;
            this.dataViewSearchQuan.RowTemplate.Height = 24;
            this.dataViewSearchQuan.Size = new System.Drawing.Size(569, 165);
            this.dataViewSearchQuan.TabIndex = 22;
            this.dataViewSearchQuan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtViewSearchQuan_CellContentClick);
            // 
            // btnAddQuan
            // 
            this.btnAddQuan.Location = new System.Drawing.Point(6, 6);
            this.btnAddQuan.Name = "btnAddQuan";
            this.btnAddQuan.Size = new System.Drawing.Size(99, 121);
            this.btnAddQuan.TabIndex = 21;
            this.btnAddQuan.Text = "Thêm vào kho hàng";
            this.btnAddQuan.UseVisualStyleBackColor = true;
            this.btnAddQuan.Click += new System.EventHandler(this.btnAddQuan_Click);
            // 
            // btnDeleteQuan
            // 
            this.btnDeleteQuan.Location = new System.Drawing.Point(6, 197);
            this.btnDeleteQuan.Name = "btnDeleteQuan";
            this.btnDeleteQuan.Size = new System.Drawing.Size(99, 129);
            this.btnDeleteQuan.TabIndex = 20;
            this.btnDeleteQuan.Text = "Xóa";
            this.btnDeleteQuan.UseVisualStyleBackColor = true;
            // 
            // dataViewQuan
            // 
            this.dataViewQuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewQuan.Location = new System.Drawing.Point(580, 6);
            this.dataViewQuan.Name = "dataViewQuan";
            this.dataViewQuan.RowHeadersWidth = 51;
            this.dataViewQuan.RowTemplate.Height = 24;
            this.dataViewQuan.Size = new System.Drawing.Size(556, 293);
            this.dataViewQuan.TabIndex = 8;
            this.dataViewQuan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewQuan_CellContentClick);
            // 
            // btnSearchQuan
            // 
            this.btnSearchQuan.Location = new System.Drawing.Point(6, 451);
            this.btnSearchQuan.Name = "btnSearchQuan";
            this.btnSearchQuan.Size = new System.Drawing.Size(99, 110);
            this.btnSearchQuan.TabIndex = 7;
            this.btnSearchQuan.Text = "Tìm";
            this.btnSearchQuan.UseVisualStyleBackColor = true;
            this.btnSearchQuan.Click += new System.EventHandler(this.btnSearchQuan_Click);
            // 
            // tpAo
            // 
            this.tpAo.Controls.Add(this.cbBSearchSize);
            this.tpAo.Controls.Add(this.txbPriceAo);
            this.tpAo.Controls.Add(this.label7);
            this.tpAo.Controls.Add(this.label6);
            this.tpAo.Controls.Add(this.label5);
            this.tpAo.Controls.Add(this.label4);
            this.tpAo.Controls.Add(this.label3);
            this.tpAo.Controls.Add(this.label2);
            this.tpAo.Controls.Add(this.label1);
            this.tpAo.Controls.Add(this.txbKieuDangAo);
            this.tpAo.Controls.Add(this.txbSLAddAo);
            this.tpAo.Controls.Add(this.txbSizeAo);
            this.tpAo.Controls.Add(this.txbNameAo);
            this.tpAo.Controls.Add(this.txbDateAddAo);
            this.tpAo.Controls.Add(this.txbIDAo);
            this.tpAo.Controls.Add(this.cbBSearchAo);
            this.tpAo.Controls.Add(this.dataViewSearchAo);
            this.tpAo.Controls.Add(this.btnAddAo);
            this.tpAo.Controls.Add(this.btnDeleteAo);
            this.tpAo.Controls.Add(this.dataViewAo);
            this.tpAo.Controls.Add(this.btnSearchAo);
            this.tpAo.Location = new System.Drawing.Point(4, 25);
            this.tpAo.Name = "tpAo";
            this.tpAo.Padding = new System.Windows.Forms.Padding(3);
            this.tpAo.Size = new System.Drawing.Size(1155, 622);
            this.tpAo.TabIndex = 2;
            this.tpAo.Text = "Áo";
            this.tpAo.UseVisualStyleBackColor = true;
            this.tpAo.Click += new System.EventHandler(this.tpAo_Click);
            // 
            // cbBSearchSize
            // 
            this.cbBSearchSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSize.FormattingEnabled = true;
            this.cbBSearchSize.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cbBSearchSize.Location = new System.Drawing.Point(120, 543);
            this.cbBSearchSize.Name = "cbBSearchSize";
            this.cbBSearchSize.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchSize.TabIndex = 39;
            this.cbBSearchSize.SelectedIndexChanged += new System.EventHandler(this.cbBSearchSize_SelectedIndexChanged);
            // 
            // txbPriceAo
            // 
            this.txbPriceAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPriceAo.Location = new System.Drawing.Point(312, 413);
            this.txbPriceAo.Name = "txbPriceAo";
            this.txbPriceAo.Size = new System.Drawing.Size(220, 30);
            this.txbPriceAo.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(111, 413);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 25);
            this.label7.TabIndex = 37;
            this.label7.Text = "Giá áo";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(112, 356);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 25);
            this.label6.TabIndex = 36;
            this.label6.Text = "Kiểu dáng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(115, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(175, 25);
            this.label5.TabIndex = 35;
            this.label5.Text = "Số lượng cần thêm";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(112, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 25);
            this.label4.TabIndex = 34;
            this.label4.Text = "Size áo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Tên áo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(111, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 25);
            this.label2.TabIndex = 32;
            this.label2.Text = "Ngày nhập áo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(112, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 25);
            this.label1.TabIndex = 31;
            this.label1.Text = "ID áo";
            // 
            // txbKieuDangAo
            // 
            this.txbKieuDangAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbKieuDangAo.Location = new System.Drawing.Point(311, 356);
            this.txbKieuDangAo.Name = "txbKieuDangAo";
            this.txbKieuDangAo.Size = new System.Drawing.Size(220, 30);
            this.txbKieuDangAo.TabIndex = 29;
            // 
            // txbSLAddAo
            // 
            this.txbSLAddAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSLAddAo.Location = new System.Drawing.Point(312, 297);
            this.txbSLAddAo.Name = "txbSLAddAo";
            this.txbSLAddAo.Size = new System.Drawing.Size(220, 30);
            this.txbSLAddAo.TabIndex = 28;
            // 
            // txbSizeAo
            // 
            this.txbSizeAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSizeAo.Location = new System.Drawing.Point(312, 227);
            this.txbSizeAo.Name = "txbSizeAo";
            this.txbSizeAo.Size = new System.Drawing.Size(220, 30);
            this.txbSizeAo.TabIndex = 27;
            // 
            // txbNameAo
            // 
            this.txbNameAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNameAo.Location = new System.Drawing.Point(312, 148);
            this.txbNameAo.Name = "txbNameAo";
            this.txbNameAo.Size = new System.Drawing.Size(220, 30);
            this.txbNameAo.TabIndex = 26;
            // 
            // txbDateAddAo
            // 
            this.txbDateAddAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbDateAddAo.Location = new System.Drawing.Point(312, 80);
            this.txbDateAddAo.Name = "txbDateAddAo";
            this.txbDateAddAo.Size = new System.Drawing.Size(220, 30);
            this.txbDateAddAo.TabIndex = 25;
            // 
            // txbIDAo
            // 
            this.txbIDAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDAo.Location = new System.Drawing.Point(312, 6);
            this.txbIDAo.Name = "txbIDAo";
            this.txbIDAo.Size = new System.Drawing.Size(220, 30);
            this.txbIDAo.TabIndex = 24;
            // 
            // cbBSearchAo
            // 
            this.cbBSearchAo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchAo.FormattingEnabled = true;
            this.cbBSearchAo.Items.AddRange(new object[] {
            "AoNam",
            "AoNu",
            ""});
            this.cbBSearchAo.Location = new System.Drawing.Point(120, 484);
            this.cbBSearchAo.Name = "cbBSearchAo";
            this.cbBSearchAo.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchAo.TabIndex = 23;
            this.cbBSearchAo.SelectedIndexChanged += new System.EventHandler(this.cbBSearchAo_SelectedIndexChanged);
            // 
            // dataViewSearchAo
            // 
            this.dataViewSearchAo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchAo.Location = new System.Drawing.Point(541, 484);
            this.dataViewSearchAo.Name = "dataViewSearchAo";
            this.dataViewSearchAo.RowHeadersWidth = 51;
            this.dataViewSearchAo.RowTemplate.Height = 24;
            this.dataViewSearchAo.Size = new System.Drawing.Size(608, 132);
            this.dataViewSearchAo.TabIndex = 22;
            // 
            // btnAddAo
            // 
            this.btnAddAo.Location = new System.Drawing.Point(6, 20);
            this.btnAddAo.Name = "btnAddAo";
            this.btnAddAo.Size = new System.Drawing.Size(99, 118);
            this.btnAddAo.TabIndex = 21;
            this.btnAddAo.Text = "Thêm áo vào kho hàng";
            this.btnAddAo.UseVisualStyleBackColor = true;
            this.btnAddAo.Click += new System.EventHandler(this.btnAddAo_Click);
            // 
            // btnDeleteAo
            // 
            this.btnDeleteAo.Location = new System.Drawing.Point(6, 227);
            this.btnDeleteAo.Name = "btnDeleteAo";
            this.btnDeleteAo.Size = new System.Drawing.Size(99, 109);
            this.btnDeleteAo.TabIndex = 20;
            this.btnDeleteAo.Text = "Xóa áo (hàng hư hoặc vừa bán)";
            this.btnDeleteAo.UseVisualStyleBackColor = true;
            this.btnDeleteAo.Click += new System.EventHandler(this.btnDeleteAo_Click);
            // 
            // dataViewAo
            // 
            this.dataViewAo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewAo.Location = new System.Drawing.Point(541, 6);
            this.dataViewAo.Name = "dataViewAo";
            this.dataViewAo.RowHeadersWidth = 51;
            this.dataViewAo.RowTemplate.Height = 24;
            this.dataViewAo.Size = new System.Drawing.Size(608, 437);
            this.dataViewAo.TabIndex = 8;
            this.dataViewAo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewAo_CellContentClick);
            // 
            // btnSearchAo
            // 
            this.btnSearchAo.Location = new System.Drawing.Point(6, 484);
            this.btnSearchAo.Name = "btnSearchAo";
            this.btnSearchAo.Size = new System.Drawing.Size(99, 96);
            this.btnSearchAo.TabIndex = 7;
            this.btnSearchAo.Text = "Tìm";
            this.btnSearchAo.UseVisualStyleBackColor = true;
            this.btnSearchAo.Click += new System.EventHandler(this.btnSearchAo_Click);
            // 
            // btnOutAdmin
            // 
            this.btnOutAdmin.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnOutAdmin.Location = new System.Drawing.Point(1076, 684);
            this.btnOutAdmin.Name = "btnOutAdmin";
            this.btnOutAdmin.Size = new System.Drawing.Size(99, 74);
            this.btnOutAdmin.TabIndex = 13;
            this.btnOutAdmin.Text = "Thoát";
            this.btnOutAdmin.UseVisualStyleBackColor = true;
            this.btnOutAdmin.Click += new System.EventHandler(this.btnOutAdmin_Click);
            // 
            // lblSpriceHat
            // 
            this.lblSpriceHat.Controls.Add(this.nmUDPriceHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchPriceHat);
            this.lblSpriceHat.Controls.Add(this.cbBDanhmucHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchDanhmucHat);
            this.lblSpriceHat.Controls.Add(this.txbSearchNameHat);
            this.lblSpriceHat.Controls.Add(this.txbIDHat);
            this.lblSpriceHat.Controls.Add(this.txbSearchHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchNameHat);
            this.lblSpriceHat.Controls.Add(this.lblSearchIDHat);
            this.lblSpriceHat.Controls.Add(this.btnSearchHat);
            this.lblSpriceHat.Controls.Add(this.btnShowHat);
            this.lblSpriceHat.Controls.Add(this.btnEditHat);
            this.lblSpriceHat.Controls.Add(this.btnDeleteHat);
            this.lblSpriceHat.Controls.Add(this.btnAddHat);
            this.lblSpriceHat.Controls.Add(this.dataViewHat);
            this.lblSpriceHat.Location = new System.Drawing.Point(4, 25);
            this.lblSpriceHat.Name = "lblSpriceHat";
            this.lblSpriceHat.Padding = new System.Windows.Forms.Padding(3);
            this.lblSpriceHat.Size = new System.Drawing.Size(1155, 622);
            this.lblSpriceHat.TabIndex = 1;
            this.lblSpriceHat.Text = "Nón";
            this.lblSpriceHat.UseVisualStyleBackColor = true;
            this.lblSpriceHat.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // nmUDPriceHat
            // 
            this.nmUDPriceHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmUDPriceHat.Location = new System.Drawing.Point(684, 334);
            this.nmUDPriceHat.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nmUDPriceHat.Name = "nmUDPriceHat";
            this.nmUDPriceHat.Size = new System.Drawing.Size(272, 36);
            this.nmUDPriceHat.TabIndex = 14;
            // 
            // lblSearchPriceHat
            // 
            this.lblSearchPriceHat.AutoSize = true;
            this.lblSearchPriceHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchPriceHat.Location = new System.Drawing.Point(497, 334);
            this.lblSearchPriceHat.Name = "lblSearchPriceHat";
            this.lblSearchPriceHat.Size = new System.Drawing.Size(79, 39);
            this.lblSearchPriceHat.TabIndex = 13;
            this.lblSearchPriceHat.Text = "Giá:";
            // 
            // cbBDanhmucHat
            // 
            this.cbBDanhmucHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBDanhmucHat.FormattingEnabled = true;
            this.cbBDanhmucHat.Location = new System.Drawing.Point(684, 258);
            this.cbBDanhmucHat.Name = "cbBDanhmucHat";
            this.cbBDanhmucHat.Size = new System.Drawing.Size(272, 37);
            this.cbBDanhmucHat.TabIndex = 12;
            // 
            // lblSearchDanhmucHat
            // 
            this.lblSearchDanhmucHat.AutoSize = true;
            this.lblSearchDanhmucHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDanhmucHat.Location = new System.Drawing.Point(497, 258);
            this.lblSearchDanhmucHat.Name = "lblSearchDanhmucHat";
            this.lblSearchDanhmucHat.Size = new System.Drawing.Size(181, 39);
            this.lblSearchDanhmucHat.TabIndex = 11;
            this.lblSearchDanhmucHat.Text = "Danh mục:";
            this.lblSearchDanhmucHat.Click += new System.EventHandler(this.label2_Click);
            // 
            // txbSearchNameHat
            // 
            this.txbSearchNameHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchNameHat.Location = new System.Drawing.Point(684, 183);
            this.txbSearchNameHat.Name = "txbSearchNameHat";
            this.txbSearchNameHat.Size = new System.Drawing.Size(272, 36);
            this.txbSearchNameHat.TabIndex = 10;
            // 
            // txbIDHat
            // 
            this.txbIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbIDHat.Location = new System.Drawing.Point(684, 104);
            this.txbIDHat.Name = "txbIDHat";
            this.txbIDHat.ReadOnly = true;
            this.txbIDHat.Size = new System.Drawing.Size(272, 36);
            this.txbIDHat.TabIndex = 8;
            this.txbIDHat.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txbSearchHat
            // 
            this.txbSearchHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSearchHat.Location = new System.Drawing.Point(579, 23);
            this.txbSearchHat.Name = "txbSearchHat";
            this.txbSearchHat.Size = new System.Drawing.Size(262, 36);
            this.txbSearchHat.TabIndex = 6;
            // 
            // lblSearchNameHat
            // 
            this.lblSearchNameHat.AutoSize = true;
            this.lblSearchNameHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchNameHat.Location = new System.Drawing.Point(497, 183);
            this.lblSearchNameHat.Name = "lblSearchNameHat";
            this.lblSearchNameHat.Size = new System.Drawing.Size(151, 39);
            this.lblSearchNameHat.TabIndex = 9;
            this.lblSearchNameHat.Text = "Tên nón:";
            // 
            // lblSearchIDHat
            // 
            this.lblSearchIDHat.AutoSize = true;
            this.lblSearchIDHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchIDHat.Location = new System.Drawing.Point(497, 104);
            this.lblSearchIDHat.Name = "lblSearchIDHat";
            this.lblSearchIDHat.Size = new System.Drawing.Size(61, 39);
            this.lblSearchIDHat.TabIndex = 7;
            this.lblSearchIDHat.Text = "ID:";
            this.lblSearchIDHat.Click += new System.EventHandler(this.lblID_Click);
            // 
            // btnSearchHat
            // 
            this.btnSearchHat.Location = new System.Drawing.Point(857, 6);
            this.btnSearchHat.Name = "btnSearchHat";
            this.btnSearchHat.Size = new System.Drawing.Size(99, 71);
            this.btnSearchHat.TabIndex = 5;
            this.btnSearchHat.Text = "Tìm";
            this.btnSearchHat.UseVisualStyleBackColor = true;
            // 
            // btnShowHat
            // 
            this.btnShowHat.Location = new System.Drawing.Point(376, 6);
            this.btnShowHat.Name = "btnShowHat";
            this.btnShowHat.Size = new System.Drawing.Size(99, 71);
            this.btnShowHat.TabIndex = 4;
            this.btnShowHat.Text = "Kiểm tra hàng";
            this.btnShowHat.UseVisualStyleBackColor = true;
            this.btnShowHat.Click += new System.EventHandler(this.btnShowHat_Click);
            // 
            // btnEditHat
            // 
            this.btnEditHat.Location = new System.Drawing.Point(251, 6);
            this.btnEditHat.Name = "btnEditHat";
            this.btnEditHat.Size = new System.Drawing.Size(99, 71);
            this.btnEditHat.TabIndex = 3;
            this.btnEditHat.Text = "Sửa đổi thông tin hàng";
            this.btnEditHat.UseVisualStyleBackColor = true;
            // 
            // btnDeleteHat
            // 
            this.btnDeleteHat.Location = new System.Drawing.Point(129, 6);
            this.btnDeleteHat.Name = "btnDeleteHat";
            this.btnDeleteHat.Size = new System.Drawing.Size(99, 71);
            this.btnDeleteHat.TabIndex = 2;
            this.btnDeleteHat.Text = "Xóa";
            this.btnDeleteHat.UseVisualStyleBackColor = true;
            // 
            // btnAddHat
            // 
            this.btnAddHat.Location = new System.Drawing.Point(6, 6);
            this.btnAddHat.Name = "btnAddHat";
            this.btnAddHat.Size = new System.Drawing.Size(99, 71);
            this.btnAddHat.TabIndex = 1;
            this.btnAddHat.Text = "Thêm vào kho hàng";
            this.btnAddHat.UseVisualStyleBackColor = true;
            this.btnAddHat.Click += new System.EventHandler(this.btnAddHat_Click);
            // 
            // dataViewHat
            // 
            this.dataViewHat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewHat.Location = new System.Drawing.Point(6, 104);
            this.dataViewHat.Name = "dataViewHat";
            this.dataViewHat.RowHeadersWidth = 51;
            this.dataViewHat.RowTemplate.Height = 24;
            this.dataViewHat.Size = new System.Drawing.Size(469, 456);
            this.dataViewHat.TabIndex = 0;
            // 
            // tbDoanhthu
            // 
            this.tbDoanhthu.Controls.Add(this.btnThongKeTienLai);
            this.tbDoanhthu.Controls.Add(this.textBox2);
            this.tbDoanhthu.Controls.Add(this.textBox1);
            this.tbDoanhthu.Controls.Add(this.lblMoney);
            this.tbDoanhthu.Controls.Add(this.lblLai);
            this.tbDoanhthu.Controls.Add(this.btnThongKeDoanhThu);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker4);
            this.tbDoanhthu.Controls.Add(this.dateTimePicker3);
            this.tbDoanhthu.Controls.Add(this.dataGridView2);
            this.tbDoanhthu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDoanhthu.Location = new System.Drawing.Point(4, 25);
            this.tbDoanhthu.Name = "tbDoanhthu";
            this.tbDoanhthu.Padding = new System.Windows.Forms.Padding(3);
            this.tbDoanhthu.Size = new System.Drawing.Size(1155, 622);
            this.tbDoanhthu.TabIndex = 0;
            this.tbDoanhthu.Text = "Doanh thu";
            this.tbDoanhthu.UseVisualStyleBackColor = true;
            this.tbDoanhthu.Click += new System.EventHandler(this.tbDoanhthu_Click);
            // 
            // btnThongKeTienLai
            // 
            this.btnThongKeTienLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeTienLai.Location = new System.Drawing.Point(544, 60);
            this.btnThongKeTienLai.Name = "btnThongKeTienLai";
            this.btnThongKeTienLai.Size = new System.Drawing.Size(140, 70);
            this.btnThongKeTienLai.TabIndex = 9;
            this.btnThongKeTienLai.Text = "Tra cứu doanh thu";
            this.btnThongKeTienLai.UseVisualStyleBackColor = true;
            this.btnThongKeTienLai.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(856, 109);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 27);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(856, 60);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 27);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // lblMoney
            // 
            this.lblMoney.AutoSize = true;
            this.lblMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoney.Location = new System.Drawing.Point(690, 101);
            this.lblMoney.Name = "lblMoney";
            this.lblMoney.Size = new System.Drawing.Size(166, 29);
            this.lblMoney.TabIndex = 6;
            this.lblMoney.Text = "Tiền thu được";
            // 
            // lblLai
            // 
            this.lblLai.AutoSize = true;
            this.lblLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLai.Location = new System.Drawing.Point(690, 60);
            this.lblLai.Name = "lblLai";
            this.lblLai.Size = new System.Drawing.Size(47, 29);
            this.lblLai.TabIndex = 5;
            this.lblLai.Text = "Lãi";
            // 
            // btnThongKeDoanhThu
            // 
            this.btnThongKeDoanhThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKeDoanhThu.Location = new System.Drawing.Point(356, 9);
            this.btnThongKeDoanhThu.Name = "btnThongKeDoanhThu";
            this.btnThongKeDoanhThu.Size = new System.Drawing.Size(130, 57);
            this.btnThongKeDoanhThu.TabIndex = 4;
            this.btnThongKeDoanhThu.Text = "Thống kê hàng đã bán";
            this.btnThongKeDoanhThu.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Location = new System.Drawing.Point(590, 12);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(327, 30);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(18, 11);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(330, 30);
            this.dateTimePicker3.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(18, 72);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(468, 424);
            this.dataGridView2.TabIndex = 1;
            // 
            // tb9
            // 
            this.tb9.Controls.Add(this.tbDoanhthu);
            this.tb9.Controls.Add(this.lblSpriceHat);
            this.tb9.Controls.Add(this.tpAo);
            this.tb9.Controls.Add(this.tpQuan);
            this.tb9.Controls.Add(this.tpSock);
            this.tb9.Controls.Add(this.tbHangTonKho);
            this.tb9.Controls.Add(this.tabPage1);
            this.tb9.Location = new System.Drawing.Point(12, 27);
            this.tb9.Name = "tb9";
            this.tb9.SelectedIndex = 0;
            this.tb9.Size = new System.Drawing.Size(1163, 651);
            this.tb9.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1155, 622);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataViewSearchSock
            // 
            this.dataViewSearchSock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchSock.Location = new System.Drawing.Point(618, 432);
            this.dataViewSearchSock.Name = "dataViewSearchSock";
            this.dataViewSearchSock.RowHeadersWidth = 51;
            this.dataViewSearchSock.RowTemplate.Height = 24;
            this.dataViewSearchSock.Size = new System.Drawing.Size(469, 187);
            this.dataViewSearchSock.TabIndex = 22;
            // 
            // cbBSearchKDSock
            // 
            this.cbBSearchKDSock.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKDSock.FormattingEnabled = true;
            this.cbBSearchKDSock.Items.AddRange(new object[] {
            "VoNam",
            "VoNu"});
            this.cbBSearchKDSock.Location = new System.Drawing.Point(162, 432);
            this.cbBSearchKDSock.Name = "cbBSearchKDSock";
            this.cbBSearchKDSock.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchKDSock.TabIndex = 25;
            // 
            // dataViewSearchSale
            // 
            this.dataViewSearchSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewSearchSale.Location = new System.Drawing.Point(580, 452);
            this.dataViewSearchSale.Name = "dataViewSearchSale";
            this.dataViewSearchSale.RowHeadersWidth = 51;
            this.dataViewSearchSale.RowTemplate.Height = 24;
            this.dataViewSearchSale.Size = new System.Drawing.Size(547, 164);
            this.dataViewSearchSale.TabIndex = 28;
            this.dataViewSearchSale.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataViewSearchSale_CellContentClick);
            // 
            // cbBSearchKDSale
            // 
            this.cbBSearchKDSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchKDSale.FormattingEnabled = true;
            this.cbBSearchKDSale.Items.AddRange(new object[] {
            "Nam",
            "Nu"});
            this.cbBSearchKDSale.Location = new System.Drawing.Point(119, 452);
            this.cbBSearchKDSale.Name = "cbBSearchKDSale";
            this.cbBSearchKDSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchKDSale.TabIndex = 29;
            this.cbBSearchKDSale.SelectedIndexChanged += new System.EventHandler(this.cbBSearchKDSale_SelectedIndexChanged);
            // 
            // cbBSearchSizeSale
            // 
            this.cbBSearchSizeSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchSizeSale.FormattingEnabled = true;
            this.cbBSearchSizeSale.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cbBSearchSizeSale.Location = new System.Drawing.Point(119, 516);
            this.cbBSearchSizeSale.Name = "cbBSearchSizeSale";
            this.cbBSearchSizeSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchSizeSale.TabIndex = 40;
            // 
            // cbBSearchLoaiSale
            // 
            this.cbBSearchLoaiSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBSearchLoaiSale.FormattingEnabled = true;
            this.cbBSearchLoaiSale.Items.AddRange(new object[] {
            "Non(tất cả có chung size M)",
            "Ao",
            "Quan",
            "Vớ(tất cả có chung size M)"});
            this.cbBSearchLoaiSale.Location = new System.Drawing.Point(119, 582);
            this.cbBSearchLoaiSale.Name = "cbBSearchLoaiSale";
            this.cbBSearchLoaiSale.Size = new System.Drawing.Size(415, 37);
            this.cbBSearchLoaiSale.TabIndex = 41;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 760);
            this.Controls.Add(this.tb9);
            this.Controls.Add(this.btnOutAdmin);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.tbHangTonKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSale)).EndInit();
            this.tpSock.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSock)).EndInit();
            this.tpQuan.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewQuan)).EndInit();
            this.tpAo.ResumeLayout(false);
            this.tpAo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchAo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewAo)).EndInit();
            this.lblSpriceHat.ResumeLayout(false);
            this.lblSpriceHat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmUDPriceHat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewHat)).EndInit();
            this.tbDoanhthu.ResumeLayout(false);
            this.tbDoanhthu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tb9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewSearchSale)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tbHangTonKho;
        private System.Windows.Forms.Button btnSearchHangE;
        private System.Windows.Forms.Button btnDeleteHangE;
        private System.Windows.Forms.Button btnAddHangE;
        private System.Windows.Forms.DataGridView dataViewSale;
        private System.Windows.Forms.TabPage tpSock;
        private System.Windows.Forms.Button btAddSock;
        private System.Windows.Forms.Button btnDeleteSock;
        private System.Windows.Forms.DataGridView dataViewSock;
        private System.Windows.Forms.Button btnSearchSock;
        private System.Windows.Forms.TabPage tpQuan;
        private System.Windows.Forms.Button btnAddQuan;
        private System.Windows.Forms.Button btnDeleteQuan;
        private System.Windows.Forms.Button btnSearchQuan;
        private System.Windows.Forms.TabPage tpAo;
        private System.Windows.Forms.Button btnAddAo;
        private System.Windows.Forms.Button btnDeleteAo;
        private System.Windows.Forms.DataGridView dataViewAo;
        private System.Windows.Forms.Button btnSearchAo;
        private System.Windows.Forms.TabPage lblSpriceHat;
        private System.Windows.Forms.NumericUpDown nmUDPriceHat;
        private System.Windows.Forms.Label lblSearchPriceHat;
        private System.Windows.Forms.ComboBox cbBDanhmucHat;
        private System.Windows.Forms.Label lblSearchDanhmucHat;
        private System.Windows.Forms.TextBox txbSearchNameHat;
        private System.Windows.Forms.TextBox txbIDHat;
        private System.Windows.Forms.TextBox txbSearchHat;
        private System.Windows.Forms.Label lblSearchNameHat;
        private System.Windows.Forms.Label lblSearchIDHat;
        private System.Windows.Forms.Button btnSearchHat;
        private System.Windows.Forms.Button btnShowHat;
        private System.Windows.Forms.Button btnEditHat;
        private System.Windows.Forms.Button btnDeleteHat;
        private System.Windows.Forms.Button btnAddHat;
        private System.Windows.Forms.DataGridView dataViewHat;
        private System.Windows.Forms.TabPage tbDoanhthu;
        private System.Windows.Forms.Button btnThongKeDoanhThu;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabControl tb9;
        private System.Windows.Forms.Button btnOutAdmin;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblMoney;
        private System.Windows.Forms.Label lblLai;
        private System.Windows.Forms.Button btnThongKeTienLai;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox cbBSearchAo;
        private System.Windows.Forms.DataGridView dataViewSearchAo;
        private System.Windows.Forms.TextBox txbKieuDangAo;
        private System.Windows.Forms.TextBox txbSLAddAo;
        private System.Windows.Forms.TextBox txbSizeAo;
        private System.Windows.Forms.TextBox txbNameAo;
        private System.Windows.Forms.TextBox txbDateAddAo;
        private System.Windows.Forms.TextBox txbIDAo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txbPriceAo;
        private System.Windows.Forms.ComboBox cbBSearchSize;
        private System.Windows.Forms.ComboBox cbBSearchSizeQ;
        private System.Windows.Forms.ComboBox cbBSearchKieuDangQ;
        private System.Windows.Forms.DataGridView dataViewSearchQuan;
        private System.Windows.Forms.DataGridView dataViewQuan;
        private System.Windows.Forms.ComboBox cbBSearchKDSock;
        private System.Windows.Forms.DataGridView dataViewSearchSock;
        private System.Windows.Forms.DataGridView dataViewSearchSale;
        private System.Windows.Forms.ComboBox cbBSearchLoaiSale;
        private System.Windows.Forms.ComboBox cbBSearchSizeSale;
        private System.Windows.Forms.ComboBox cbBSearchKDSale;
    }
}