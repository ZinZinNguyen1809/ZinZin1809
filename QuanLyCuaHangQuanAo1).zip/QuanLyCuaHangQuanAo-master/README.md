# QuanLyCuaHangQuanAo
PHẦN MỀM QUẢN LÝ SHOP QUẦN ÁO

---------------------------------

NHÓM TÁC GIẢ
- [NGUYỄN ĐẶNG PHƯƠNG NAM](https://github.com/TaolaTrumokehong) (18521125)
- [NGUYỄN LÊ MINH](https://github.com/ZinZinNguyen)(18520100)
- [TRẦN THANH HẢI](https://github.com/TranThanhHai15042000) (18520707)

-----------------------------------

MÔ TẢ

Ứng dụng quản lý shop quần áo bao gồm giao diện cho quản lý và giao diện cho nhân viên trên nền tảng Windows.  
* Phần giao diện cho quản lý sẽ gồm: quản lý các nhân viên trong shop, quản lý việc nhập hàng, quản lý hàng tồn kho, quản lý , quản lý doanh thu, chi phí,...  
* Giao diện cho nhân viên gồm: quản lý hóa đơn, quản lý thông tin khách hàng, báo cáo doanh thu: ngày, tuần, tháng.

-------------------------------------

ĐIỀU KIỆN TIÊN QUYẾT

Điều kiện trước khi thực thi chương trình:
- Hệ điều hành: Không giới hạn
- Cài đặt Windows Forms 

---------------------------------------

CÁCH THỰC THI CHƯƠNG TRÌNH


----------------------


GIẢNG VIÊN HƯỚNG DẪN

- NGUYỄN TẤN TOÀN

---------------------
CÀI ĐẶT

---------------------
THÔNG TIN LIÊN LẠC
<!-- UL -->
* 18521125@gm.uit.edu.vn    
* 18520100@gm.uit.edu.vn
* 18520707@gm.uit.edu.vn



--------------------------------------HẾT-----------------------------------------------------
