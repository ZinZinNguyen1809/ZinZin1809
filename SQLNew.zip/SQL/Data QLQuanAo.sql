﻿CREATE DATABASE QuanlyQuanAo
GO

USE QuanlyQuanAo
GO
create table Sale(
	LoaiHangSale nvarchar(5),
	TenHangSale nvarchar(30),
	priceUnSale float,
	priceSale float,
	SoLuongHSale int,
	KieuDangHSale nvarchar(5),
	NgayNhapHSale date,
	SizeHSale nvarchar(5),
)
select TenHangSale, priceSale, priceUnSale, NgayNhapHSale, SoLuongHSale from dbo.Sale where KieuDangHSale=N'Nam' and SizeHSale=N'S' and LoaiHangSale=N'Ao'
Go
--quan 
--ao
--vớ
--nón
--bill
--billinfo
--acount

--
--nhap du lieu:   1man hinh
--	kiem tra du lieu quan size 39 chuc nang 10 chuc nang 10 bang csdl thiet ke thao tac=== bấm 1 button hien 1 chuc nang 
--1 chuc nang > sql ////2 thao tac form > code c# thuan c#
--thang làm đầu thuần csdl
--man hinh chinh co n button 

CREATE TABLE Hat
(
	Ngàynhậpnón date,
	Mãsốnón int identity PRIMARY KEY,
	Tênnón nvarchar(30),
	--ChatLieuH nvarchar(50),
	Sizenón nvarchar(4),
	Sốlượngnón int,
	Kiểudángnón nvarchar(5),
	Giánón float,
)
GO

CREATE TABLE Quan
(
	NgayNhapQuan date,
	idQuan int identity PRIMARY KEY,
	nameQ nvarchar(30),
	SizeQ nvarchar(4),
	SoLuongQ int,
	KieuDangQ nvarchar(5),
	priceQ float,
)
GO
select NgayNhapQuan,idQuan ,nameQ,SoLuongQ,priceQ from dbo.Quan where KieuDangQ=N'Nam'and SizeQ='S'
GO
select NgayNhapSock,idSock ,nameS,SoLuongS,priceS from dbo.Sock where KieuDangS=N'Nữ'
GO
CREATE TABLE Ao
(
	NgayNhapAo date,
	idAo int identity PRIMARY KEY,
	nameA nvarchar(30),
	SizeA nvarchar(4),
	SoLuongA int,
	KieuDangA nvarchar(5),
	priceA float,
)
GO
select idAo ,nameA,SizeA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'
GO
select idAo ,nameA,SizeA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nữ'
go

select idAo ,nameA,SoLuongA,priceA from dbo.Ao where KieuDangA=N'Nam'and SizeA='S' 
GO

CREATE TABLE Sock
(
	NgayNhapSock date,
	idSock int identity PRIMARY KEY,
	nameS nvarchar(30),
	SizeS nvarchar(4),
	SoLuongS int,
	KieuDangS nvarchar(5),
	priceS float,

)
GO

SELECT *FROM dbo.Ao

SELECT *FROM dbo.Quan

SELECT *FROM dbo.Hat

SELECT *FROM dbo.Sock

CREATE TABLE ThongKeDoanhThu
(
	Loại nvarchar(8),
	Thờigianbán date,
	Tổnglợinhuận int,
	
)
GO



CREATE TABLE Account(
	UserName nvarchar(50),
	Pass nvarchar(50), 
)
GO

SELECT *FROM dbo.Account WHERE UserName = N'nguyenleminh' AND Pass= N'18520100'

INSERT INTO dbo.Ao(idAo,NgayNhapAo,nameA,SizeA,SoLuongA,KieuDangA) values 
GO

